#
# TABLE STRUCTURE FOR: tbl_saas_affiliate_payouts
#

DROP TABLE IF EXISTS `tbl_saas_affiliate_payouts`;

CREATE TABLE `tbl_saas_affiliate_payouts` (
  `affiliate_payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notes` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `comments` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `available_amount` decimal(18,5) DEFAULT NULL,
  `payment_method` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`affiliate_payout_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_affiliate_users
#

DROP TABLE IF EXISTS `tbl_saas_affiliate_users`;

CREATE TABLE `tbl_saas_affiliate_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT 0,
  `banned` tinyint(4) NOT NULL DEFAULT 0,
  `is_verified` tinyint(1) NOT NULL,
  `ban_reason` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `new_password_key` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `new_email_key` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `first_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `language` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'en',
  `country` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `mobile` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `avatar` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `isAffiliate` tinyint(1) NOT NULL DEFAULT 0,
  `referral_link` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `address` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `affiliate_link` (`referral_link`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_affiliates
#

DROP TABLE IF EXISTS `tbl_saas_affiliates`;

CREATE TABLE `tbl_saas_affiliates` (
  `affiliate_id` int(11) NOT NULL AUTO_INCREMENT,
  `referral_by` int(11) DEFAULT NULL,
  `referral_to` int(11) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `amount_was` decimal(18,5) DEFAULT NULL,
  `get_amount` decimal(18,5) DEFAULT NULL,
  `commission_type` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `commission_value` decimal(18,5) DEFAULT NULL,
  `payment_method` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `affiliate_rule` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `affiliate_payment_rules` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`affiliate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_all_heading_section
#

DROP TABLE IF EXISTS `tbl_saas_all_heading_section`;

CREATE TABLE `tbl_saas_all_heading_section` (
  `heading_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `icons` text DEFAULT NULL,
  `links` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`heading_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (1, 'Features designed for you', NULL, NULL, NULL, 'We believe we have created the most efficient SaaS landing page for your users. Landing page\r\nwith features that will convince you to use it for your SaaS business.', 'features', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (4, 'Creative Heads', NULL, NULL, NULL, 'Generally, every customer wants a product or service that solves their problem, worth their\r\nmoney, and is delivered with amazing customer service', 'creatives', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (5, 'Discover what makes Task manager great.', NULL, NULL, NULL, 'Start working with SaaS that can provide everything you need to generate awareness, drive traffic, connect.', 'discovers', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (11, 'About US', NULL, NULL, NULL, 'Start working with SaaS that can provide everything you need to generate awareness, drive traffic, connect.', 'abouts', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (12, 'How do we works ?', 'Work Process', NULL, NULL, '<p>Start working with SaaS that can provide everything you need to generate awareness, drive traffic, connect.<br></p>', 'about_works', 2, 1);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (13, 'Discussion', NULL, 'uil uil-presentation-edit', NULL, '<p>The most well-known dummy text is the \'Lorem Ipsum\', which is said to have originated</p>\r\n', 'discussion', 1, 1);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (14, 'Strategy & Testing', '', 'uil uil-airplay', NULL, '<p>Generators convallis odio, vel pharetra quam malesuada vel. Nam porttitor malesuada.</p>', 'strategy', 2, 1);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (15, 'Reporting', '', 'uil uil-image-check', NULL, '<p>Internet Proin tempus odio, vel pharetra quam malesuada vel. Nam porttitor malesuada.</p>', 'reporting', 2, 1);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (16, 'Latest Blog', NULL, NULL, NULL, 'Blocks, Elements and Modifiers. A smart HTML/CSS structure that can easely be reused. Layout driven by the purpose of modularity.', 'blogs_heading', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (17, 'Our Gallery', NULL, NULL, NULL, 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.', 'gallery_heading', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (18, NULL, NULL, 'facebook', '#', NULL, 'footer_icons', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (19, NULL, NULL, 'modules/saas/uploads/btransfer_in-1680588158.png', 'asddsa', 'Copyright © 2023 Smart Net GT', 'footer_left', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (20, 'Sign up and receive the latest tips via email.', 'Newsletter', 'Subscribe', 'asddsa', NULL, 'footer_right', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (21, NULL, NULL, 'instagram', '', NULL, 'footer_icons', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (22, NULL, NULL, 'twitter', '', NULL, 'footer_icons', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (23, NULL, NULL, 'linkedin', '', NULL, 'footer_icons', 2, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (24, 'by', 'PerfectSaaS. Design with', 'mdi mdi-heart text-danger', 'asddsa', 'coderitems', 'footer_bottom', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (25, 'Get in Touch', NULL, NULL, NULL, '                                                                <p>Do you wanna know more or have any query, Feel free to contact with us at Our 24/7 Dedicated support team are waiting to solve your doubt :)<br></p>                                                                                    ', 'contact_heading', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (26, 'Have Question ? Get in touch!', 'Contact us', NULL, '', '<span xss=\"removed\">Start working with SaaS that can provide everything you need to generate awareness, drive triffic, connect.</span>', 'questions', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (27, 'asddsa', NULL, NULL, NULL, 'asddsa', 'blogs_heading', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (29, 'by', 'PerfectSaaS. Design with', 'mdi mdi-heart text-danger', 'asddsa', 'CoderItems.', 'footer_bottom', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (30, 'by', 'PerfectSaaS. Design with', 'mdi mdi-heart text-danger', 'asddsasdadsasda', 'CoderItems.', 'footer_bottom', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (31, 'by', 'PerfectSaaS. Design with', 'mdi mdi-heart text-danger', 'asddsa', 'CoderItems.', 'footer_bottom', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (32, 'by', 'PerfectSaaS. Design with', 'mdi mdi-heart text-danger', 'asddsa', 'CoderItems.', 'footer_bottom', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (33, 'Trusted client by over 10,000+ of the world\'s', NULL, NULL, NULL, 'Start working with PerfectSaaS that can provide everything you need to generate awareness, drive traffic, connect.', 'blogs_heading', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (34, 'Trusted client by over 10,000+ of the world\'s', NULL, NULL, NULL, 'Start working with PerfectSaaS that can provide everything you need to generate awareness, drive traffic, connect. sad\r\n', 'brand_heading', 1, NULL);
INSERT INTO `tbl_saas_all_heading_section` (`heading_id`, `title`, `name`, `icons`, `links`, `description`, `type`, `user_id`, `status`) VALUES (35, 'We believe in building each other and hence', 'Work with some amazing partners', NULL, NULL, 'Start working with PerfectSaaS that can provide everything you need to generate awareness, drive traffic, connect.', 'review_heading', 1, NULL);


#
# TABLE STRUCTURE FOR: tbl_saas_all_section_area
#

DROP TABLE IF EXISTS `tbl_saas_all_section_area`;

CREATE TABLE `tbl_saas_all_section_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `link` varchar(191) DEFAULT NULL,
  `designation` varchar(120) DEFAULT NULL,
  `color` int(11) DEFAULT NULL,
  `title_2` varchar(120) DEFAULT NULL,
  `color_2` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `icons` text DEFAULT NULL,
  `button_name_2` varchar(120) DEFAULT NULL,
  `button_link_2` text DEFAULT NULL,
  `icons_2` text DEFAULT NULL,
  `button_name_3` varchar(120) DEFAULT NULL,
  `button_link_3` text DEFAULT NULL,
  `icons_3` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `date` varchar(30) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (2, 'Responsive Layout Template', 'Read More', '', NULL, NULL, NULL, NULL, '<p>Responsive code that makes your landing page look good on all devices (desktops, tablets, and phones). Created with mobile specialists.</p>', NULL, 'uil uil-airplay', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'features');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (4, 'SaaS Landing Page Analysis', 'Read More', NULL, NULL, NULL, NULL, NULL, '<p>A perfect structure created after we analized trends in SaaS landing page designs. Analysis made to the most popular SaaS businesses.<br></p>', NULL, 'uil uil-plane-departure', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'features');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (5, 'Smart BEM Grid', 'Read More', NULL, NULL, NULL, NULL, NULL, '<p>Blocks, Elements and Modifiers. A smart HTML/CSS structure that can easely be reused. Layout driven by the purpose of modularity.<br></p>', NULL, 'uil uil-truck', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'features');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (6, 'Marketing Online', 'Gail R. Thompson', NULL, 'Co-founder', 77, 'SEO Services', 55, NULL, NULL, 'uil uil-file-bookmark-alt', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'creatives');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (8, 'Collaborate with your team anytime and anywhare.', 'Find Better Leads', '', NULL, NULL, NULL, NULL, '<p>Start working with SaaS that can provide everything you need to generate awareness, drive traffic, connect.<br></p>', 'modules/saas/uploads/1.jpg', 'uil uil-capture', 'Find Better Leads', '', 'uil uil-file', 'Get Paid Seemlessly', '', 'uil uil-credit-card-search', 1, NULL, 2, 'features_collaborate');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (9, 'Who we are ?', 'Contact us', '', NULL, 15, NULL, NULL, '                                                                <p>Start working with PerfectSaaS that can provide everything you need to generate awareness, drive traffic, connect. Dummy text is text that is used in the publishing industry or by web designers to occupy the space which will later be filled with \'real\' content. This is required when, for example, the final text is not yet available. Dummy texts have been in use by typesetters since the 16th century.</p><p><br></p>                                                        ', 'modules/saas/uploads/about2.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'abouts');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (11, 'Meet Experience', 'Team', '', NULL, NULL, 'Team Member', NULL, '                                                                <p>Start working with PerfectSaaS that can provide everything you need to generate awareness, drive traffic, connect.</p>                                                        ', 'modules/saas/uploads/cta-bg.jpg', 'mdi mdi-play text-primary', 'Read More', '', 'uil uil-angle-right-b', NULL, NULL, NULL, 1, NULL, 1, 'about_footer');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (12, 'How do we works ?', 'Work Process', '', NULL, 33, NULL, 8, '<p>Start working with SaaS that can provide everything you need to generate awareness, drive traffic, connect.<br></p>', 'modules/saas/uploads/01.jpg', NULL, 'Read More', '', NULL, NULL, NULL, NULL, 1, '0000-00-00', 1, 'about_works');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (13, 'Discussion asddsa', NULL, '', NULL, 35, NULL, 21, '<p>The most well-known dummy text is the \'Lorem Ipsum\', which is said to have originated</p>', 'modules/saas/uploads/02.jpg', 'uil uil-presentation-edit', 'Read More', '', NULL, NULL, NULL, NULL, 1, '2023-06-26', 1, 'discussion');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (14, 'Smartest Applications for Business', 'Calvin Carlo', '', NULL, 84, NULL, 75, NULL, 'modules/saas/uploads/03.jpg', NULL, 'Read More', '', NULL, NULL, NULL, NULL, 1, '2023-06-20', 2, 'blogs');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'uil uil-angle-right-b', 'About', 'qwe', NULL, NULL, NULL, NULL, 1, NULL, 1, 'company');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'uil uil-angle-right-b', 'Privacy Policy', '/saas_perfex/front/privacy-policy', NULL, NULL, NULL, NULL, 1, NULL, 1, 'usefull_links');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (19, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'uil uil-angle-right-b', 'Terms of Services', '/saas_perfex/front/terms-conditions', NULL, NULL, NULL, NULL, 1, NULL, 1, 'usefull_links');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (20, 'Kitchen', NULL, '', NULL, 100, NULL, NULL, NULL, 'modules/saas/uploads/01.jpg', 'uil uil-arrow-up-right', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'gallery');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (22, 'Living Room', NULL, '', NULL, 77, NULL, NULL, NULL, 'modules/saas/uploads/02.jpg', 'uil uil-arrow-up-right', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'gallery');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (23, 'Office', NULL, '', NULL, 110, NULL, NULL, NULL, 'modules/saas/uploads/03.jpg', 'uil uil-arrow-up-right', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'gallery');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (24, 'Dining Hall', NULL, '', NULL, 35, NULL, NULL, NULL, 'modules/saas/uploads/04.jpg', 'uil uil-arrow-up-right', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'gallery');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (27, 'Email', 'ventas@smartnetgt.com', '', NULL, NULL, NULL, NULL, NULL, NULL, 'mail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'new_contact');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (29, 'Location', 'View on Google map', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'map-pin', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 'new_contact');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (34, 'Management Dashboard', NULL, NULL, NULL, NULL, NULL, NULL, 'Dummy text is text that is used in the publishing industry or by web designers.', 'modules/saas/uploads/apps.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'discovers');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (35, 'Management Timeline', NULL, NULL, NULL, NULL, NULL, NULL, 'Dummy text is text that is used in the publishing industry or by web designers.', 'modules/saas/uploads/task.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'discovers');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (36, 'Payment Management', NULL, NULL, NULL, NULL, NULL, NULL, 'Dummy text is text that is used in the publishing industry or by web designers.', 'modules/saas/uploads/timeline.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'discovers');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (37, 'File Integrate', NULL, NULL, NULL, NULL, NULL, NULL, 'Dummy text is text that is used in the publishing industry or by web designers.', 'modules/saas/uploads/widgets2.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 2, 'discovers');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (38, 'How do we works ?', 'Work Process', NULL, NULL, NULL, NULL, NULL, '<p>Start working with SaaS that can provide everything you need to generate awareness, drive traffic, connect.</p>', NULL, '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 2, 'about_works');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (50, 'Great Product Analytics With Real Problem', 'Buy Now', '', NULL, NULL, NULL, NULL, 'Due to its widespread use as filler text for layouts, non-readability is of great importance: human perception is tuned to recognize certain patterns and repetitions in texts. If the distribution of letters visual impact.', 'modules/saas/uploads/classic02.png', '', '', '', '', '', '', '', 1, NULL, 1, 'features_collaborate');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (51, 'PayPal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'modules/saas/uploads/paypal.svg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'brands');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (52, 'amazon', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'modules/saas/uploads/amazon.svg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'brands');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (53, 'google', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'modules/saas/uploads/google.svg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'brands');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (54, 'Thomas Israel', NULL, NULL, 'C.E.O', NULL, '5', NULL, 'It seems that only fragments of the original text\r\n                                        remain in the Lorem Ipsum texts used today. ', 'modules/saas/uploads/0_1.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'reviews');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (55, 'Barbara McIntosh ', NULL, NULL, 'M.D', NULL, '4.5', NULL, 'One disadvantage of Lorum Ipsum is that in Latin\r\n                                        certain letters appear more frequently than others.', 'modules/saas/uploads/02.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'reviews');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (56, 'Carl Oliver', NULL, NULL, 'P.A', NULL, '5', NULL, 'The most well-known dummy text is the \'Lorem Ipsum\',\r\n                                        which is said to have originated in the 16th century. ', 'modules/saas/uploads/03.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'reviews');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (57, 'Christa Smith', NULL, NULL, 'Manager', NULL, '5', NULL, 'According to most sources, Lorum Ipsum can be traced\r\n                                        back to a text composed by Cicero. ', 'modules/saas/uploads/04.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'reviews');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (58, 'Dean Tolle', NULL, NULL, 'Developer', NULL, '4.5', NULL, ' There is now an abundance of readable dummy texts.\r\n                                        These are usually used when a text is required. ', 'modules/saas/uploads/05.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'reviews');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (59, 'Jill Webb', NULL, NULL, 'Sr. Developer', NULL, '5', NULL, 'Thus, Lorem Ipsum has only limited suitability as a\r\n                                        visual filler for German texts.', 'modules/saas/uploads/06.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'reviews');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (60, 'Lenevo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'modules/saas/uploads/lenovo.svg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'brands');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (61, 'Shopify', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'modules/saas/uploads/shopify.svg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'brands');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (62, 'Spotify', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'modules/saas/uploads/spotify.svg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, 'brands');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (65, 'asdsda', 'adssad', NULL, NULL, NULL, NULL, NULL, '                                                            dsasadsdasad', NULL, 'asddsa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'about_works');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (66, 'asd', 'sdsda', NULL, NULL, NULL, NULL, NULL, '                                                            asd', NULL, 'sad', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'discussion');
INSERT INTO `tbl_saas_all_section_area` (`id`, `title`, `name`, `link`, `designation`, `color`, `title_2`, `color_2`, `description`, `image`, `icons`, `button_name_2`, `button_link_2`, `icons_2`, `button_name_3`, `button_link_3`, `icons_3`, `status`, `date`, `user_id`, `type`) VALUES (67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Blogs', '/saas_perfex/front/blog', NULL, NULL, NULL, NULL, 1, NULL, 1, 'company');


#
# TABLE STRUCTURE FOR: tbl_saas_applied_coupon
#

DROP TABLE IF EXISTS `tbl_saas_applied_coupon`;

CREATE TABLE `tbl_saas_applied_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_amount` varchar(100) DEFAULT NULL,
  `discount_percentage` varchar(100) DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `coupon` varchar(50) DEFAULT NULL,
  `applied_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_companies
#

DROP TABLE IF EXISTS `tbl_saas_companies`;

CREATE TABLE `tbl_saas_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `domain` varchar(250) DEFAULT NULL,
  `domain_url` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status` enum('pending','running','expired','suspended','terminated') DEFAULT 'pending',
  `activation_code` varchar(50) DEFAULT NULL,
  `package_id` int(11) NOT NULL,
  `db_name` varchar(120) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `frequency` varchar(50) DEFAULT NULL,
  `trial_period` varchar(20) DEFAULT NULL,
  `is_trial` enum('Yes','No') DEFAULT 'No',
  `expired_date` date DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `timezone` varchar(250) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `maintenance_mode_message` varchar(200) DEFAULT NULL,
  `maintenance_mode` varchar(20) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  `referral_by` int(11) DEFAULT NULL,
  `for_seed` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_companies` (`id`, `name`, `email`, `password`, `domain`, `domain_url`, `status`, `activation_code`, `package_id`, `db_name`, `amount`, `frequency`, `trial_period`, `is_trial`, `expired_date`, `currency`, `timezone`, `language`, `country`, `mobile`, `address`, `remarks`, `maintenance_mode_message`, `maintenance_mode`, `created_date`, `created_by`, `updated_date`, `updated_by`, `referral_by`, `for_seed`) VALUES (1, 'ERP SmartNet GT', 'sample@perfectsaas.com', '123456', 'company_seed', NULL, 'running', NULL, 1, 'designtech_company_seed_1', '0.00', 'lifetime', '0', 'No', '2124-12-15', '$', 'America/Guatemala', NULL, 'US', '', '', NULL, NULL, NULL, '2024-12-16 03:23:56', NULL, NULL, 0, NULL, 'yes');


#
# TABLE STRUCTURE FOR: tbl_saas_companies_history
#

DROP TABLE IF EXISTS `tbl_saas_companies_history`;

CREATE TABLE `tbl_saas_companies_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `companies_id` int(11) DEFAULT NULL,
  `amount` decimal(25,5) NOT NULL DEFAULT 0.00000,
  `reports` varchar(50) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `i_have_read_agree` enum('Yes','No') DEFAULT 'Yes',
  `payment_method` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `frequency` varchar(50) DEFAULT NULL,
  `validity` date DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `source` varchar(20) DEFAULT NULL,
  `package_name` varchar(250) DEFAULT NULL,
  `staff_no` varchar(50) DEFAULT NULL,
  `additional_staff_no` varchar(20) DEFAULT NULL,
  `client_no` varchar(20) DEFAULT NULL,
  `additional_client_no` varchar(20) DEFAULT NULL,
  `project_no` varchar(20) DEFAULT NULL,
  `additional_project_no` varchar(20) DEFAULT NULL,
  `invoice_no` varchar(20) DEFAULT NULL,
  `additional_invoice_no` varchar(20) DEFAULT NULL,
  `leads_no` varchar(50) DEFAULT NULL,
  `additional_leads_no` varchar(50) DEFAULT NULL,
  `expense_no` varchar(50) DEFAULT NULL,
  `additional_expense_no` varchar(50) DEFAULT NULL,
  `contract_no` varchar(50) DEFAULT NULL,
  `additional_contract_no` varchar(50) DEFAULT NULL,
  `estimate_no` varchar(50) NOT NULL,
  `additional_estimate_no` varchar(50) DEFAULT NULL,
  `calendar` varchar(50) DEFAULT NULL,
  `credit_note_no` varchar(50) DEFAULT NULL,
  `additional_credit_note_no` varchar(50) DEFAULT NULL,
  `proposal_no` varchar(50) DEFAULT NULL,
  `additional_proposal_no` varchar(50) DEFAULT NULL,
  `tickets` varchar(50) DEFAULT NULL,
  `additional_tickets` varchar(50) DEFAULT NULL,
  `tasks_no` varchar(50) DEFAULT NULL,
  `additional_tasks_no` varchar(50) DEFAULT NULL,
  `item_no` varchar(50) DEFAULT NULL,
  `additional_item_no` varchar(50) DEFAULT NULL,
  `disk_space` varchar(50) DEFAULT NULL,
  `additional_disk_space` varchar(100) DEFAULT NULL,
  `currency` varchar(100) DEFAULT NULL,
  `allowed_payment_modes` text DEFAULT NULL,
  `modules` text DEFAULT NULL,
  `allowed_themes` text DEFAULT NULL,
  `disabled_modules` text DEFAULT NULL,
  `custom_domain` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `saas_companies_instance_id_foreign` (`companies_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_companies_history` (`id`, `companies_id`, `amount`, `reports`, `ip`, `i_have_read_agree`, `payment_method`, `created_at`, `frequency`, `validity`, `active`, `source`, `package_name`, `staff_no`, `additional_staff_no`, `client_no`, `additional_client_no`, `project_no`, `additional_project_no`, `invoice_no`, `additional_invoice_no`, `leads_no`, `additional_leads_no`, `expense_no`, `additional_expense_no`, `contract_no`, `additional_contract_no`, `estimate_no`, `additional_estimate_no`, `calendar`, `credit_note_no`, `additional_credit_note_no`, `proposal_no`, `additional_proposal_no`, `tickets`, `additional_tickets`, `tasks_no`, `additional_tasks_no`, `item_no`, `additional_item_no`, `disk_space`, `additional_disk_space`, `currency`, `allowed_payment_modes`, `modules`, `allowed_themes`, `disabled_modules`, `custom_domain`) VALUES (1, NULL, '0.00000', 'Yes', NULL, 'Yes', NULL, '2024-12-16 03:24:00', NULL, NULL, 1, NULL, 'BIZTEAM', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Yes', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, 'a:0:{}', 'a:0:{}', NULL, NULL, '0');


#
# TABLE STRUCTURE FOR: tbl_saas_companies_payment
#

DROP TABLE IF EXISTS `tbl_saas_companies_payment`;

CREATE TABLE `tbl_saas_companies_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companies_history_id` int(11) DEFAULT NULL,
  `companies_id` int(11) NOT NULL,
  `reference_no` text DEFAULT NULL,
  `transaction_id` text DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_date` varchar(20) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `subtotal` varchar(50) DEFAULT NULL,
  `discount_percent` varchar(50) DEFAULT NULL,
  `discount_amount` varchar(50) DEFAULT NULL,
  `coupon_code` varchar(50) DEFAULT NULL,
  `total_amount` varchar(50) DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_coupon
#

DROP TABLE IF EXISTS `tbl_saas_coupon`;

CREATE TABLE `tbl_saas_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `type` tinyint(1) DEFAULT 0 COMMENT '0=fixed,1=discount',
  `package_type` varchar(30) DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `show_on_pricing` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_domain_requests
#

DROP TABLE IF EXISTS `tbl_saas_domain_requests`;

CREATE TABLE `tbl_saas_domain_requests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `custom_domain` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_front_cms_media
#

DROP TABLE IF EXISTS `tbl_saas_front_cms_media`;

CREATE TABLE `tbl_saas_front_cms_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(300) DEFAULT NULL,
  `thumb_path` varchar(300) DEFAULT NULL,
  `dir_path` varchar(300) DEFAULT NULL,
  `img_name` varchar(300) DEFAULT NULL,
  `thumb_name` varchar(300) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `file_type` varchar(100) DEFAULT NULL,
  `file_ext` varchar(50) DEFAULT NULL,
  `file_size` varchar(100) NOT NULL,
  `vid_url` mediumtext NOT NULL,
  `vid_title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (127, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'l4.jpg', 'l4.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '98.19', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (128, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'l2.jpg', 'l2.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '72.5', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (129, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'l1.jpg', 'l1.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '86.27', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (130, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'powerfull-features01.png', 'powerfull-features01.png', '2022-11-20 11:56:38', 'image', 'image/png', '20.75', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (131, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'team03.png', 'team03.png', '2022-11-20 11:56:38', 'image', 'image/jpg', '142.07', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (132, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'team02.jpg', 'team02.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '88.26', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (133, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'team01.jpg', 'team01.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '69.41', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (134, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'slack-3.png', 'slack-3.png', '2022-11-20 11:56:38', 'image', 'image/png', '27.59', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (135, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', '1.jpg', '1.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '56.14', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (136, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', '1-1.jpg', '1-1.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '62.59', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (137, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', '1-2.jpg', '1-2.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '59.38', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (138, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'slack-1.svg', 'slack-1.svg', '2022-11-20 11:56:38', 'image', 'image/svg+xml', '45.93', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (139, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'slack-2.svg', 'slack-2.svg', '2022-11-20 11:56:38', 'image', 'image/svg+xml', '10.31', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (140, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'icon1.png', 'icon1.png', '2022-11-20 11:56:38', 'image', 'image/png', '0.72', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (141, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'blog03.jpg', 'blog03.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '120.05', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (142, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'blog02.jpg', 'blog02.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '180.06', '', '');
INSERT INTO `tbl_saas_front_cms_media` (`id`, `image`, `thumb_path`, `dir_path`, `img_name`, `thumb_name`, `created_at`, `file_type`, `file_ext`, `file_size`, `vid_url`, `vid_title`) VALUES (143, NULL, 'modules/saas/uploads/', 'modules/saas/uploads/', 'blog01.jpg', 'blog01.jpg', '2022-11-20 11:56:38', 'image', 'image/jpg', '150.62', '', '');


#
# TABLE STRUCTURE FOR: tbl_saas_front_contact_us
#

DROP TABLE IF EXISTS `tbl_saas_front_contact_us`;

CREATE TABLE `tbl_saas_front_contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(22) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `view_status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tbl_saas_front_menu_items
#

DROP TABLE IF EXISTS `tbl_saas_front_menu_items`;

CREATE TABLE `tbl_saas_front_menu_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `menu` varchar(100) DEFAULT NULL,
  `page_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `ext_url` mediumtext DEFAULT NULL,
  `open_new_tab` int(11) DEFAULT 0,
  `ext_url_link` mediumtext DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `publish` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `is_active` varchar(10) DEFAULT 'no',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (1, 1, 'Home', 1, 0, NULL, NULL, NULL, 'home', 1, 0, NULL, 'no', '2022-11-20 11:56:39');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (3, 1, 'About', 128, 0, NULL, NULL, NULL, 'about', 2, 0, NULL, 'no', '2023-07-19 15:10:13');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (16, 2, 'Home', 1, 0, NULL, NULL, NULL, 'home-1', 1, 0, NULL, 'no', '2022-11-20 11:56:39');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (17, 2, 'About Us', 114, 0, NULL, NULL, NULL, 'about-us', 2, 0, NULL, 'no', '2022-11-20 11:56:39');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (20, 2, 'Gallery', 117, 0, NULL, NULL, NULL, 'gallery', 6, 0, NULL, 'no', '2022-11-20 11:56:39');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (21, 2, 'Contact Us', 76, 0, NULL, NULL, NULL, 'contact-us-1', 7, 0, NULL, 'no', '2022-11-20 11:56:39');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (45, 1, 'Pricing', 125, 0, NULL, NULL, NULL, 'pricing', 4, 0, NULL, 'no', '2023-07-19 15:10:13');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (48, 1, 'Contact Us', 2, 0, NULL, NULL, NULL, 'contact-us', 10, 0, NULL, 'no', '2023-07-19 15:31:58');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (50, 1, 'Gallary', 130, 58, NULL, NULL, NULL, 'gallery', 8, 0, NULL, 'no', '2023-07-19 15:31:59');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (51, 1, 'Blog', 129, 58, NULL, NULL, NULL, 'blog', 7, 0, NULL, 'no', '2023-07-19 15:31:58');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (52, 1, 'Features', 132, 58, NULL, NULL, NULL, 'features', 3, 0, NULL, 'no', '2023-07-19 15:10:13');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (57, 1, 'Affiliate', 133, 0, NULL, NULL, NULL, 'affiliate', 5, 0, NULL, 'no', '2023-07-19 15:10:13');
INSERT INTO `tbl_saas_front_menu_items` (`id`, `menu_id`, `menu`, `page_id`, `parent_id`, `ext_url`, `open_new_tab`, `ext_url_link`, `slug`, `weight`, `publish`, `description`, `is_active`, `created_at`) VALUES (58, 1, 'Others', 0, 0, NULL, NULL, NULL, 'others', 6, 0, NULL, 'no', '2023-07-19 15:31:57');


#
# TABLE STRUCTURE FOR: tbl_saas_front_menus
#

DROP TABLE IF EXISTS `tbl_saas_front_menus`;

CREATE TABLE `tbl_saas_front_menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(100) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `open_new_tab` int(11) NOT NULL DEFAULT 0,
  `ext_url` mediumtext NOT NULL,
  `ext_url_link` mediumtext NOT NULL,
  `publish` int(11) NOT NULL DEFAULT 0,
  `content_type` varchar(10) NOT NULL DEFAULT 'manual',
  `is_active` varchar(10) DEFAULT 'no',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_front_menus` (`id`, `menu`, `slug`, `description`, `open_new_tab`, `ext_url`, `ext_url_link`, `publish`, `content_type`, `is_active`, `created_at`) VALUES (1, 'Main Menu', 'main-menu', 'Main menu', 0, '', '', 0, 'default', 'no', '2022-11-20 11:56:38');
INSERT INTO `tbl_saas_front_menus` (`id`, `menu`, `slug`, `description`, `open_new_tab`, `ext_url`, `ext_url_link`, `publish`, `content_type`, `is_active`, `created_at`) VALUES (2, 'Bottom Menu', 'bottom-menu', 'Bottom Menu', 0, '', '', 0, 'default', 'no', '2022-11-20 11:56:38');


#
# TABLE STRUCTURE FOR: tbl_saas_front_pages
#

DROP TABLE IF EXISTS `tbl_saas_front_pages`;

CREATE TABLE `tbl_saas_front_pages` (
  `pages_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_type` varchar(10) NOT NULL DEFAULT 'manual',
  `is_homepage` int(11) DEFAULT 0,
  `title` varchar(250) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `meta_title` mediumtext DEFAULT NULL,
  `meta_description` mediumtext DEFAULT NULL,
  `meta_keyword` mediumtext DEFAULT NULL,
  `feature_image` varchar(200) NOT NULL,
  `description` longtext DEFAULT NULL,
  `publish_date` date NOT NULL,
  `publish` int(11) DEFAULT 0,
  `sidebar` int(11) DEFAULT 0,
  `is_active` varchar(10) DEFAULT 'no',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`pages_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (1, 'default', 0, 'Home', 'front/home', 'page', 'home', 'Home Page', 'Home Page                                                                                                                                                                                                                         ', 'Home Page', '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;\r\n<section class=\"features-area pt-100 pb-70\" id=\"features\">\r\n<div class=\"container\">\r\n<div class=\"section-header text-center mb-50\">\r\n<h2>Don&#39;t write in this page.the page its default. edit will not working</h2>\r\n</div>\r\n</div>\r\n</section>\r\n\r\n<section class=\"our-team bg-light pt-100 pb-70\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-xl-4 col-lg-4 col-md-4\">\r\n<div class=\"team-box mb-30\">\r\n<div class=\"progess-wrapper\">\r\n<div class=\"single-skill mb-20\">\r\n<div class=\"progress\">\r\n<div aria-valuemax=\"100\" aria-valuemin=\"0\" aria-valuenow=\"80\" class=\"progress-bar wow slideInLeft\" data-wow-delay=\".6s\" data-wow-duration=\"1s\" role=\"progressbar\" xss=\"removed\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '2019-01-14', 1, 1, 'no', '2023-07-18 13:31:55');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (2, 'default', 0, 'Contact us', 'front/contact-us', 'page', 'contact-us', '', '', '', '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;\r\n<p>Don&#39;t write in this page.the page its default. edit will not working</p>\r\n&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '2019-01-14', 0, NULL, 'no', '2023-07-18 13:31:47');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (3, 'default', 0, 'Terms & Conditions', 'front/terms-conditions', 'page', 'terms-conditions', '', '', '', '', '<h4>Introduction as</h4>\r\n\r\n<p xss=\"removed\">These Website Standard Terms and Conditions written on this webpage shall manage your use of our website, Webiste Name accessible at Website.com.</p>\r\n\r\n<p xss=\"removed\">These Terms will be applied fully and affect to your use of this Website. By using this Website, you agreed to accept all terms and conditions written in here. You must not use this Website if you disagree with any of these Website Standard Terms and Conditions.</p>\r\n\r\n<p xss=\"removed\">Minors or people below 18 years old are not allowed to use this Website.</p>\r\n\r\n<h4>Intellectual Property Rights</h4>\r\n\r\n<p xss=\"removed\">Other than the content you own, under these Terms, Company Name and/or its licensors own all the intellectual property rights and materials contained in this Website.</p>\r\n\r\n<p xss=\"removed\">You are granted limited license only for purposes of viewing the material contained on this Website.</p>\r\n\r\n<h4>Restrictions</h4>\r\n\r\n<p xss=\"removed\">You are specifically restricted from all of the following:</p>\r\n\r\n<ul xss=\"removed\">\r\n <li xss=\"removed\">publishing any Website material in any other media;</li>\r\n <li xss=\"removed\">selling, sublicensing and/or otherwise commercializing any Website material;</li>\r\n <li xss=\"removed\">publicly performing and/or showing any Website material;</li>\r\n <li xss=\"removed\">using this Website in any way that is or may be damaging to this Website;</li>\r\n <li xss=\"removed\">using this Website in any way that impacts user access to this Website;</li>\r\n <li xss=\"removed\">using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>\r\n <li xss=\"removed\">engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>\r\n <li xss=\"removed\">using this Website to engage in any advertising or marketing.</li>\r\n</ul>\r\n\r\n<p xss=\"removed\">Certain areas of this Website are restricted from being access by you and Company Name may further restrict access by you to any areas of this Website, at any time, in absolute discretion. Any user ID and password you may have for this Website are confidential and you must maintain confidentiality as well.</p>\r\n\r\n<h4>Your Content</h4>\r\n\r\n<p xss=\"removed\">In these Website Standard Terms and Conditions, â€œYour Contentâ€ shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant Company Name a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>\r\n\r\n<p xss=\"removed\">Your Content must be your own and must not be invading any third-party&#39;s rights. Company Name reserves the right to remove any of Your Content from this Website at any time without notice.</p>\r\n\r\n<h4>No warranties</h4>\r\n\r\n<p xss=\"removed\">This Website is provided â€œas is,â€ with all faults, and Company Name express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>\r\n\r\n<h4>Limitation of liability</h4>\r\n\r\n<p xss=\"removed\">In no event shall Company Name, nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract.  Company Name, including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.</p>\r\n\r\n<h4>Indemnification<br>\r\nYou hereby indemnify to the fullest extent Company Name from and against any and/or all liabilities, costs, demands, causes of action, damages and expenses arising in any way related to your breach of any of the provisions of these Terms.</h4>\r\n\r\n<h2 xss=\"removed\"> </h2>\r\n\r\n<p xss=\"removed\"> </p>\r\n\r\n<h4>Severability</h4>\r\n\r\n<p xss=\"removed\">If any provision of these Terms is found to be invalid under any applicable law, such provisions shall be deleted without affecting the remaining provisions herein.</p>\r\n\r\n<h4>Variation of Terms</h4>\r\n\r\n<p xss=\"removed\">Company Name is permitted to revise these Terms at any time as it sees fit, and by using this Website you are expected to review these Terms on a regular basis.</p>\r\n\r\n<h4>Assignment</h4>\r\n\r\n<p xss=\"removed\">The Company Name is allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification. However, you are not allowed to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.</p>\r\n\r\n<h4>Entire Agreement</h4>\r\n\r\n<p xss=\"removed\">These Terms constitute the entire agreement between Company Name and you in relation to your use of this Website, and supersede all prior agreements and understandings.</p>\r\n\r\n<h4>Governing Law & Jurisdiction</h4>\r\n\r\n<p xss=\"removed\">These Terms will be governed by and interpreted in accordance with the laws of the State of Country, and you submit to the non-exclusive jurisdiction of the state and federal courts located in Country for the resolution of any disputes.</p>\r\n', '2019-01-14', 0, NULL, 'no', '2023-07-11 17:06:08');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (4, 'default', 0, '404 not Found', 'front/404-not-found', 'page', '404-not-found', '', '                                ', '', '', '\n<div class=\"cps-main-wrap\">\n<div class=\"cps-section cps-section-padding\">\n<div class=\"container text-center\">\n<div class=\"cps-404-content\">\n<h3 class=\"cps-404-title\">Hey Error 404</h3>\n\n<p class=\"cps-404-text\">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>\n<a class=\"btn btn-to-home\" href=\"#\" tppabs=\"#\">Back to Home</a></div>\n</div>\n</div>\n</div>\n', '2019-01-14', 0, NULL, 'no', '2022-11-20 11:56:39');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (5, 'default', 0, 'Pricing', 'front/pricing', 'page', 'pricing', NULL, NULL, NULL, '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;\r\n<section class=\"cps-section cps-section-padding cps-gray-bg\" id=\"pricing\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-md-12 col-xs-12\">\r\n<div class=\"cps-section-header text-center\">\r\n<h3 class=\"cps-section-title\">Don&#39;t write in this page.the page its default. edit will not working</h3>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"cps-section cps-section-padding\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-md-12 text-center\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '2019-01-14', 0, 0, 'no', '2023-07-21 19:40:18');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (6, 'default', 0, 'Privacy Policy', 'front/privacy-policy', 'page', 'privacy-policy', NULL, NULL, NULL, '', '<section class=\"works-area bg-light pt-120 pb-100\">\r\n            <div class=\"container\"><h4 class=\"text-center\">WELCOME TO SOFTWARE ADVICE! PLEASE TAKE TIME TO READ OUR PRIVACY POLICY!</h4>\r\n\r\n\r\n\r\n<p style=\"margin-bottom: 1.25rem; text-align: center; text-rendering: optimizelegibility; padding: 0px; line-height: 1.6; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px; color: rgb(77, 77, 77);\">This Privacy Policy covers the privacy practices of Software Advice, a Texas company, and our Affiliates (\"Software Advice\" \"we\" or \"us\"), along with the Sites on which this Privacy Policy is posted (the \"Sites\"). This Policy does not apply to those of our Affiliates, which due to their different business models, have developed their own privacy policies: CEB, Iconoculture, L2&nbsp;and&nbsp;Gartner.</p>\r\n\r\n\r\n\r\n<p style=\"margin-bottom: 1.25rem; text-align: center; text-rendering: optimizelegibility; padding: 0px; line-height: 1.6; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px; color: rgb(77, 77, 77);\"><span style=\"line-height: inherit; font-weight: 700;\">WHAT WE DO:</span>&nbsp;We millions of users to research and evaluate the right software solutions and services for their organizations. As part of our comprehensive directory of products and services, we provide verified user reviews, original research&nbsp;and&nbsp;personalized guidance. Users may also connect directly with software vendors that choose to participate in our lead generation programs.</p>\r\n\r\n\r\n\r\n<p style=\"margin-bottom: 1.25rem; text-align: center; text-rendering: optimizelegibility; padding: 0px; line-height: 1.6; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px; color: rgb(77, 77, 77);\"><span style=\"line-height: inherit; font-weight: 700;\">OUR PRIVACY PRACTICES:</span>&nbsp;While using our Sites and Services, and as part of the normal course of business, we may collect personal information (\"Information\") about you. We want you to understand how we use the information we collect, and that you share with us, and how you may protect your privacy while using our Sites.</p>\r\n\r\n\r\n\r\n<p style=\"margin-bottom: 1.25rem; text-align: center; text-rendering: optimizelegibility; padding: 0px; line-height: 1.6; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px; color: rgb(77, 77, 77);\"><span style=\"line-height: inherit; font-weight: 700;\">YOUR CONSENT:</span>&nbsp;When you provide your Information to us, you consent to the collection, storage and use of your Information by us, our Affiliates and third parties in accordance with the terms set out in this Policy. \"Affiliate\" is any legal entity that controls, is controlled by or is under common control with Gartner (our parent company).</p>\r\n\r\n\r\n</div>\r\n\r\n\r\n</section>', '2019-01-14', 0, 0, 'no', '2023-07-21 19:40:21');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (7, 'default', 0, 'About US', 'front/about-us', 'page', 'about-us', NULL, NULL, NULL, '', '\n<section class=\"powerful-features gray-bg pt-120 pb-50\" id=\"features\">\n<div class=\"container\">\n<div class=\"row\">\n<div class=\"col-xl-12\">\n<div class=\"section-header mb-80 text-center\">\n<h2>Powerful Features</h2>\n\n<p>Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod</p>\n</div>\n</div>\n\n<div class=\"col-xl-4 col-lg-4\">\n<div class=\"powerful-features-single-step mb-70 mt-80\">\n<div class=\"features-text text-right fix pr-30\"><span>Easy Instalations</span>\n\n<p>Lorem ipsum dolor sit amet consectr ncididunt ut labore et dolore</p>\n</div>\n</div>\n\n<div class=\"powerful-features-single-step mb-70\">\n<div class=\"features-text text-right fix pr-30\"><span>Real Time Customizat </span>\n\n<p>Lorem ipsum dolor sit amet consectr ncididunt ut labore et dolore</p>\n</div>\n</div>\n\n<div class=\"powerful-features-single-step mb-70\">\n<div class=\"features-text text-right fix pr-30\"><span>Customer Support</span>\n\n<p>Lorem ipsum dolor sit amet consectr ncididunt ut labore et dolore</p>\n</div>\n</div>\n</div>\n\n<div class=\"col-xl-4 col-lg-4\">\n<div class=\"powerfull-features-img\"><img alt=\"\" src=\"http://localhost/client_moumen/uploads/gallery/powerfull-features01.png\"></div>\n</div>\n\n<div class=\"col-xl-4 col-lg-4\">\n<div class=\"powerful-features-single-step mb-70 mt-80\">\n<div class=\"features-text pl-30 fix\"><span>Easy Editable</span>\n\n<p>Lorem ipsum dolor sit amet consectr ncididunt ut labore et dolore</p>\n</div>\n</div>\n\n<div class=\"powerful-features-single-step mb-70\">\n<div class=\"features-text pl-30 fix\"><span>Clean & Unique Design</span>\n\n<p>Lorem ipsum dolor sit amet consectr ncididunt ut labore et dolore</p>\n</div>\n</div>\n\n<div class=\"powerful-features-single-step mb-70\">\n<div class=\"features-text pl-30 fix\"><span>Clean Code</span>\n\n<p>Lorem ipsum dolor sit amet consectr ncididunt ut labore et dolore</p>\n</div>\n</div>\n</div>\n</div>\n</div>\n</section>\n\n<section class=\"powerful-features-video pt-205 pb-130\">\n<div class=\"container\">\n<div class=\"powerfull-features-video position-relative\"><img alt=\"\" src=\"http://localhost/client_moumen/uploads/gallery/powerfull-features-video.jpg\"></div>\n</div>\n</section>\n\n', '2019-01-14', 0, 0, 'no', '2023-07-21 19:40:24');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (8, 'default', 0, 'Blog', 'front/blog', 'page', 'blog', NULL, NULL, NULL, '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;\r\n<section class=\"blog-area pt-120 pb-65\" id=\"latest-blog\">\r\n<div class=\"container\">&lt;!-- Section-header start --&gt;\r\n<div class=\"section-header text-center mb-80\">\r\n<h2>Don&#39;t write in this page.the page its default. edit will not working</h2>\r\n</div>\r\n\r\n<div class=\"row\">\r\n<div class=\"col-xl-4 col-lg-4\">&lt;!-- Blog-wrapper end --&gt;</div>\r\n</div>\r\n</div>\r\n</section>\r\n&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '2019-01-14', 0, 0, 'no', '2023-07-21 19:40:27');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (9, 'default', 0, 'Gallery', 'front/gallery', 'page', 'gallery', NULL, NULL, NULL, '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;&lt;!-- our-gallery strat--&gt;\r\n<div class=\"our-gallery pt-120 pb-100\">\r\n<div class=\"container\">\r\n<div class=\"section-header mb-80 text-center\">\r\n<h2>Don&#39;t write in this page.the page its default. edit will not working</h2>\r\n</div>\r\n</div>\r\n</div>\r\n&lt;!-- our-gallery end--&gt;&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '2019-01-14', 0, 0, 'no', '2023-07-21 19:40:30');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (10, 'default', 0, 'Features', 'front/features', 'page', 'features', NULL, NULL, NULL, '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;\r\n<div class=\"cps-section cps-section-padding\" id=\"service-box\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-md-12\">\r\n<div class=\"cps-section-header text-center style-4\">\r\n<h3 class=\"cps-section-title\">Don&#39;t write in this page.the page its default. edit will not working</h3>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '2021-06-20', 0, 0, 'no', '2023-07-21 19:40:32');
INSERT INTO `tbl_saas_front_pages` (`pages_id`, `page_type`, `is_homepage`, `title`, `url`, `type`, `slug`, `meta_title`, `meta_description`, `meta_keyword`, `feature_image`, `description`, `publish_date`, `publish`, `sidebar`, `is_active`, `created_at`) VALUES (11, 'default', 0, 'Affiliate Program', 'front/affiliate-program', 'page', 'affiliate-program', NULL, NULL, NULL, '', '&lt;html&gt;\r\n&lt;head&gt;\r\n &lt;title&gt;&lt;/title&gt;\r\n&lt;/head&gt;\r\n&lt;body data-gr-ext-disabled=\"forever\" data-gr-ext-installed=\"\" data-new-gr-c-s-check-loaded=\"14.1115.0\" data-new-gr-c-s-loaded=\"14.1115.0\"&gt;\r\n<p>Don&#39;t write in this page.the page its default. edit will not working</p>\r\n&lt;/body&gt;\r\n&lt;/html&gt;\r\n', '0000-00-00', 0, 0, 'no', '2023-07-21 19:40:36');


#
# TABLE STRUCTURE FOR: tbl_saas_front_pages_contents
#

DROP TABLE IF EXISTS `tbl_saas_front_pages_contents`;

CREATE TABLE `tbl_saas_front_pages_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `content_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbl_saas_front_slider
#

DROP TABLE IF EXISTS `tbl_saas_front_slider`;

CREATE TABLE `tbl_saas_front_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(350) DEFAULT NULL,
  `subtitle` text NOT NULL,
  `description` text DEFAULT NULL,
  `slider_bg` varchar(255) NOT NULL,
  `slider_img` text DEFAULT NULL,
  `button_text_1` varchar(255) DEFAULT NULL,
  `button_text_2` varchar(255) DEFAULT NULL,
  `button_icon_1` varchar(100) DEFAULT NULL,
  `button_icon_2` varchar(100) DEFAULT NULL,
  `button_link_1` varchar(255) DEFAULT NULL,
  `button_link_2` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_saas_front_slider` (`id`, `title`, `subtitle`, `description`, `slider_bg`, `slider_img`, `button_text_1`, `button_text_2`, `button_icon_1`, `button_icon_2`, `button_link_1`, `button_link_2`, `sort`, `status`) VALUES (1, 'Better Management  <br>  Less Expense', 'Not sure about Pro? Try trial first!', '                                                                                                <div class=\"slider-intro-list mb-40\">                                        <ul>                                            <li><span class=\"fal fa-check\"></span>Unlimited Projects.</li>                                            <li><span class=\"fal fa-check\"></span>Unlimited Team Members.</li>                                            <li><span class=\"fal fa-check\"></span>Unlimited Disk Space.</li>                                        </ul>                                    </div>                                                                                    ', 'modules/saas/uploads/slider-bg-01.jpeg', 'modules/saas/uploads/slider-thum-01.png', 'Take Off', '14 days free trial', NULL, 'fal fa-user-alt mr-1', '', '', 0, 1);
INSERT INTO `tbl_saas_front_slider` (`id`, `title`, `subtitle`, `description`, `slider_bg`, `slider_img`, `button_text_1`, `button_text_2`, `button_icon_1`, `button_icon_2`, `button_link_1`, `button_link_2`, `sort`, `status`) VALUES (2, 'Business Growth', 'Not sure about Pro? Try trial first!', '<div class=\"slider-intro-list mb-40\">                                        <ul>\n                                            <li><span class=\"fal fa-check\"></span>Unlimited Projects.</li>\n                                            <li><span class=\"fal fa-check\"></span>Unlimited Team Members.</li>\n                                            <li><span class=\"fal fa-check\"></span>Unlimited Disk Space.</li>\n                                        </ul>\n                                    </div>', 'modules/saas/uploads/14_1.png', 'modules/saas/uploads/mock-1.png', 'Start Live Demo', '', NULL, NULL, '', '', NULL, 1);
INSERT INTO `tbl_saas_front_slider` (`id`, `title`, `subtitle`, `description`, `slider_bg`, `slider_img`, `button_text_1`, `button_text_2`, `button_icon_1`, `button_icon_2`, `button_link_1`, `button_link_2`, `sort`, `status`) VALUES (3, 'Financial Service', 'Try trial first!', '<div class=\"slider-intro-list mb-40\">                                        <ul>\n                                            <li><span class=\"fal fa-check\"></span>Unlimited Projects.</li>\n                                            <li><span class=\"fal fa-check\"></span>Unlimited Team Members.</li>\n                                            <li><span class=\"fal fa-check\"></span>Unlimited Disk Space.</li>\n                                        </ul>\n                                    </div>', 'modules/saas/uploads/wonderfull-bg01.jpg', 'modules/saas/uploads/imac.png', 'See Live Demp', '14 days free trial', NULL, NULL, '', '', NULL, 1);
INSERT INTO `tbl_saas_front_slider` (`id`, `title`, `subtitle`, `description`, `slider_bg`, `slider_img`, `button_text_1`, `button_text_2`, `button_icon_1`, `button_icon_2`, `button_link_1`, `button_link_2`, `sort`, `status`) VALUES (4, 'Powerful services', 'We believe we have created the most efficient SaaS landing page for your users', '                                                                                                <div class=\"slider-intro-list mb-40\">                                        <ul>                                            <li><span class=\"fal fa-check\"></span> Unlimited Expense.</li>                                            <li><span class=\"fal fa-check\"></span> Unlimited Transaction.</li>                                            <li><span class=\"fal fa-check\"></span>Unlimited Deposit.</li><li><span class=\"fal fa-check\"></span>Unlimited Transfer.</li>                                        </ul>                                    </div>                                                                                    ', 'modules/saas/uploads/login_cover.jpg', 'modules/saas/uploads/dashboard-2.png', 'Take Off', '10 days free trial', NULL, NULL, '', '', NULL, 1);


#
# TABLE STRUCTURE FOR: tbl_saas_menu
#

DROP TABLE IF EXISTS `tbl_saas_menu`;

CREATE TABLE `tbl_saas_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 0,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(1) DEFAULT 1 COMMENT '1= active 0=inactive',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (1, 'dashboard', 'saas', 'fa fa-dashboard', 0, 1, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (2, 'packages', 'saas/packages', 'fa fa-shield', 0, 2, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (3, 'companies', 'saas/companies', 'icon icon-people', 0, 3, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (4, 'invoices', 'saas/companies/invoices', 'fa fa-book', 0, 4, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (5, 'super_admin', 'saas/super_admin', 'icon icon-people', 0, 5, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (7, 'settings', 'saas/settings', 'fa fa-gears', 0, 7, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (8, 'faq', 'saas/faq', 'fa fa-user-md', 0, 8, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (9, 'coupon', 'saas/coupon', 'fa fa-gift', 0, 6, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (10, 'assign_package', 'assignPackage', 'fa fa-sign-in', 0, 2, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (11, 'frontcms', '#', 'fa fa-empire', 0, 6, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (12, 'menu', 'saas/frontcms/menus', 'fa fa-outdent', 11, 0, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (13, 'mpage', 'saas/frontcms/page', 'fa fa-table', 11, 1, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (14, 'media', 'saas/frontcms/media', 'fa fa-image', 11, 2, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (15, 'slider', 'saas/frontcms/settings/slider', 'fa fa-sliders', 11, 3, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (16, 'settings', 'saas/frontcms/settings', 'fa fa-cogs', 11, 5, '2022-11-20 11:56:39', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (17, 'abouts', 'saas/frontcms/abouts', 'fa fa-circle-o', 11, 10, '2023-07-18 16:28:48', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (18, 'features', 'saas/frontcms/features', 'fa fa-circle-o', 11, 9, '2023-07-18 16:28:51', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (19, 'discovers', 'saas/frontcms/discovers', 'fa fa-circle-o', 11, 8, '2023-07-18 16:28:53', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (20, 'creatives', 'saas/frontcms/creatives', 'fa fa-circle-o', 11, 7, '2023-07-18 16:28:56', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (21, 'blogs', 'saas/frontcms/blogs', 'fa fa-circle-o', 11, 6, '2023-07-18 16:28:58', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (22, 'gallery', 'saas/frontcms/gallery', 'fa fa-circle-o', 11, 14, '2023-07-18 16:29:01', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (23, 'brand', 'saas/frontcms/brand', 'fa fa-circle-o', 11, 10, '2023-07-18 16:29:03', 1);
INSERT INTO `tbl_saas_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (24, 'reviews', 'saas/frontcms/reviews', 'fa fa-circle-o', 11, 9, '2023-07-18 16:29:11', 1);


#
# TABLE STRUCTURE FOR: tbl_saas_package_field
#

DROP TABLE IF EXISTS `tbl_saas_package_field`;

CREATE TABLE `tbl_saas_package_field` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `field_label` varchar(250) NOT NULL,
  `field_name` varchar(250) NOT NULL,
  `field_type` enum('text','textarea','checkbox','radio','date') NOT NULL DEFAULT 'text',
  `help_text` varchar(250) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (1, 'staff', 'staff_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 1);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (2, 'client_no', 'client_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 4);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (3, 'leads', 'leads_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 5);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (4, 'expense', 'expense_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 6);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (5, 'tasks_no', 'tasks_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 7);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (6, 'projects', 'project_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 8);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (7, 'invoice_no', 'invoice_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 9);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (8, 'contracts', 'contract_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 10);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (9, 'estimates', 'estimate_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 11);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (10, 'credit_notes', 'credit_note_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 12);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (11, 'proposals', 'proposal_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 13);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (12, 'items', 'item_no', 'text', 'use 0 = unlimited and empty = not included', 'active', 14);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (13, 'tickets', 'tickets', 'text', 'use 0 = unlimited and empty = not included', 'active', 15);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (14, 'disk_space', 'disk_space', 'text', 'Include it with MB,GB,TB etc like 1GB.', 'active', 3);
INSERT INTO `tbl_saas_package_field` (`field_id`, `field_label`, `field_name`, `field_type`, `help_text`, `status`, `order`) VALUES (15, 'custom_domain', 'custom_domain', 'checkbox', '', 'active', 2);


#
# TABLE STRUCTURE FOR: tbl_saas_package_module
#

DROP TABLE IF EXISTS `tbl_saas_package_module`;

CREATE TABLE `tbl_saas_package_module` (
  `package_module_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(200) NOT NULL,
  `module_title` varchar(200) NOT NULL,
  `price` decimal(18,5) NOT NULL DEFAULT 0.00000,
  `preview_image` text DEFAULT NULL,
  `preview_video_url` text DEFAULT NULL,
  `descriptions` text DEFAULT NULL,
  `module_order` int(11) DEFAULT NULL,
  `status` enum('published','unpublished') DEFAULT 'published',
  PRIMARY KEY (`package_module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_package_module` (`package_module_id`, `module_name`, `module_title`, `price`, `preview_image`, `preview_video_url`, `descriptions`, `module_order`, `status`) VALUES (1, 'whatsapp_api', 'Whatsapp API', '3.00000', 'a:1:{i:0;a:2:{s:9:\"file_name\";s:12:\"whatsapp.jpg\";s:8:\"filetype\";s:10:\"image/jpeg\";}}', NULL, '<p>Modulo para conectar tu sistema con Whatsapp por medio de la API oficial.</p>', 1, 'published');


#
# TABLE STRUCTURE FOR: tbl_saas_packages
#

DROP TABLE IF EXISTS `tbl_saas_packages`;

CREATE TABLE `tbl_saas_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `monthly_price` decimal(18,2) DEFAULT 0.00,
  `lifetime_price` decimal(18,2) DEFAULT 0.00,
  `yearly_price` decimal(18,2) DEFAULT 0.00,
  `sort` int(11) DEFAULT NULL,
  `staff_no` varchar(20) DEFAULT NULL,
  `additional_staff_no` varchar(20) DEFAULT NULL,
  `client_no` varchar(20) DEFAULT NULL,
  `additional_client_no` varchar(20) DEFAULT NULL,
  `project_no` varchar(20) DEFAULT NULL,
  `additional_project_no` varchar(20) DEFAULT NULL,
  `invoice_no` varchar(20) DEFAULT NULL,
  `additional_invoice_no` varchar(20) DEFAULT NULL,
  `leads_no` varchar(50) DEFAULT NULL,
  `additional_leads_no` varchar(50) DEFAULT NULL,
  `expense_no` varchar(50) DEFAULT NULL,
  `additional_expense_no` varchar(50) DEFAULT NULL,
  `contract_no` varchar(50) DEFAULT NULL,
  `additional_contract_no` varchar(50) DEFAULT NULL,
  `estimate_no` varchar(50) NOT NULL,
  `additional_estimate_no` varchar(50) DEFAULT NULL,
  `calendar` varchar(50) DEFAULT NULL,
  `credit_note_no` varchar(50) DEFAULT NULL,
  `additional_credit_note_no` varchar(50) DEFAULT NULL,
  `proposal_no` varchar(50) DEFAULT NULL,
  `additional_proposal_no` varchar(50) DEFAULT NULL,
  `tickets` varchar(50) DEFAULT NULL,
  `additional_tickets` varchar(50) DEFAULT NULL,
  `tasks_no` varchar(50) DEFAULT NULL,
  `additional_tasks_no` varchar(50) DEFAULT NULL,
  `item_no` varchar(50) DEFAULT NULL,
  `additional_item_no` varchar(50) DEFAULT NULL,
  `reports` varchar(50) DEFAULT NULL,
  `disk_space` varchar(100) DEFAULT NULL,
  `additional_disk_space` varchar(100) DEFAULT NULL,
  `trial_period` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `recommended` enum('Yes','No') DEFAULT 'No',
  `trail_period` varchar(20) DEFAULT NULL,
  `allowed_payment_modes` text DEFAULT NULL,
  `modules` text DEFAULT NULL,
  `allowed_themes` text DEFAULT NULL,
  `disabled_modules` text DEFAULT NULL,
  `custom_domain` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `tbl_saas_packages` (`id`, `name`, `monthly_price`, `lifetime_price`, `yearly_price`, `sort`, `staff_no`, `additional_staff_no`, `client_no`, `additional_client_no`, `project_no`, `additional_project_no`, `invoice_no`, `additional_invoice_no`, `leads_no`, `additional_leads_no`, `expense_no`, `additional_expense_no`, `contract_no`, `additional_contract_no`, `estimate_no`, `additional_estimate_no`, `calendar`, `credit_note_no`, `additional_credit_note_no`, `proposal_no`, `additional_proposal_no`, `tickets`, `additional_tickets`, `tasks_no`, `additional_tasks_no`, `item_no`, `additional_item_no`, `reports`, `disk_space`, `additional_disk_space`, `trial_period`, `description`, `status`, `recommended`, `trail_period`, `allowed_payment_modes`, `modules`, `allowed_themes`, `disabled_modules`, `custom_domain`) VALUES (2, 'FREE', '0.00', '0.00', '0.00', 3, '20', '3', '5', '3', '', NULL, '', NULL, '', NULL, '', NULL, '', NULL, '', NULL, 'Yes', '', NULL, '', NULL, '2', NULL, '', NULL, '', NULL, 'Yes', '', NULL, '365', 'FREE', 'published', 'Yes', NULL, 'a:1:{i:0;s:1:\"1\";}', 'a:20:{i:0;s:10:\"accounting\";i:1;s:28:\"advanced_task_status_manager\";i:2;s:12:\"si_timesheet\";i:3;s:7:\"exports\";i:4;s:6:\"backup\";i:5;s:5:\"goals\";i:6;s:10:\"hr_profile\";i:7;s:3:\"hrm\";i:8;s:10:\"menu_setup\";i:9;s:8:\"purchase\";i:10;s:11:\"recruitment\";i:11;s:9:\"styleflow\";i:12;s:7:\"surveys\";i:13;s:14:\"task_bookmarks\";i:14;s:11:\"theme_style\";i:15;s:10:\"timesheets\";i:16;s:12:\"translations\";i:17;s:9:\"warehouse\";i:18;s:12:\"whatsapp_api\";i:19;s:4:\"wiki\";}', 'a:10:{i:0;s:7:\"appline\";i:1;s:7:\"appvila\";i:2;s:5:\"basic\";i:3;s:4:\"cube\";i:4;s:5:\"intro\";i:5;s:4:\"nova\";i:6;s:8:\"open-pro\";i:7;s:4:\"play\";i:8;s:4:\"qest\";i:9;s:4:\"tidy\";}', 'a:0:{}', 'Yes');
INSERT INTO `tbl_saas_packages` (`id`, `name`, `monthly_price`, `lifetime_price`, `yearly_price`, `sort`, `staff_no`, `additional_staff_no`, `client_no`, `additional_client_no`, `project_no`, `additional_project_no`, `invoice_no`, `additional_invoice_no`, `leads_no`, `additional_leads_no`, `expense_no`, `additional_expense_no`, `contract_no`, `additional_contract_no`, `estimate_no`, `additional_estimate_no`, `calendar`, `credit_note_no`, `additional_credit_note_no`, `proposal_no`, `additional_proposal_no`, `tickets`, `additional_tickets`, `tasks_no`, `additional_tasks_no`, `item_no`, `additional_item_no`, `reports`, `disk_space`, `additional_disk_space`, `trial_period`, `description`, `status`, `recommended`, `trail_period`, `allowed_payment_modes`, `modules`, `allowed_themes`, `disabled_modules`, `custom_domain`) VALUES (5, 'Plan Emprendedor', '5.00', '300.00', '45.00', 5, '10', '3', '25', NULL, '0', NULL, '0', NULL, '0', NULL, '0', NULL, '0', NULL, '0', NULL, 'No', '0', NULL, '0', NULL, '0', NULL, '0', NULL, '0', NULL, 'Yes', '3GB', '5', '90', 'Si tu negocio esta en crecimiento, nuestro ERP es la solucion ideal!', 'published', 'No', NULL, 'a:1:{i:0;s:1:\"1\";}', 'a:2:{i:0;s:10:\"accounting\";i:1;s:8:\"purchase\";}', 'a:1:{i:0;s:4:\"cube\";}', 'a:0:{}', NULL);


#
# TABLE STRUCTURE FOR: tbl_saas_temp_payment
#

DROP TABLE IF EXISTS `tbl_saas_temp_payment`;

CREATE TABLE `tbl_saas_temp_payment` (
  `temp_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `companies_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `billing_cycle` varchar(30) NOT NULL,
  `expired_date` varchar(30) NOT NULL,
  `coupon_code` varchar(30) DEFAULT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `clientid` int(11) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `new_module` text DEFAULT NULL,
  `new_limit` text DEFAULT NULL,
  PRIMARY KEY (`temp_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblacc_account_history
#

DROP TABLE IF EXISTS `tblacc_account_history`;

CREATE TABLE `tblacc_account_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  `reconcile` int(11) NOT NULL DEFAULT 0,
  `split` int(11) NOT NULL DEFAULT 0,
  `item` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_accounts
#

DROP TABLE IF EXISTS `tblacc_accounts`;

CREATE TABLE `tblacc_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `parent_account` int(11) DEFAULT NULL,
  `account_type_id` int(11) NOT NULL,
  `account_detail_type_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT NULL,
  `balance_as_of` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default_account` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_banking_rule_details
#

DROP TABLE IF EXISTS `tblacc_banking_rule_details`;

CREATE TABLE `tblacc_banking_rule_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `subtype` varchar(45) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `subtype_amount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_banking_rules
#

DROP TABLE IF EXISTS `tblacc_banking_rules`;

CREATE TABLE `tblacc_banking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `following` varchar(45) DEFAULT NULL,
  `then` varchar(45) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `deposit_to` int(11) DEFAULT NULL,
  `auto_add` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_item_automatics
#

DROP TABLE IF EXISTS `tblacc_item_automatics`;

CREATE TABLE `tblacc_item_automatics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `inventory_asset_account` int(11) NOT NULL DEFAULT 0,
  `income_account` int(11) NOT NULL DEFAULT 0,
  `expense_account` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_journal_entries
#

DROP TABLE IF EXISTS `tblacc_journal_entries`;

CREATE TABLE `tblacc_journal_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `journal_date` date DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_reconciles
#

DROP TABLE IF EXISTS `tblacc_reconciles`;

CREATE TABLE `tblacc_reconciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `beginning_balance` decimal(15,2) NOT NULL,
  `ending_balance` decimal(15,2) NOT NULL,
  `ending_date` date NOT NULL,
  `expense_date` date DEFAULT NULL,
  `service_charge` decimal(15,2) DEFAULT NULL,
  `expense_account` int(11) DEFAULT NULL,
  `income_date` date DEFAULT NULL,
  `interest_earned` decimal(15,2) DEFAULT NULL,
  `income_account` int(11) DEFAULT NULL,
  `finish` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_tax_mappings
#

DROP TABLE IF EXISTS `tblacc_tax_mappings`;

CREATE TABLE `tblacc_tax_mappings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_id` int(11) NOT NULL,
  `payment_account` int(11) NOT NULL DEFAULT 0,
  `deposit_to` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_transaction_bankings
#

DROP TABLE IF EXISTS `tblacc_transaction_bankings`;

CREATE TABLE `tblacc_transaction_bankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `withdrawals` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deposits` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payee` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblacc_transfers
#

DROP TABLE IF EXISTS `tblacc_transfers`;

CREATE TABLE `tblacc_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_funds_from` int(11) NOT NULL,
  `transfer_funds_to` int(11) NOT NULL,
  `transfer_amount` decimal(15,2) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblactivity_log
#

DROP TABLE IF EXISTS `tblactivity_log`;

CREATE TABLE `tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (1, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 181.174.105.161]', '2024-12-15 20:12:46', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (2, 'Database Backup [database_backup_2024-12-15-20-47-04-v3-2-1.zip]', '2024-12-15 20:47:04', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (3, 'New Role Added [ID: 2.Huawei Site]', '2024-12-15 20:58:02', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (4, 'New Department Added [BODEGA, ID: 1]', '2024-12-15 21:00:01', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (5, 'New Department Added [COMPRAS, ID: 2]', '2024-12-15 21:00:08', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (6, 'New Department Added [VENTAS, ID: 3]', '2024-12-15 21:00:21', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (7, 'New Department Added [CONTABILIDAD, ID: 4]', '2024-12-15 21:00:31', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (8, 'New Customer Group Created [ID:1, Name:FTTH TIGO]', '2024-12-15 21:01:02', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (9, 'Project Status Updated [ID: 4, Name: Finalizado]', '2024-12-15 21:01:23', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (10, 'Task Status Updated [ID: 5, Name: Completo]', '2024-12-15 21:01:59', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (11, 'Package Status Changed [ID:4, Status0]', '2024-12-15 21:35:06', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (12, 'Package Status Changed [ID:1, Status0]', '2024-12-15 21:35:07', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (13, 'Package Status Changed [ID:3, Status0]', '2024-12-15 21:35:08', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (14, 'Package Status Changed [ID:5, Status0]', '2024-12-15 21:35:10', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (15, 'save footer left []', '2024-12-15 22:37:26', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (16, 'save contact [Email]', '2024-12-15 22:37:46', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (17, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 181.174.105.161]', '2024-12-16 20:44:24', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (18, 'Package Deleted [ID:4, NameBIZPLAN]', '2024-12-16 20:54:43', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (19, 'Package Deleted [ID:1, NameBIZTEAM]', '2024-12-16 20:54:47', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (20, 'Package Deleted [ID:3, NameFREE PLAN]', '2024-12-16 20:54:51', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (21, 'Package Status Changed [ID:5, Status1]', '2024-12-16 20:58:49', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (22, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 181.174.105.161]', '2024-12-18 19:55:40', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (23, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 181.174.105.161]', '2024-12-20 18:32:22', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (24, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 181.174.105.161]', '2024-12-21 09:10:41', 'Soporte SmartNet');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (25, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: 181.174.105.63]', '2024-12-30 16:48:48', 'Soporte SmartNet');


#
# TABLE STRUCTURE FOR: tblallowance_type
#

DROP TABLE IF EXISTS `tblallowance_type`;

CREATE TABLE `tblallowance_type` (
  `type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `allowance_val` decimal(15,2) NOT NULL,
  `taxable` tinyint(1) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblbonus_discipline
#

DROP TABLE IF EXISTS `tblbonus_discipline`;

CREATE TABLE `tblbonus_discipline` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `id_criteria` varchar(200) DEFAULT NULL,
  `type` int(3) NOT NULL,
  `apply_for` varchar(50) DEFAULT NULL,
  `from_time` datetime DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `url_file` longtext DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `id_admin` int(3) DEFAULT NULL,
  `status` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblbonus_discipline_detail
#

DROP TABLE IF EXISTS `tblbonus_discipline_detail`;

CREATE TABLE `tblbonus_discipline_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_bonus_discipline` int(11) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `department_id` longtext DEFAULT NULL,
  `lever_bonus` int(11) DEFAULT NULL,
  `formality` varchar(50) DEFAULT NULL,
  `formality_value` varchar(100) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcd_care
#

DROP TABLE IF EXISTS `tblcd_care`;

CREATE TABLE `tblcd_care` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `care_time` datetime NOT NULL,
  `care_result` text NOT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcd_family_infor
#

DROP TABLE IF EXISTS `tblcd_family_infor`;

CREATE TABLE `tblcd_family_infor` (
  `fi_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `fi_birthday` date DEFAULT NULL,
  `job` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` int(15) DEFAULT NULL,
  PRIMARY KEY (`fi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcd_interview
#

DROP TABLE IF EXISTS `tblcd_interview`;

CREATE TABLE `tblcd_interview` (
  `in_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `interview` int(11) NOT NULL,
  PRIMARY KEY (`in_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcd_literacy
#

DROP TABLE IF EXISTS `tblcd_literacy`;

CREATE TABLE `tblcd_literacy` (
  `li_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `literacy_from_date` date DEFAULT NULL,
  `literacy_to_date` date DEFAULT NULL,
  `diploma` varchar(200) DEFAULT NULL,
  `training_places` varchar(200) DEFAULT NULL,
  `specialized` varchar(200) DEFAULT NULL,
  `training_form` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`li_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcd_skill
#

DROP TABLE IF EXISTS `tblcd_skill`;

CREATE TABLE `tblcd_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `skill_name` text DEFAULT NULL,
  `skill_description` text DEFAULT NULL,
  PRIMARY KEY (`id`,`candidate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcd_work_experience
#

DROP TABLE IF EXISTS `tblcd_work_experience`;

CREATE TABLE `tblcd_work_experience` (
  `we_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `position` varchar(200) DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `salary` varchar(200) DEFAULT NULL,
  `reason_quitwork` varchar(200) DEFAULT NULL,
  `job_description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`we_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblcheck_in_out
#

DROP TABLE IF EXISTS `tblcheck_in_out`;

CREATE TABLE `tblcheck_in_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type_check` int(11) DEFAULT NULL,
  `type` varchar(5) NOT NULL DEFAULT 'W',
  `route_point_id` int(11) DEFAULT NULL,
  `workplace_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblchecklist
#

DROP TABLE IF EXISTS `tblchecklist`;

CREATE TABLE `tblchecklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblchecklist_allocation
#

DROP TABLE IF EXISTS `tblchecklist_allocation`;

CREATE TABLE `tblchecklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `saas_company_id` int(11) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblconsent_purposes
#

DROP TABLE IF EXISTS `tblconsent_purposes`;

CREATE TABLE `tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblconsents
#

DROP TABLE IF EXISTS `tblconsents`;

CREATE TABLE `tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `opt_in_purpose_description` mediumtext DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontact_permissions
#

DROP TABLE IF EXISTS `tblcontact_permissions`;

CREATE TABLE `tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontract_comments
#

DROP TABLE IF EXISTS `tblcontract_comments`;

CREATE TABLE `tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontract_renewals
#

DROP TABLE IF EXISTS `tblcontract_renewals`;

CREATE TABLE `tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `contacts_sent_to` mediumtext DEFAULT NULL,
  `last_sign_reminder_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcontracts_types
#

DROP TABLE IF EXISTS `tblcontracts_types`;

CREATE TABLE `tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcountries
#

DROP TABLE IF EXISTS `tblcountries`;

CREATE TABLE `tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (1, 'AF', 'Afghanistan', 'Islamic Republic of Afghanistan', 'AFG', '004', 'yes', '93', '.af');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (2, 'AX', 'Aland Islands', '&Aring;land Islands', 'ALA', '248', 'no', '358', '.ax');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (3, 'AL', 'Albania', 'Republic of Albania', 'ALB', '008', 'yes', '355', '.al');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (4, 'DZ', 'Algeria', 'People\'s Democratic Republic of Algeria', 'DZA', '012', 'yes', '213', '.dz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (5, 'AS', 'American Samoa', 'American Samoa', 'ASM', '016', 'no', '1+684', '.as');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (6, 'AD', 'Andorra', 'Principality of Andorra', 'AND', '020', 'yes', '376', '.ad');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (7, 'AO', 'Angola', 'Republic of Angola', 'AGO', '024', 'yes', '244', '.ao');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (8, 'AI', 'Anguilla', 'Anguilla', 'AIA', '660', 'no', '1+264', '.ai');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (9, 'AQ', 'Antarctica', 'Antarctica', 'ATA', '010', 'no', '672', '.aq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (10, 'AG', 'Antigua and Barbuda', 'Antigua and Barbuda', 'ATG', '028', 'yes', '1+268', '.ag');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (11, 'AR', 'Argentina', 'Argentine Republic', 'ARG', '032', 'yes', '54', '.ar');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (12, 'AM', 'Armenia', 'Republic of Armenia', 'ARM', '051', 'yes', '374', '.am');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (13, 'AW', 'Aruba', 'Aruba', 'ABW', '533', 'no', '297', '.aw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (14, 'AU', 'Australia', 'Commonwealth of Australia', 'AUS', '036', 'yes', '61', '.au');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (15, 'AT', 'Austria', 'Republic of Austria', 'AUT', '040', 'yes', '43', '.at');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (16, 'AZ', 'Azerbaijan', 'Republic of Azerbaijan', 'AZE', '031', 'yes', '994', '.az');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (17, 'BS', 'Bahamas', 'Commonwealth of The Bahamas', 'BHS', '044', 'yes', '1+242', '.bs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (18, 'BH', 'Bahrain', 'Kingdom of Bahrain', 'BHR', '048', 'yes', '973', '.bh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (19, 'BD', 'Bangladesh', 'People\'s Republic of Bangladesh', 'BGD', '050', 'yes', '880', '.bd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (20, 'BB', 'Barbados', 'Barbados', 'BRB', '052', 'yes', '1+246', '.bb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (21, 'BY', 'Belarus', 'Republic of Belarus', 'BLR', '112', 'yes', '375', '.by');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (22, 'BE', 'Belgium', 'Kingdom of Belgium', 'BEL', '056', 'yes', '32', '.be');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (23, 'BZ', 'Belize', 'Belize', 'BLZ', '084', 'yes', '501', '.bz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (24, 'BJ', 'Benin', 'Republic of Benin', 'BEN', '204', 'yes', '229', '.bj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (25, 'BM', 'Bermuda', 'Bermuda Islands', 'BMU', '060', 'no', '1+441', '.bm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (26, 'BT', 'Bhutan', 'Kingdom of Bhutan', 'BTN', '064', 'yes', '975', '.bt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (27, 'BO', 'Bolivia', 'Plurinational State of Bolivia', 'BOL', '068', 'yes', '591', '.bo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (28, 'BQ', 'Bonaire, Sint Eustatius and Saba', 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'no', '599', '.bq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (29, 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'BIH', '070', 'yes', '387', '.ba');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (30, 'BW', 'Botswana', 'Republic of Botswana', 'BWA', '072', 'yes', '267', '.bw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (31, 'BV', 'Bouvet Island', 'Bouvet Island', 'BVT', '074', 'no', 'NONE', '.bv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (32, 'BR', 'Brazil', 'Federative Republic of Brazil', 'BRA', '076', 'yes', '55', '.br');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (33, 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'IOT', '086', 'no', '246', '.io');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (34, 'BN', 'Brunei', 'Brunei Darussalam', 'BRN', '096', 'yes', '673', '.bn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (35, 'BG', 'Bulgaria', 'Republic of Bulgaria', 'BGR', '100', 'yes', '359', '.bg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (36, 'BF', 'Burkina Faso', 'Burkina Faso', 'BFA', '854', 'yes', '226', '.bf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (37, 'BI', 'Burundi', 'Republic of Burundi', 'BDI', '108', 'yes', '257', '.bi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (38, 'KH', 'Cambodia', 'Kingdom of Cambodia', 'KHM', '116', 'yes', '855', '.kh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (39, 'CM', 'Cameroon', 'Republic of Cameroon', 'CMR', '120', 'yes', '237', '.cm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (40, 'CA', 'Canada', 'Canada', 'CAN', '124', 'yes', '1', '.ca');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (41, 'CV', 'Cape Verde', 'Republic of Cape Verde', 'CPV', '132', 'yes', '238', '.cv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (42, 'KY', 'Cayman Islands', 'The Cayman Islands', 'CYM', '136', 'no', '1+345', '.ky');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (43, 'CF', 'Central African Republic', 'Central African Republic', 'CAF', '140', 'yes', '236', '.cf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (44, 'TD', 'Chad', 'Republic of Chad', 'TCD', '148', 'yes', '235', '.td');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (45, 'CL', 'Chile', 'Republic of Chile', 'CHL', '152', 'yes', '56', '.cl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (46, 'CN', 'China', 'People\'s Republic of China', 'CHN', '156', 'yes', '86', '.cn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (47, 'CX', 'Christmas Island', 'Christmas Island', 'CXR', '162', 'no', '61', '.cx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (48, 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'CCK', '166', 'no', '61', '.cc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (49, 'CO', 'Colombia', 'Republic of Colombia', 'COL', '170', 'yes', '57', '.co');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (50, 'KM', 'Comoros', 'Union of the Comoros', 'COM', '174', 'yes', '269', '.km');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (51, 'CG', 'Congo', 'Republic of the Congo', 'COG', '178', 'yes', '242', '.cg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (52, 'CK', 'Cook Islands', 'Cook Islands', 'COK', '184', 'some', '682', '.ck');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (53, 'CR', 'Costa Rica', 'Republic of Costa Rica', 'CRI', '188', 'yes', '506', '.cr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (54, 'CI', 'Cote d\'ivoire (Ivory Coast)', 'Republic of C&ocirc;te D\'Ivoire (Ivory Coast)', 'CIV', '384', 'yes', '225', '.ci');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (55, 'HR', 'Croatia', 'Republic of Croatia', 'HRV', '191', 'yes', '385', '.hr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (56, 'CU', 'Cuba', 'Republic of Cuba', 'CUB', '192', 'yes', '53', '.cu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (57, 'CW', 'Curacao', 'Cura&ccedil;ao', 'CUW', '531', 'no', '599', '.cw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (58, 'CY', 'Cyprus', 'Republic of Cyprus', 'CYP', '196', 'yes', '357', '.cy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (59, 'CZ', 'Czech Republic', 'Czech Republic', 'CZE', '203', 'yes', '420', '.cz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (60, 'CD', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo', 'COD', '180', 'yes', '243', '.cd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (61, 'DK', 'Denmark', 'Kingdom of Denmark', 'DNK', '208', 'yes', '45', '.dk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (62, 'DJ', 'Djibouti', 'Republic of Djibouti', 'DJI', '262', 'yes', '253', '.dj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (63, 'DM', 'Dominica', 'Commonwealth of Dominica', 'DMA', '212', 'yes', '1+767', '.dm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (64, 'DO', 'Dominican Republic', 'Dominican Republic', 'DOM', '214', 'yes', '1+809, 8', '.do');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (65, 'EC', 'Ecuador', 'Republic of Ecuador', 'ECU', '218', 'yes', '593', '.ec');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (66, 'EG', 'Egypt', 'Arab Republic of Egypt', 'EGY', '818', 'yes', '20', '.eg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (67, 'SV', 'El Salvador', 'Republic of El Salvador', 'SLV', '222', 'yes', '503', '.sv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (68, 'GQ', 'Equatorial Guinea', 'Republic of Equatorial Guinea', 'GNQ', '226', 'yes', '240', '.gq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (69, 'ER', 'Eritrea', 'State of Eritrea', 'ERI', '232', 'yes', '291', '.er');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (70, 'EE', 'Estonia', 'Republic of Estonia', 'EST', '233', 'yes', '372', '.ee');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (71, 'ET', 'Ethiopia', 'Federal Democratic Republic of Ethiopia', 'ETH', '231', 'yes', '251', '.et');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (72, 'FK', 'Falkland Islands (Malvinas)', 'The Falkland Islands (Malvinas)', 'FLK', '238', 'no', '500', '.fk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (73, 'FO', 'Faroe Islands', 'The Faroe Islands', 'FRO', '234', 'no', '298', '.fo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (74, 'FJ', 'Fiji', 'Republic of Fiji', 'FJI', '242', 'yes', '679', '.fj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (75, 'FI', 'Finland', 'Republic of Finland', 'FIN', '246', 'yes', '358', '.fi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (76, 'FR', 'France', 'French Republic', 'FRA', '250', 'yes', '33', '.fr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (77, 'GF', 'French Guiana', 'French Guiana', 'GUF', '254', 'no', '594', '.gf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (78, 'PF', 'French Polynesia', 'French Polynesia', 'PYF', '258', 'no', '689', '.pf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (79, 'TF', 'French Southern Territories', 'French Southern Territories', 'ATF', '260', 'no', NULL, '.tf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (80, 'GA', 'Gabon', 'Gabonese Republic', 'GAB', '266', 'yes', '241', '.ga');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (81, 'GM', 'Gambia', 'Republic of The Gambia', 'GMB', '270', 'yes', '220', '.gm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (82, 'GE', 'Georgia', 'Georgia', 'GEO', '268', 'yes', '995', '.ge');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (83, 'DE', 'Germany', 'Federal Republic of Germany', 'DEU', '276', 'yes', '49', '.de');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (84, 'GH', 'Ghana', 'Republic of Ghana', 'GHA', '288', 'yes', '233', '.gh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (85, 'GI', 'Gibraltar', 'Gibraltar', 'GIB', '292', 'no', '350', '.gi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (86, 'GR', 'Greece', 'Hellenic Republic', 'GRC', '300', 'yes', '30', '.gr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (87, 'GL', 'Greenland', 'Greenland', 'GRL', '304', 'no', '299', '.gl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (88, 'GD', 'Grenada', 'Grenada', 'GRD', '308', 'yes', '1+473', '.gd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (89, 'GP', 'Guadaloupe', 'Guadeloupe', 'GLP', '312', 'no', '590', '.gp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (90, 'GU', 'Guam', 'Guam', 'GUM', '316', 'no', '1+671', '.gu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (91, 'GT', 'Guatemala', 'Republic of Guatemala', 'GTM', '320', 'yes', '502', '.gt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (92, 'GG', 'Guernsey', 'Guernsey', 'GGY', '831', 'no', '44', '.gg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (93, 'GN', 'Guinea', 'Republic of Guinea', 'GIN', '324', 'yes', '224', '.gn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (94, 'GW', 'Guinea-Bissau', 'Republic of Guinea-Bissau', 'GNB', '624', 'yes', '245', '.gw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (95, 'GY', 'Guyana', 'Co-operative Republic of Guyana', 'GUY', '328', 'yes', '592', '.gy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (96, 'HT', 'Haiti', 'Republic of Haiti', 'HTI', '332', 'yes', '509', '.ht');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (97, 'HM', 'Heard Island and McDonald Islands', 'Heard Island and McDonald Islands', 'HMD', '334', 'no', 'NONE', '.hm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (98, 'HN', 'Honduras', 'Republic of Honduras', 'HND', '340', 'yes', '504', '.hn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (99, 'HK', 'Hong Kong', 'Hong Kong', 'HKG', '344', 'no', '852', '.hk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (100, 'HU', 'Hungary', 'Hungary', 'HUN', '348', 'yes', '36', '.hu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (101, 'IS', 'Iceland', 'Republic of Iceland', 'ISL', '352', 'yes', '354', '.is');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (102, 'IN', 'India', 'Republic of India', 'IND', '356', 'yes', '91', '.in');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (103, 'ID', 'Indonesia', 'Republic of Indonesia', 'IDN', '360', 'yes', '62', '.id');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (104, 'IR', 'Iran', 'Islamic Republic of Iran', 'IRN', '364', 'yes', '98', '.ir');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (105, 'IQ', 'Iraq', 'Republic of Iraq', 'IRQ', '368', 'yes', '964', '.iq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (106, 'IE', 'Ireland', 'Ireland', 'IRL', '372', 'yes', '353', '.ie');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (107, 'IM', 'Isle of Man', 'Isle of Man', 'IMN', '833', 'no', '44', '.im');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (108, 'IL', 'Israel', 'State of Israel', 'ISR', '376', 'yes', '972', '.il');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (109, 'IT', 'Italy', 'Italian Republic', 'ITA', '380', 'yes', '39', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (110, 'JM', 'Jamaica', 'Jamaica', 'JAM', '388', 'yes', '1+876', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (111, 'JP', 'Japan', 'Japan', 'JPN', '392', 'yes', '81', '.jp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (112, 'JE', 'Jersey', 'The Bailiwick of Jersey', 'JEY', '832', 'no', '44', '.je');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (113, 'JO', 'Jordan', 'Hashemite Kingdom of Jordan', 'JOR', '400', 'yes', '962', '.jo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (114, 'KZ', 'Kazakhstan', 'Republic of Kazakhstan', 'KAZ', '398', 'yes', '7', '.kz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (115, 'KE', 'Kenya', 'Republic of Kenya', 'KEN', '404', 'yes', '254', '.ke');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (116, 'KI', 'Kiribati', 'Republic of Kiribati', 'KIR', '296', 'yes', '686', '.ki');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (117, 'XK', 'Kosovo', 'Republic of Kosovo', '---', '---', 'some', '381', '');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (118, 'KW', 'Kuwait', 'State of Kuwait', 'KWT', '414', 'yes', '965', '.kw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (119, 'KG', 'Kyrgyzstan', 'Kyrgyz Republic', 'KGZ', '417', 'yes', '996', '.kg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (120, 'LA', 'Laos', 'Lao People\'s Democratic Republic', 'LAO', '418', 'yes', '856', '.la');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (121, 'LV', 'Latvia', 'Republic of Latvia', 'LVA', '428', 'yes', '371', '.lv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (122, 'LB', 'Lebanon', 'Republic of Lebanon', 'LBN', '422', 'yes', '961', '.lb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (123, 'LS', 'Lesotho', 'Kingdom of Lesotho', 'LSO', '426', 'yes', '266', '.ls');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (124, 'LR', 'Liberia', 'Republic of Liberia', 'LBR', '430', 'yes', '231', '.lr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (125, 'LY', 'Libya', 'Libya', 'LBY', '434', 'yes', '218', '.ly');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (126, 'LI', 'Liechtenstein', 'Principality of Liechtenstein', 'LIE', '438', 'yes', '423', '.li');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (127, 'LT', 'Lithuania', 'Republic of Lithuania', 'LTU', '440', 'yes', '370', '.lt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (128, 'LU', 'Luxembourg', 'Grand Duchy of Luxembourg', 'LUX', '442', 'yes', '352', '.lu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (129, 'MO', 'Macao', 'The Macao Special Administrative Region', 'MAC', '446', 'no', '853', '.mo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (130, 'MK', 'North Macedonia', 'Republic of North Macedonia', 'MKD', '807', 'yes', '389', '.mk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (131, 'MG', 'Madagascar', 'Republic of Madagascar', 'MDG', '450', 'yes', '261', '.mg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (132, 'MW', 'Malawi', 'Republic of Malawi', 'MWI', '454', 'yes', '265', '.mw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (133, 'MY', 'Malaysia', 'Malaysia', 'MYS', '458', 'yes', '60', '.my');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (134, 'MV', 'Maldives', 'Republic of Maldives', 'MDV', '462', 'yes', '960', '.mv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (135, 'ML', 'Mali', 'Republic of Mali', 'MLI', '466', 'yes', '223', '.ml');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (136, 'MT', 'Malta', 'Republic of Malta', 'MLT', '470', 'yes', '356', '.mt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (137, 'MH', 'Marshall Islands', 'Republic of the Marshall Islands', 'MHL', '584', 'yes', '692', '.mh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (138, 'MQ', 'Martinique', 'Martinique', 'MTQ', '474', 'no', '596', '.mq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (139, 'MR', 'Mauritania', 'Islamic Republic of Mauritania', 'MRT', '478', 'yes', '222', '.mr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (140, 'MU', 'Mauritius', 'Republic of Mauritius', 'MUS', '480', 'yes', '230', '.mu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (141, 'YT', 'Mayotte', 'Mayotte', 'MYT', '175', 'no', '262', '.yt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (142, 'MX', 'Mexico', 'United Mexican States', 'MEX', '484', 'yes', '52', '.mx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (143, 'FM', 'Micronesia', 'Federated States of Micronesia', 'FSM', '583', 'yes', '691', '.fm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (144, 'MD', 'Moldava', 'Republic of Moldova', 'MDA', '498', 'yes', '373', '.md');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (145, 'MC', 'Monaco', 'Principality of Monaco', 'MCO', '492', 'yes', '377', '.mc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (146, 'MN', 'Mongolia', 'Mongolia', 'MNG', '496', 'yes', '976', '.mn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (147, 'ME', 'Montenegro', 'Montenegro', 'MNE', '499', 'yes', '382', '.me');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (148, 'MS', 'Montserrat', 'Montserrat', 'MSR', '500', 'no', '1+664', '.ms');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (149, 'MA', 'Morocco', 'Kingdom of Morocco', 'MAR', '504', 'yes', '212', '.ma');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (150, 'MZ', 'Mozambique', 'Republic of Mozambique', 'MOZ', '508', 'yes', '258', '.mz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (151, 'MM', 'Myanmar (Burma)', 'Republic of the Union of Myanmar', 'MMR', '104', 'yes', '95', '.mm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (152, 'NA', 'Namibia', 'Republic of Namibia', 'NAM', '516', 'yes', '264', '.na');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (153, 'NR', 'Nauru', 'Republic of Nauru', 'NRU', '520', 'yes', '674', '.nr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (154, 'NP', 'Nepal', 'Federal Democratic Republic of Nepal', 'NPL', '524', 'yes', '977', '.np');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (155, 'NL', 'Netherlands', 'Kingdom of the Netherlands', 'NLD', '528', 'yes', '31', '.nl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (156, 'NC', 'New Caledonia', 'New Caledonia', 'NCL', '540', 'no', '687', '.nc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (157, 'NZ', 'New Zealand', 'New Zealand', 'NZL', '554', 'yes', '64', '.nz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (158, 'NI', 'Nicaragua', 'Republic of Nicaragua', 'NIC', '558', 'yes', '505', '.ni');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (159, 'NE', 'Niger', 'Republic of Niger', 'NER', '562', 'yes', '227', '.ne');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (160, 'NG', 'Nigeria', 'Federal Republic of Nigeria', 'NGA', '566', 'yes', '234', '.ng');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (161, 'NU', 'Niue', 'Niue', 'NIU', '570', 'some', '683', '.nu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (162, 'NF', 'Norfolk Island', 'Norfolk Island', 'NFK', '574', 'no', '672', '.nf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (163, 'KP', 'North Korea', 'Democratic People\'s Republic of Korea', 'PRK', '408', 'yes', '850', '.kp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (164, 'MP', 'Northern Mariana Islands', 'Northern Mariana Islands', 'MNP', '580', 'no', '1+670', '.mp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (165, 'NO', 'Norway', 'Kingdom of Norway', 'NOR', '578', 'yes', '47', '.no');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (166, 'OM', 'Oman', 'Sultanate of Oman', 'OMN', '512', 'yes', '968', '.om');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (167, 'PK', 'Pakistan', 'Islamic Republic of Pakistan', 'PAK', '586', 'yes', '92', '.pk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (168, 'PW', 'Palau', 'Republic of Palau', 'PLW', '585', 'yes', '680', '.pw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (169, 'PS', 'Palestine', 'State of Palestine (or Occupied Palestinian Territory)', 'PSE', '275', 'some', '970', '.ps');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (170, 'PA', 'Panama', 'Republic of Panama', 'PAN', '591', 'yes', '507', '.pa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (171, 'PG', 'Papua New Guinea', 'Independent State of Papua New Guinea', 'PNG', '598', 'yes', '675', '.pg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (172, 'PY', 'Paraguay', 'Republic of Paraguay', 'PRY', '600', 'yes', '595', '.py');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (173, 'PE', 'Peru', 'Republic of Peru', 'PER', '604', 'yes', '51', '.pe');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (174, 'PH', 'Philippines', 'Republic of the Philippines', 'PHL', '608', 'yes', '63', '.ph');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (175, 'PN', 'Pitcairn', 'Pitcairn', 'PCN', '612', 'no', 'NONE', '.pn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (176, 'PL', 'Poland', 'Republic of Poland', 'POL', '616', 'yes', '48', '.pl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (177, 'PT', 'Portugal', 'Portuguese Republic', 'PRT', '620', 'yes', '351', '.pt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (178, 'PR', 'Puerto Rico', 'Commonwealth of Puerto Rico', 'PRI', '630', 'no', '1+939', '.pr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (179, 'QA', 'Qatar', 'State of Qatar', 'QAT', '634', 'yes', '974', '.qa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (180, 'RE', 'Reunion', 'R&eacute;union', 'REU', '638', 'no', '262', '.re');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (181, 'RO', 'Romania', 'Romania', 'ROU', '642', 'yes', '40', '.ro');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (182, 'RU', 'Russia', 'Russian Federation', 'RUS', '643', 'yes', '7', '.ru');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (183, 'RW', 'Rwanda', 'Republic of Rwanda', 'RWA', '646', 'yes', '250', '.rw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (184, 'BL', 'Saint Barthelemy', 'Saint Barth&eacute;lemy', 'BLM', '652', 'no', '590', '.bl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (185, 'SH', 'Saint Helena', 'Saint Helena, Ascension and Tristan da Cunha', 'SHN', '654', 'no', '290', '.sh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (186, 'KN', 'Saint Kitts and Nevis', 'Federation of Saint Christopher and Nevis', 'KNA', '659', 'yes', '1+869', '.kn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (187, 'LC', 'Saint Lucia', 'Saint Lucia', 'LCA', '662', 'yes', '1+758', '.lc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (188, 'MF', 'Saint Martin', 'Saint Martin', 'MAF', '663', 'no', '590', '.mf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (189, 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'SPM', '666', 'no', '508', '.pm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (190, 'VC', 'Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines', 'VCT', '670', 'yes', '1+784', '.vc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (191, 'WS', 'Samoa', 'Independent State of Samoa', 'WSM', '882', 'yes', '685', '.ws');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (192, 'SM', 'San Marino', 'Republic of San Marino', 'SMR', '674', 'yes', '378', '.sm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (193, 'ST', 'Sao Tome and Principe', 'Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'STP', '678', 'yes', '239', '.st');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (194, 'SA', 'Saudi Arabia', 'Kingdom of Saudi Arabia', 'SAU', '682', 'yes', '966', '.sa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (195, 'SN', 'Senegal', 'Republic of Senegal', 'SEN', '686', 'yes', '221', '.sn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (196, 'RS', 'Serbia', 'Republic of Serbia', 'SRB', '688', 'yes', '381', '.rs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (197, 'SC', 'Seychelles', 'Republic of Seychelles', 'SYC', '690', 'yes', '248', '.sc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (198, 'SL', 'Sierra Leone', 'Republic of Sierra Leone', 'SLE', '694', 'yes', '232', '.sl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (199, 'SG', 'Singapore', 'Republic of Singapore', 'SGP', '702', 'yes', '65', '.sg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (200, 'SX', 'Sint Maarten', 'Sint Maarten', 'SXM', '534', 'no', '1+721', '.sx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (201, 'SK', 'Slovakia', 'Slovak Republic', 'SVK', '703', 'yes', '421', '.sk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (202, 'SI', 'Slovenia', 'Republic of Slovenia', 'SVN', '705', 'yes', '386', '.si');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (203, 'SB', 'Solomon Islands', 'Solomon Islands', 'SLB', '090', 'yes', '677', '.sb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (204, 'SO', 'Somalia', 'Somali Republic', 'SOM', '706', 'yes', '252', '.so');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (205, 'ZA', 'South Africa', 'Republic of South Africa', 'ZAF', '710', 'yes', '27', '.za');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (206, 'GS', 'South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands', 'SGS', '239', 'no', '500', '.gs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (207, 'KR', 'South Korea', 'Republic of Korea', 'KOR', '410', 'yes', '82', '.kr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (208, 'SS', 'South Sudan', 'Republic of South Sudan', 'SSD', '728', 'yes', '211', '.ss');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (209, 'ES', 'Spain', 'Kingdom of Spain', 'ESP', '724', 'yes', '34', '.es');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (210, 'LK', 'Sri Lanka', 'Democratic Socialist Republic of Sri Lanka', 'LKA', '144', 'yes', '94', '.lk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (211, 'SD', 'Sudan', 'Republic of the Sudan', 'SDN', '729', 'yes', '249', '.sd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (212, 'SR', 'Suriname', 'Republic of Suriname', 'SUR', '740', 'yes', '597', '.sr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (213, 'SJ', 'Svalbard and Jan Mayen', 'Svalbard and Jan Mayen', 'SJM', '744', 'no', '47', '.sj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (214, 'SZ', 'Swaziland', 'Kingdom of Swaziland', 'SWZ', '748', 'yes', '268', '.sz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (215, 'SE', 'Sweden', 'Kingdom of Sweden', 'SWE', '752', 'yes', '46', '.se');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (216, 'CH', 'Switzerland', 'Swiss Confederation', 'CHE', '756', 'yes', '41', '.ch');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (217, 'SY', 'Syria', 'Syrian Arab Republic', 'SYR', '760', 'yes', '963', '.sy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (218, 'TW', 'Taiwan', 'Republic of China (Taiwan)', 'TWN', '158', 'former', '886', '.tw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (219, 'TJ', 'Tajikistan', 'Republic of Tajikistan', 'TJK', '762', 'yes', '992', '.tj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (220, 'TZ', 'Tanzania', 'United Republic of Tanzania', 'TZA', '834', 'yes', '255', '.tz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (221, 'TH', 'Thailand', 'Kingdom of Thailand', 'THA', '764', 'yes', '66', '.th');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (222, 'TL', 'Timor-Leste (East Timor)', 'Democratic Republic of Timor-Leste', 'TLS', '626', 'yes', '670', '.tl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (223, 'TG', 'Togo', 'Togolese Republic', 'TGO', '768', 'yes', '228', '.tg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (224, 'TK', 'Tokelau', 'Tokelau', 'TKL', '772', 'no', '690', '.tk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (225, 'TO', 'Tonga', 'Kingdom of Tonga', 'TON', '776', 'yes', '676', '.to');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (226, 'TT', 'Trinidad and Tobago', 'Republic of Trinidad and Tobago', 'TTO', '780', 'yes', '1+868', '.tt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (227, 'TN', 'Tunisia', 'Republic of Tunisia', 'TUN', '788', 'yes', '216', '.tn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (228, 'TR', 'Turkey', 'Republic of Turkey', 'TUR', '792', 'yes', '90', '.tr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (229, 'TM', 'Turkmenistan', 'Turkmenistan', 'TKM', '795', 'yes', '993', '.tm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (230, 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'TCA', '796', 'no', '1+649', '.tc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (231, 'TV', 'Tuvalu', 'Tuvalu', 'TUV', '798', 'yes', '688', '.tv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (232, 'UG', 'Uganda', 'Republic of Uganda', 'UGA', '800', 'yes', '256', '.ug');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (233, 'UA', 'Ukraine', 'Ukraine', 'UKR', '804', 'yes', '380', '.ua');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (234, 'AE', 'United Arab Emirates', 'United Arab Emirates', 'ARE', '784', 'yes', '971', '.ae');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (235, 'GB', 'United Kingdom', 'United Kingdom of Great Britain and Nothern Ireland', 'GBR', '826', 'yes', '44', '.uk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (236, 'US', 'United States', 'United States of America', 'USA', '840', 'yes', '1', '.us');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (237, 'UM', 'United States Minor Outlying Islands', 'United States Minor Outlying Islands', 'UMI', '581', 'no', 'NONE', 'NONE');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (238, 'UY', 'Uruguay', 'Eastern Republic of Uruguay', 'URY', '858', 'yes', '598', '.uy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (239, 'UZ', 'Uzbekistan', 'Republic of Uzbekistan', 'UZB', '860', 'yes', '998', '.uz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (240, 'VU', 'Vanuatu', 'Republic of Vanuatu', 'VUT', '548', 'yes', '678', '.vu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (241, 'VA', 'Vatican City', 'State of the Vatican City', 'VAT', '336', 'no', '39', '.va');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (242, 'VE', 'Venezuela', 'Bolivarian Republic of Venezuela', 'VEN', '862', 'yes', '58', '.ve');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (243, 'VN', 'Vietnam', 'Socialist Republic of Vietnam', 'VNM', '704', 'yes', '84', '.vn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (244, 'VG', 'Virgin Islands, British', 'British Virgin Islands', 'VGB', '092', 'no', '1+284', '.vg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (245, 'VI', 'Virgin Islands, US', 'Virgin Islands of the United States', 'VIR', '850', 'no', '1+340', '.vi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (246, 'WF', 'Wallis and Futuna', 'Wallis and Futuna', 'WLF', '876', 'no', '681', '.wf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (247, 'EH', 'Western Sahara', 'Western Sahara', 'ESH', '732', 'no', '212', '.eh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (248, 'YE', 'Yemen', 'Republic of Yemen', 'YEM', '887', 'yes', '967', '.ye');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (249, 'ZM', 'Zambia', 'Republic of Zambia', 'ZMB', '894', 'yes', '260', '.zm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (250, 'ZW', 'Zimbabwe', 'Republic of Zimbabwe', 'ZWE', '716', 'yes', '263', '.zw');


#
# TABLE STRUCTURE FOR: tblcreditnote_refunds
#

DROP TABLE IF EXISTS `tblcreditnote_refunds`;

CREATE TABLE `tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcreditnotes
#

DROP TABLE IF EXISTS `tblcreditnotes`;

CREATE TABLE `tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `formatted_number` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `clientnote` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `formatted_number` (`formatted_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcredits
#

DROP TABLE IF EXISTS `tblcredits`;

CREATE TABLE `tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `decimal_separator`, `thousand_separator`, `placement`, `isdefault`) VALUES (1, '$', 'USD', '.', ',', 'before', 1);
INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `decimal_separator`, `thousand_separator`, `placement`, `isdefault`) VALUES (2, 'â‚¬', 'EUR', ',', '.', 'before', 0);


#
# TABLE STRUCTURE FOR: tblcustomer_admins
#

DROP TABLE IF EXISTS `tblcustomer_admins`;

CREATE TABLE `tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` mediumtext NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcustomer_groups
#

DROP TABLE IF EXISTS `tblcustomer_groups`;

CREATE TABLE `tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcustomers_groups
#

DROP TABLE IF EXISTS `tblcustomers_groups`;

CREATE TABLE `tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (1, 'FTTH TIGO');


#
# TABLE STRUCTURE FOR: tblcustomfields
#

DROP TABLE IF EXISTS `tblcustomfields`;

CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` longtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblcustomfieldsvalues
#

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;

CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblday_off
#

DROP TABLE IF EXISTS `tblday_off`;

CREATE TABLE `tblday_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `off_reason` varchar(255) NOT NULL,
  `off_type` varchar(100) NOT NULL,
  `break_date` date NOT NULL,
  `timekeeping` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `repeat_by_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` longtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  `manager_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `folder`, `delete_after_import`, `calendar_id`, `hidefromclient`, `manager_id`, `parent_id`) VALUES (1, 'BODEGA', 'soporte@smartnetgt.com', '', 0, '', '', '', 'INBOX', 0, NULL, 1, 0, 0);
INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `folder`, `delete_after_import`, `calendar_id`, `hidefromclient`, `manager_id`, `parent_id`) VALUES (2, 'COMPRAS', '', '', 0, '', '', '', 'INBOX', 0, NULL, 1, 0, 0);
INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `folder`, `delete_after_import`, `calendar_id`, `hidefromclient`, `manager_id`, `parent_id`) VALUES (3, 'VENTAS', '', '', 0, '', '', '', 'INBOX', 0, NULL, 0, 0, 0);
INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `folder`, `delete_after_import`, `calendar_id`, `hidefromclient`, `manager_id`, `parent_id`) VALUES (4, 'CONTABILIDAD', '', '', 0, '', '', '', 'INBOX', 0, NULL, 1, 0, 0);


#
# TABLE STRUCTURE FOR: tbldismissed_announcements
#

DROP TABLE IF EXISTS `tbldismissed_announcements`;

CREATE TABLE `tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblemailtemplates
#

DROP TABLE IF EXISTS `tblemailtemplates`;

CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` longtext NOT NULL,
  `subject` longtext NOT NULL,
  `message` longtext NOT NULL,
  `fromname` longtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (1, 'client', 'new-client-created', 'english', 'New Contact Added/Registered (Welcome Email)', 'Welcome aboard', 'Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (2, 'invoice', 'invoice-send-to-client', 'english', 'Send Invoice to Customer', 'Invoice with number {invoice_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (3, 'ticket', 'new-ticket-opened-admin', 'english', 'New Ticket Opened (Opened by Staff, Sent to Customer)', 'New Support Ticket Opened', '<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br><br><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br><br><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br></span><br><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br><span style=\"font-size: 12pt;\">{ticket_message}</span><br><br><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br><br>Kind Regards,</span><br><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (4, 'ticket', 'ticket-reply', 'english', 'Ticket Reply (Sent to Customer)', 'New Ticket Reply', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (5, 'ticket', 'ticket-autoresponse', 'english', 'New Ticket Opened - Autoresponse', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (6, 'invoice', 'invoice-payment-recorded', 'english', 'Invoice Payment Recorded (Sent to Customer)', 'Invoice Payment Recorded', '<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (7, 'invoice', 'invoice-overdue-notice', 'english', 'Invoice Overdue Notice', 'Invoice Overdue Notice - {invoice_number}', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (8, 'invoice', 'invoice-already-send', 'english', 'Invoice Already Sent to Customer', 'Invoice # {invoice_number} ', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (9, 'ticket', 'new-ticket-created-staff', 'english', 'New Ticket Created (Opened by Customer, Sent to Staff Members)', 'New Ticket Created', '<p><span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (10, 'estimate', 'estimate-send-to-client', 'english', 'Send Estimate to Customer', 'Estimate # {estimate_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (11, 'ticket', 'ticket-reply-to-admin', 'english', 'Ticket Reply (Sent to Staff)', 'New Support Ticket Reply', '<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (12, 'estimate', 'estimate-already-send', 'english', 'Estimate Already Sent to Customer', 'Estimate # {estimate_number} ', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (13, 'contract', 'contract-expiration', 'english', 'Contract Expiration Reminder (Sent to Customer Contacts)', 'Contract Expiration Reminder', '<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (14, 'tasks', 'task-assigned', 'english', 'New Task Assigned (Sent to Staff)', 'New Task Assigned to You - {task_name}', '<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (15, 'tasks', 'task-added-as-follower', 'english', 'Staff Member Added as Follower on Task (Sent to Staff)', 'You are added as follower on task - {task_name}', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (16, 'tasks', 'task-commented', 'english', 'New Comment on Task (Sent to Staff)', 'New Comment on Task - {task_name}', 'Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (17, 'tasks', 'task-added-attachment', 'english', 'New Attachment(s) on Task (Sent to Staff)', 'New Attachment on Task - {task_name}', 'Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (18, 'estimate', 'estimate-declined-to-staff', 'english', 'Estimate Declined (Sent to Staff)', 'Customer Declined Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (19, 'estimate', 'estimate-accepted-to-staff', 'english', 'Estimate Accepted (Sent to Staff)', 'Customer Accepted Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (20, 'proposals', 'proposal-client-accepted', 'english', 'Customer Action - Accepted (Sent to Staff)', 'Customer Accepted Proposal', '<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (21, 'proposals', 'proposal-send-to-customer', 'english', 'Send Proposal to Customer', 'Proposal With Number {proposal_number} Created', 'Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (22, 'proposals', 'proposal-client-declined', 'english', 'Customer Action - Declined (Sent to Staff)', 'Client Declined Proposal', 'Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (23, 'proposals', 'proposal-client-thank-you', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting proposal', 'Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (24, 'proposals', 'proposal-comment-to-client', 'english', 'New Comment Â (Sent to Customer/Lead)', 'New Proposal Comment', 'Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (25, 'proposals', 'proposal-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Proposal Comment', 'Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (26, 'estimate', 'estimate-thank-you-to-customer', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting estimate', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (27, 'tasks', 'task-deadline-notification', 'english', 'Task Deadline Reminder - Sent to Assigned Members', 'Task Deadline Reminder', 'Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (28, 'contract', 'send-contract', 'english', 'Send Contract to Customer', 'Contract - {contract_subject}', '<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (29, 'invoice', 'invoice-payment-recorded-to-staff', 'english', 'Invoice Payment Recorded (Sent to Staff)', 'New Invoice Payment', '<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (30, 'ticket', 'auto-close-ticket', 'english', 'Auto Close Ticket', 'Ticket Auto Closed', '<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (31, 'project', 'new-project-discussion-created-to-staff', 'english', 'New Project Discussion (Sent to Project Members)', 'New Project Discussion Created - {project_name}', '<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (32, 'project', 'new-project-discussion-created-to-customer', 'english', 'New Project Discussion (Sent to Customer Contacts)', 'New Project Discussion Created - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (33, 'project', 'new-project-file-uploaded-to-customer', 'english', 'New Project File(s) Uploaded (Sent to Customer Contacts)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (34, 'project', 'new-project-file-uploaded-to-staff', 'english', 'New Project File(s) Uploaded (Sent to Project Members)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (35, 'project', 'new-project-discussion-comment-to-customer', 'english', 'New Discussion Comment  (Sent to Customer Contacts)', 'New Discussion Comment', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (36, 'project', 'new-project-discussion-comment-to-staff', 'english', 'New Discussion Comment (Sent to Project Members)', 'New Discussion Comment', '<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (37, 'project', 'staff-added-as-project-member', 'english', 'Staff Added as Project Member', 'New project assigned to you', '<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (38, 'estimate', 'estimate-expiry-reminder', 'english', 'Estimate Expiration Reminder', 'Estimate Expiration Reminder', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (39, 'proposals', 'proposal-expiry-reminder', 'english', 'Proposal Expiration Reminder', 'Proposal Expiration Reminder', '<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (40, 'staff', 'new-staff-created', 'english', 'New Staff Created (Welcome Email)', 'You are added as staff member', 'Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (41, 'client', 'contact-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (42, 'client', 'contact-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (43, 'client', 'contact-set-password', 'english', 'Set New Password', 'Set new password on {companyname} ', '<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (44, 'staff', 'staff-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (45, 'staff', 'staff-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (46, 'project', 'assigned-to-project', 'english', 'New Project Created (Sent to Customer Contacts)', 'New Project Created', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (47, 'tasks', 'task-added-attachment-to-contacts', 'english', 'New Attachment(s) on Task (Sent to Customer Contacts)', 'New Attachment on Task - {task_name}', '<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (48, 'tasks', 'task-commented-to-contacts', 'english', 'New Comment on Task (Sent to Customer Contacts)', 'New Comment on Task - {task_name}', '<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (49, 'leads', 'new-lead-assigned', 'english', 'New Lead Assigned to Staff Member', 'New lead assigned to you', '<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (50, 'client', 'client-statement', 'english', 'Statement - Account Summary', 'Account Statement from {statement_from} to {statement_to}', 'Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (51, 'ticket', 'ticket-assigned-to-admin', 'english', 'New Ticket Assigned (Sent to Staff)', 'New support ticket has been assigned to you', '<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (52, 'client', 'new-client-registered-to-admin', 'english', 'New Customer Registration (Sent to admins)', 'New Customer Registration', 'Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (53, 'leads', 'new-web-to-lead-form-submitted', 'english', 'Web to lead form submitted - Sent to lead', '{lead_name} - We Received Your Request', 'Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (54, 'staff', 'two-factor-authentication', 'english', 'Two Factor Authentication', 'Confirm Your Login', '<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (55, 'project', 'project-finished-to-customer', 'english', 'Project Marked as Finished (Sent to Customer Contacts)', 'Project Marked as Finished', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (56, 'credit_note', 'credit-note-send-to-client', 'english', 'Send Credit Note To Email', 'Credit Note With Number #{credit_note_number} Created', 'Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (57, 'tasks', 'task-status-change-to-staff', 'english', 'Task Status Changed (Sent to Staff)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (58, 'tasks', 'task-status-change-to-contacts', 'english', 'Task Status Changed (Sent to Customer Contacts)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (59, 'staff', 'reminder-email-staff', 'english', 'Staff Reminder Email', 'You Have a New Reminder!', '<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (60, 'contract', 'contract-comment-to-client', 'english', 'New Comment Â (Sent to Customer Contacts)', 'New Contract Comment', 'Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (61, 'contract', 'contract-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Contract Comment', 'Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (62, 'subscriptions', 'send-subscription', 'english', 'Send Subscription to Customer', 'Subscription Created', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (63, 'subscriptions', 'subscription-payment-failed', 'english', 'Subscription Payment Failed', 'Your most recent invoice payment failed', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (64, 'subscriptions', 'subscription-canceled', 'english', 'Subscription Canceled (Sent to customer primary contact)', 'Your subscription has been canceled', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (65, 'subscriptions', 'subscription-payment-succeeded', 'english', 'Subscription Payment Succeeded (Sent to customer primary contact)', 'Subscription  Payment Receipt - {subscription_name}', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (66, 'contract', 'contract-expiration-to-staff', 'english', 'Contract Expiration Reminder (Sent to Staff)', 'Contract Expiration Reminder', 'Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (67, 'gdpr', 'gdpr-removal-request', 'english', 'Removal Request From Contact (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (68, 'gdpr', 'gdpr-removal-request-lead', 'english', 'Removal Request From Lead (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (69, 'client', 'client-registration-confirmed', 'english', 'Customer Registration Confirmed', 'Your registration is confirmed', '<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (70, 'contract', 'contract-signed-to-staff', 'english', 'Contract Signed (Sent to Staff)', 'Customer Signed a Contract', 'Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (71, 'subscriptions', 'customer-subscribed-to-staff', 'english', 'Customer Subscribed to a Subscription (Sent to administrators and subscription creator)', 'Customer Subscribed to a Subscription', 'The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (72, 'client', 'contact-verification-email', 'english', 'Email Verification (Sent to Contact After Registration)', 'Verify Email Address', '<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (73, 'client', 'new-customer-profile-file-uploaded-to-staff', 'english', 'New Customer Profile File(s) Uploaded (Sent to Staff)', 'Customer Uploaded New File(s) in Profile', 'Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (74, 'staff', 'event-notification-to-staff', 'english', 'Event Notification (Calendar)', 'Upcoming Event - {event_title}', 'Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.', '', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (75, 'subscriptions', 'subscription-payment-requires-action', 'english', 'Credit Card Authorization Required - SCA', 'Important: Confirm your subscription {subscription_name} payment', '<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (76, 'invoice', 'invoice-due-notice', 'english', 'Invoice Due Notice', 'Your {invoice_number} will be due soon', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (77, 'estimate_request', 'estimate-request-submitted-to-staff', 'english', 'Estimate Request Submitted (Sent to Staff)', 'New Estimate Request Submitted', '<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (78, 'estimate_request', 'estimate-request-assigned', 'english', 'Estimate Request Assigned (Sent to Staff)', 'New Estimate Request Assigned', '<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (79, 'estimate_request', 'estimate-request-received-to-user', 'english', 'Estimate Request Received (Sent to User)', 'Estimate Request Received', 'Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (80, 'notifications', 'non-billed-tasks-reminder', 'english', 'Non-billed tasks reminder (sent to selected staff members)', 'Action required: Completed tasks are not billed', 'Hello {staff_firstname}<br><br>The following tasks are marked as complete but not yet billed:<br><br>{unbilled_tasks_list}<br><br>Kind Regards,<br><br>{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (81, 'invoice', 'invoices-batch-payments', 'english', 'Invoices Payments Recorded in Batch (Sent to Customer)', 'We have received your payments', 'Hello {contact_firstname} {contact_lastname}<br><br>Thank you for the payments. Please find the payments details below:<br><br>{batch_payments_list}<br><br>We are looking forward working with you.<br><br>Kind Regards,<br><br>{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (82, 'contract', 'contract-sign-reminder', 'english', 'Contract Sign Reminder (Sent to Customer)', 'Contract Sign Reminder', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />This is a reminder to review and sign the contract:<a href=\"{contract_link}\">{contract_subject}</a></p><p>You can view and sign by visiting: <a href=\"{contract_link}\">{contract_subject}</a></p><p><br />We are looking forward working with you.<br /><br />Kind Regards,<br /><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (83, 'inventory_warning', 'inventory-warning-to-staff', 'english', 'Inventory warning (Sent to staff)', 'Inventory warning', 'Hi {staff_name}! <br /><br />This is a inventory warning<br />{<span 12pt=\"\">notification_content</span>}. <br /><br />Regards.', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (84, 'timesheets_attendance_mgt', 'attendance_notice', 'english', 'Attendance notice', 'Timesheets - Attendance notice', '{staff_name} {type_check} at {date_time}', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (85, 'timesheets_attendance_mgt', 'send_request_approval', 'english', 'Send request approval', 'Timesheets - Send request approval to approver', 'Hi {approver}! <br>-{staff_name} has created an apply for leave and requires your approval. Please go to this link for details and approval: {link}', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (86, 'timesheets_attendance_mgt', 'remind_user_check_in', 'english', 'Remind user check in', 'Timesheets - Remind user check in', 'Remind you to check in today to record the start time of the shift {date_time}', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (87, 'timesheets_attendance_mgt', 'new_leave_application_send_to_notification_recipient', 'english', 'New application (Send to notification recipient)', 'Timesheets - New application - Send to notification recipient', '{staff_name} created a new application {link} at {date_time}', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (88, 'saas', 'saas-welcome-mail', 'english', 'SaaS Welcome Email', 'Welcome aboard', 'Dear {name},<br/><br/>\r\n    Thank you for registering on the  <b>{companyname}</b> platform. We are happy to have you on board.<br/><br/> \r\n    We just wanted to say welcome. We are thrilled to have you on board and look forward to working with you.<br/><br/>\r\n    Please let us know if you have any questions or concerns. We are always happy to help.<br/><br/>\r\n    \r\n    <br/><br/>\r\n    Please click on the link below to activate your account.<br/><br/>\r\n    <big><strong><a href=\"{activation_url}\">Start your registration</a></strong></big><br/><br/>\r\n    link does not work? copy and paste this link into your browser:<br/>\r\n    <big><strong><a href=\"{activation_url}\">{activation_url}</a></strong></big><br/><br/>\r\n    \r\n    We listed your company details below, make sure you keep them safe your account details\r\n    <br/><br/>\r\n    please follow this link:<big><strong><a href=\"{company_url}\">View company url</a></strong></big><br/><br/>\r\n    link does not work? copy and paste this link into your browser:<br/>\r\n    <big><strong><a href=\"{company_url}\">{company_url}</a></strong></big><br/><br/>\r\n   \r\n    Best regards,<br/>\r\n    {email_signature}<br/>\r\n    (This is an automated email, so please do not reply to this.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (89, 'saas', 'saas-faq-request-email', 'english', 'SaaS FAQ Request Email', 'FAQ Request', 'Hi there,,<br/><br/>\r\n    {name} has requested a FAQ.<br/><br/>\r\n    <b>Question:</b><br/>\r\n    {question}<br/><br/>\r\n    \r\n    you can answer this question by clicking on the link below.<br/><br/>\r\n    <big><strong><a href=\"{faq_url}\">Answer this question</a></strong></big><br/><br/>\r\n    link does not work? copy and paste this link into your browser:<br/>\r\n    <big><strong><a href=\"{faq_url}\">{faq_url}</a></strong></big><br/><br/>\r\n    \r\n    Best regards,<br/>\r\n    {email_signature}<br/>\r\n    (This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (90, 'saas', 'saas-assign-new-package', 'english', 'SaaS Assign New Package', 'New Package', 'Dear {name},<br/><br/>\r\n    We have assigned a new package to your account.<br/><br/>\r\n    <b>Package:</b><br/>\r\n    {package_name}<br/><br/>\r\n    \r\n    Best regards,<br/>\r\n    {email_signature}<br/>\r\n    (This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (91, 'saas', 'saas-company-expiration-email', 'english', 'Company Expiration Email', '[Attention needed] - Company Expiration Reminder', 'Dear {name},<br/><br/>\r\nAs a valued user, we wanted to ensure you are aware of the upcoming expiration date for your company.<br/><br/>\r\nAs of {expiration_date}, your company will be expired.<br/><br/>\r\nto avoid any interruption in service, please renew your company as soon as possible.<br/><br/>\r\nby renewing your company, you will continue to enjoy all the benefits of your current plan.<br/><br/>\r\nto renew your company, please follow this link:<br/><br/>\r\n<big><strong><a href=\"{company_url}\">Renew your company</a></strong></big><br/><br/>\r\nlink does not work? copy and paste this link into your browser:<br/>\r\n<big><strong><a href=\"{company_url}\">{company_url}</a></strong></big><br/><br/>\r\n\r\n<strong>\r\n    If you have any questions or concerns, please do not hesitate to contact us. We are always happy to help.   \r\n</strong>\r\n<br/><br/>\r\n\r\nBest regards,<br/>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (92, 'saas', 'saas-inactive-company-email', 'english', 'Inactive Company Email', '[Attention] - your company is inactive soon! Please take action', 'Dear {name},<br/><br/>\r\nAs a valued user, we wanted to ensure you are aware of the upcoming expiration date for your company.<br/><br/>\r\n<strong>Despite our previous notifications,it seems that you have not renewed your company yet.</strong><br/><br/>\r\nAccording to our records, your company already expired on {expiration_date}.<br/><br/>\r\nUnfortunately, your company is inactive now.<br/><br/>\r\nto avoid any interruption in service, please renew your company as soon as possible.<br/><br/>\r\nby renewing your company, you will continue to enjoy all the benefits of your current plan.<br/><br/>\r\nto renew your company, please follow this link:<br/><br/>\r\n<big><strong><a href=\"{company_url}\">Renew your company</a></strong></big><br/><br/>\r\nlink does not work? copy and paste this link into your browser:<br/>\r\n<big><strong><a href=\"{company_url}\">{company_url}</a></strong></big><br/><br/>\r\n\r\nBest regards,<br/>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (93, 'saas', 'saas-company-url', 'english', 'Company URL', 'Company URL', 'Dear {name},<br/><br/>\r\nyou had requested your company URL.<br/><br/>\r\nso here is your company URL:<br/><br/>\r\n<big><strong><a href=\"{company_url}\">{company_url}</a></strong></big><br/><br/>\r\nlink does not work? copy and paste this link into your browser:<br/>\r\n<big><strong><a href=\"{company_url}\">{company_url}</a></strong></big><br/><br/>\r\n\r\nBest regards,<br/>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (94, 'affiliate', 'affiliate-verification-email', 'english', 'Email Verification (Sent to Affiliate User After Registration)', 'Verify Email Address', 'Dear {first_name},<br/><br/>\r\nThank you for registering with us.<br/><br/>\r\nPlease click on the link below to verify your email address and activate your account.<br/><br/>\r\n<big><strong><a href=\"{verification_url}\">Verify Email Address</a></strong></big><br/><br/>\r\nlink does not work? copy and paste this link into your browser:<br/>\r\n<big><strong><a href=\"{verification_url}\">{verification_url}</a></strong></big><br/><br/>\r\n\r\nBest regards,<br/>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (95, 'affiliate', 'affiliate-withdrawal-request', 'english', 'Affiliate Withdrawal Request (Sent to Super Admin)', 'Affiliate Withdrawal Request', 'Hello ,<br/><br/> \r\nan affiliate withdrawal request has been sent from {first_name} {last_name} <br/><br>\r\namount : {withdrawal_amount} <br/><br/>\r\n\r\ncheck your affiliation to get Withdrawal Request and you can approve or reject the request .\r\n\r\nBest regards,<br>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)\r\n', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (96, 'affiliate', 'affiliate-withdrawal-accepted', 'english', 'Affiliate Withdrawal Accepted (Sent to affiliate users)', 'Affiliate Withdrawal Accepted', 'Dear {first_name} <br/><br/>\r\nyour affiliate withdraw request has been accepted.\r\n\r\nyou can view the request from your affiliation portal .\r\n\r\n\r\nBest regards,<br/>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (97, 'affiliate', 'affiliate-withdrawal-declined', 'english', 'Affiliate Withdrawal Declined (Sent to affiliate users)', 'Affiliate Withdrawal Declined', 'Dear {first_name} <br/><br/>\r\nyour affiliate withdraw request has been declined.\r\n\r\nyou can view the request from your affiliation portal .\r\n\r\n\r\nBest regards,<br/>\r\n{email_signature}<br/>\r\n(This is an automated email, so please do not reply to it.)', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (98, 'approve', 'send-request-approve', 'english', 'Send Approval Request', 'Require Approval', '<p>Hi {staff_firstname}<br /><br />You have received a request to approve the {object_type}.<br /><br />You can view the {object_type} on the following link <a href=\"{object_link}\">{object_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (99, 'approve', 'send-request-approve', 'vietnamese', 'Gửi yêu cầu phê duyệt', 'Yêu cầu phê duyệt', 'Xin ch&agrave;o {staff_firstname} {staff_lastname}<br /><br />Bạn đã nhận được yêu cầu phê duyệt {object_type} mới.<br /><br />Bạn c&oacute; thể xem hóa đơn tại đ&acirc;y&nbsp;<a href=\"{object_link}\">{object_name}</a><br /><br />{email_signature}', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (100, 'approve', 'send_rejected', 'english', 'Send Rejected', 'The {object_type} has been rejected', '<p>Hi {staff_firstname}<br /><br />Your {object_type} has been rejected.<br /><br />You can view the {object_type} on the following link <a href=\"{object_link}\">{object_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (101, 'approve', 'send_rejected', 'vietnamese', 'Gửi từ chối', '{object_type} đã bị từ chối', 'Xin ch&agrave;o {staff_firstname} {staff_lastname}<br /><br />{object_type} của bạn đã bị từ chối.<br /><br />Bạn c&oacute; thể xem {object_type} tại đ&acirc;y&nbsp;<a href=\"{object_link}\">{object_name}</a><br /><br />{email_signature}', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (102, 'approve', 'send_approve', 'english', 'Send Approve', 'The {object_type} has been approved', '<p>Hi {staff_firstname}<br /><br />Your {object_type} has been approved.<br /><br />You can view the {object_type} on the following link <a href=\"{object_link}\">{object_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (103, 'approve', 'send_approve', 'vietnamese', 'Gửi phê duyệt', '{object_type} đã được phê duyệt', 'Xin ch&agrave;o {staff_firstname} {staff_lastname}<br /><br />{object_type} của bạn đã được phê duyệt.<br /><br />Bạn c&oacute; thể xem {object_type} tại đ&acirc;y&nbsp;<a href=\"{object_link}\">{object_name}</a><br /><br />{email_signature}', '{companyname} | CRM', NULL, 0, 1, 0);


#
# TABLE STRUCTURE FOR: tblestimate_request_forms
#

DROP TABLE IF EXISTS `tblestimate_request_forms`;

CREATE TABLE `tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblestimate_request_status
#

DROP TABLE IF EXISTS `tblestimate_request_status`;

CREATE TABLE `tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (1, 'Cancelled', 1, '#808080', 'cancelled');
INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (2, 'Processing', 2, '#007bff', 'processing');
INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (3, 'Completed', 3, '#28a745', 'completed');


#
# TABLE STRUCTURE FOR: tblestimate_requests
#

DROP TABLE IF EXISTS `tblestimate_requests`;

CREATE TABLE `tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `formatted_number` varchar(100) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`),
  KEY `formatted_number` (`formatted_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblevents
#

DROP TABLE IF EXISTS `tblevents`;

CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblexpenses_categories
#

DROP TABLE IF EXISTS `tblexpenses_categories`;

CREATE TABLE `tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblfiles
#

DROP TABLE IF EXISTS `tblfiles`;

CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblfilter_defaults
#

DROP TABLE IF EXISTS `tblfilter_defaults`;

CREATE TABLE `tblfilter_defaults` (
  `filter_id` int(10) unsigned NOT NULL,
  `staff_id` int(11) NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `view` varchar(191) NOT NULL,
  KEY `filter_id` (`filter_id`),
  KEY `staff_id` (`staff_id`),
  CONSTRAINT `tblfilter_defaults_ibfk_1` FOREIGN KEY (`filter_id`) REFERENCES `tblfilters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tblfilter_defaults_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `tblstaff` (`staffid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblfilters
#

DROP TABLE IF EXISTS `tblfilters`;

CREATE TABLE `tblfilters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `builder` mediumtext NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `identifier` varchar(191) NOT NULL,
  `is_shared` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_question_box
#

DROP TABLE IF EXISTS `tblform_question_box`;

CREATE TABLE `tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_question_box_description
#

DROP TABLE IF EXISTS `tblform_question_box_description`;

CREATE TABLE `tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `boxid` longtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_questions
#

DROP TABLE IF EXISTS `tblform_questions`;

CREATE TABLE `tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` longtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblform_results
#

DROP TABLE IF EXISTS `tblform_results`;

CREATE TABLE `tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` mediumtext DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblgdpr_requests
#

DROP TABLE IF EXISTS `tblgdpr_requests`;

CREATE TABLE `tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblgoals
#

DROP TABLE IF EXISTS `tblgoals`;

CREATE TABLE `tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT 0,
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT 1,
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT 1,
  `notified` int(11) NOT NULL DEFAULT 0,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgoods_delivery
#

DROP TABLE IF EXISTS `tblgoods_delivery`;

CREATE TABLE `tblgoods_delivery` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_type` int(11) DEFAULT NULL COMMENT 'type goods delivery',
  `rel_document` int(11) DEFAULT NULL COMMENT 'document id of goods delivery',
  `customer_code` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `to_` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL COMMENT 'the reason delivery',
  `staff_id` int(11) DEFAULT NULL COMMENT 'salesman',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_delivery_code` varchar(100) DEFAULT NULL COMMENT 'số chứng từ xuất kho',
  `warehouse_id` int(11) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_discount` varchar(100) DEFAULT NULL,
  `after_discount` varchar(100) DEFAULT NULL,
  `invoice_id` varchar(100) DEFAULT NULL,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL,
  `type_of_delivery` varchar(100) DEFAULT 'total',
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `delivery_status` varchar(100) DEFAULT 'ready_for_packing',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgoods_delivery_detail
#

DROP TABLE IF EXISTS `tblgoods_delivery_detail`;

CREATE TABLE `tblgoods_delivery_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `total_money` varchar(200) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `available_quantity` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `total_after_discount` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `guarantee_period` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `packing_qty` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgoods_delivery_invoices_pr_orders
#

DROP TABLE IF EXISTS `tblgoods_delivery_invoices_pr_orders`;

CREATE TABLE `tblgoods_delivery_invoices_pr_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL COMMENT 'goods_delivery_id',
  `rel_type` int(11) DEFAULT NULL COMMENT 'invoice_id or purchase order id',
  `type` varchar(100) DEFAULT NULL COMMENT 'invoice,  purchase_orders',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgoods_receipt
#

DROP TABLE IF EXISTS `tblgoods_receipt`;

CREATE TABLE `tblgoods_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(100) DEFAULT NULL,
  `supplier_name` text DEFAULT NULL,
  `deliver_name` text DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `pr_order_id` int(11) DEFAULT NULL COMMENT 'code puchase request agree',
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `goods_receipt_code` varchar(100) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `total_tax_money` varchar(100) DEFAULT NULL,
  `total_goods_money` varchar(100) DEFAULT NULL,
  `value_of_inventory` varchar(100) DEFAULT NULL,
  `total_money` varchar(100) DEFAULT NULL COMMENT 'total_money = total_tax_money +total_goods_money ',
  `addedfrom` int(11) DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `project` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `requester` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `invoice_no` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgoods_receipt_detail
#

DROP TABLE IF EXISTS `tblgoods_receipt_detail`;

CREATE TABLE `tblgoods_receipt_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `tax` varchar(100) DEFAULT NULL,
  `tax_money` varchar(100) DEFAULT NULL,
  `goods_money` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `discount_money` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgoods_transaction_detail
#

DROP TABLE IF EXISTS `tblgoods_transaction_detail`;

CREATE TABLE `tblgoods_transaction_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` int(11) DEFAULT NULL COMMENT 'id_goods_receipt_id or goods_delivery_id',
  `goods_id` int(11) NOT NULL COMMENT ' is id commodity',
  `old_quantity` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` text NOT NULL,
  `note` text DEFAULT NULL,
  `status` int(2) DEFAULT NULL COMMENT '1:Goods receipt note 2:Goods delivery note',
  `purchase_price` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `from_stock_name` int(11) DEFAULT NULL,
  `to_stock_name` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblgroup_checklist
#

DROP TABLE IF EXISTS `tblgroup_checklist`;

CREATE TABLE `tblgroup_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblgroup_checklist_allocation
#

DROP TABLE IF EXISTS `tblgroup_checklist_allocation`;

CREATE TABLE `tblgroup_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblhr_allocation_asset
#

DROP TABLE IF EXISTS `tblhr_allocation_asset`;

CREATE TABLE `tblhr_allocation_asset` (
  `allocation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `asset_name` varchar(100) DEFAULT NULL,
  `assets_amount` int(11) unsigned NOT NULL,
  `status_allocation` int(11) unsigned DEFAULT 0 COMMENT '1: Allocated 0: Unallocated',
  PRIMARY KEY (`allocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_allowance_type
#

DROP TABLE IF EXISTS `tblhr_allowance_type`;

CREATE TABLE `tblhr_allowance_type` (
  `type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `allowance_val` decimal(15,2) NOT NULL,
  `taxable` tinyint(1) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_checklist_allocation
#

DROP TABLE IF EXISTS `tblhr_checklist_allocation`;

CREATE TABLE `tblhr_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_dependent_person
#

DROP TABLE IF EXISTS `tblhr_dependent_person`;

CREATE TABLE `tblhr_dependent_person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) unsigned DEFAULT NULL,
  `dependent_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `dependent_bir` date DEFAULT NULL,
  `start_month` date DEFAULT NULL,
  `end_month` date DEFAULT NULL,
  `dependent_iden` varchar(20) NOT NULL,
  `reason` longtext DEFAULT NULL,
  `status` int(11) unsigned DEFAULT 0,
  `status_comment` longtext DEFAULT NULL,
  PRIMARY KEY (`id`,`dependent_iden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_education
#

DROP TABLE IF EXISTS `tblhr_education`;

CREATE TABLE `tblhr_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `programe_id` int(11) DEFAULT NULL,
  `training_programs_name` text NOT NULL,
  `training_places` text DEFAULT NULL,
  `training_time_from` datetime DEFAULT NULL,
  `training_time_to` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `training_result` varchar(150) DEFAULT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_group_checklist_allocation
#

DROP TABLE IF EXISTS `tblhr_group_checklist_allocation`;

CREATE TABLE `tblhr_group_checklist_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `meta` varchar(100) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_job_p
#

DROP TABLE IF EXISTS `tblhr_job_p`;

CREATE TABLE `tblhr_job_p` (
  `job_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_job_position
#

DROP TABLE IF EXISTS `tblhr_job_position`;

CREATE TABLE `tblhr_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `job_position_description` text DEFAULT NULL,
  `job_p_id` int(11) unsigned NOT NULL,
  `position_code` varchar(50) DEFAULT NULL,
  `department_id` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_jp_interview_training
#

DROP TABLE IF EXISTS `tblhr_jp_interview_training`;

CREATE TABLE `tblhr_jp_interview_training` (
  `training_process_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` longtext DEFAULT NULL,
  `training_name` varchar(100) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `position_training_id` text DEFAULT NULL,
  `mint_point` int(11) DEFAULT NULL,
  `additional_training` varchar(100) DEFAULT '',
  `staff_id` text DEFAULT NULL,
  `time_to_start` date DEFAULT NULL,
  `time_to_end` date DEFAULT NULL,
  PRIMARY KEY (`training_process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_jp_salary_scale
#

DROP TABLE IF EXISTS `tblhr_jp_salary_scale`;

CREATE TABLE `tblhr_jp_salary_scale` (
  `salary_scale_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_position_id` int(11) unsigned NOT NULL,
  `rel_type` varchar(100) DEFAULT NULL COMMENT 'salary:allowance:insurance',
  `rel_id` int(11) DEFAULT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`salary_scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_knowedge_base_article_feedback
#

DROP TABLE IF EXISTS `tblhr_knowedge_base_article_feedback`;

CREATE TABLE `tblhr_knowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_knowledge_base
#

DROP TABLE IF EXISTS `tblhr_knowledge_base`;

CREATE TABLE `tblhr_knowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_knowledge_base_groups
#

DROP TABLE IF EXISTS `tblhr_knowledge_base_groups`;

CREATE TABLE `tblhr_knowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_list_staff_quitting_work
#

DROP TABLE IF EXISTS `tblhr_list_staff_quitting_work`;

CREATE TABLE `tblhr_list_staff_quitting_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `staff_name` text DEFAULT NULL,
  `department_name` text DEFAULT NULL,
  `role_name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `dateoff` datetime NOT NULL DEFAULT current_timestamp(),
  `approval` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_p_t_form_question_box
#

DROP TABLE IF EXISTS `tblhr_p_t_form_question_box`;

CREATE TABLE `tblhr_p_t_form_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_p_t_form_question_box_description
#

DROP TABLE IF EXISTS `tblhr_p_t_form_question_box_description`;

CREATE TABLE `tblhr_p_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_p_t_form_results
#

DROP TABLE IF EXISTS `tblhr_p_t_form_results`;

CREATE TABLE `tblhr_p_t_form_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_p_t_surveyresultsets
#

DROP TABLE IF EXISTS `tblhr_p_t_surveyresultsets`;

CREATE TABLE `tblhr_p_t_surveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `trainingid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_position_training
#

DROP TABLE IF EXISTS `tblhr_position_training`;

CREATE TABLE `tblhr_position_training` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `training_type` int(11) unsigned NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `viewdescription` text DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT 0,
  `onlyforloggedin` int(11) DEFAULT 0,
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `hash` varchar(32) NOT NULL,
  `mint_point` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_position_training_question_form
#

DROP TABLE IF EXISTS `tblhr_position_training_question_form`;

CREATE TABLE `tblhr_position_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_procedure_retire
#

DROP TABLE IF EXISTS `tblhr_procedure_retire`;

CREATE TABLE `tblhr_procedure_retire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `people_handle_id` int(11) NOT NULL,
  `procedure_retire_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_procedure_retire_manage
#

DROP TABLE IF EXISTS `tblhr_procedure_retire_manage`;

CREATE TABLE `tblhr_procedure_retire_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_procedure_retire` text NOT NULL,
  `department` varchar(250) NOT NULL,
  `datecreator` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_procedure_retire_of_staff
#

DROP TABLE IF EXISTS `tblhr_procedure_retire_of_staff`;

CREATE TABLE `tblhr_procedure_retire_of_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `option_name` text DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_procedure_retire_of_staff_by_id
#

DROP TABLE IF EXISTS `tblhr_procedure_retire_of_staff_by_id`;

CREATE TABLE `tblhr_procedure_retire_of_staff_by_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` text DEFAULT NULL,
  `people_handle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_profile_option
#

DROP TABLE IF EXISTS `tblhr_profile_option`;

CREATE TABLE `tblhr_profile_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblhr_profile_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (1, 'job_position_prefix', '#JOB', 1);
INSERT INTO `tblhr_profile_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (2, 'job_position_number', '1', 1);
INSERT INTO `tblhr_profile_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (3, 'contract_code_prefix', '#CONTRACT', 1);
INSERT INTO `tblhr_profile_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (4, 'contract_code_number', '1', 1);
INSERT INTO `tblhr_profile_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (5, 'staff_code_prefix', 'EC', 1);
INSERT INTO `tblhr_profile_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (6, 'staff_code_number', '1', 1);


#
# TABLE STRUCTURE FOR: tblhr_rec_transfer_records
#

DROP TABLE IF EXISTS `tblhr_rec_transfer_records`;

CREATE TABLE `tblhr_rec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_salary_form
#

DROP TABLE IF EXISTS `tblhr_salary_form`;

CREATE TABLE `tblhr_salary_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `salary_val` decimal(15,2) NOT NULL,
  `tax` tinyint(1) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_staff_contract
#

DROP TABLE IF EXISTS `tblhr_staff_contract`;

CREATE TABLE `tblhr_staff_contract` (
  `id_contract` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_code` varchar(200) NOT NULL,
  `name_contract` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `start_valid` date DEFAULT NULL,
  `end_valid` date DEFAULT NULL,
  `contract_status` varchar(100) DEFAULT NULL,
  `sign_day` date DEFAULT NULL,
  `staff_delegate` int(11) DEFAULT NULL,
  `hourly_or_month` longtext DEFAULT NULL,
  PRIMARY KEY (`id_contract`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_staff_contract_detail
#

DROP TABLE IF EXISTS `tblhr_staff_contract_detail`;

CREATE TABLE `tblhr_staff_contract_detail` (
  `contract_detail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_contract_id` int(11) unsigned NOT NULL,
  `type` text DEFAULT NULL,
  `rel_type` text DEFAULT NULL,
  `rel_value` decimal(15,2) DEFAULT 0.00,
  `since_date` date DEFAULT NULL,
  `contract_note` text DEFAULT NULL,
  PRIMARY KEY (`contract_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_staff_contract_type
#

DROP TABLE IF EXISTS `tblhr_staff_contract_type`;

CREATE TABLE `tblhr_staff_contract_type` (
  `id_contracttype` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_contracttype` varchar(200) NOT NULL,
  `description` longtext DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `insurance` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_contracttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_training_allocation
#

DROP TABLE IF EXISTS `tblhr_training_allocation`;

CREATE TABLE `tblhr_training_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime NOT NULL DEFAULT current_timestamp(),
  `training_name` varchar(150) DEFAULT NULL,
  `jp_interview_training_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_type_of_trainings
#

DROP TABLE IF EXISTS `tblhr_type_of_trainings`;

CREATE TABLE `tblhr_type_of_trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblhr_type_of_trainings` (`id`, `name`) VALUES (1, 'Basic training');


#
# TABLE STRUCTURE FOR: tblhr_views_tracking
#

DROP TABLE IF EXISTS `tblhr_views_tracking`;

CREATE TABLE `tblhr_views_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhr_workplace
#

DROP TABLE IF EXISTS `tblhr_workplace`;

CREATE TABLE `tblhr_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblhrm_option
#

DROP TABLE IF EXISTS `tblhrm_option`;

CREATE TABLE `tblhrm_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (1, 'hrm_contract_form', '[]', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (2, 'hrm_leave_position', '[]', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (3, 'hrm_leave_contract_type', '[]', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (4, 'hrm_leave_start_date', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (5, 'hrm_max_leave_in_year', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (6, 'hrm_start_leave_from_month', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (7, 'hrm_start_leave_to_month', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (8, 'hrm_add_new_leave_month_from_date', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (9, 'hrm_accumulated_leave_to_month', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (10, 'hrm_leave_contract_sign_day', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (11, 'hrm_start_date_seniority', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (12, 'hrm_seniority_year', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (13, 'hrm_seniority_year_leave', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (14, 'hrm_next_year', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (15, 'hrm_next_year_leave', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (16, 'alow_borrow_leave', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (17, 'contract_type_borrow', '[]', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (18, 'max_leave_borrow', NULL, 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (19, 'day_increases_monthly', '15', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (20, 'sign_a_labor_contract', '1', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (21, 'maternity_leave_to_return_to_work', '1', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (22, 'unpaid_leave_to_return_to_work', '1', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (23, 'increase_the_premium', '1', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (24, 'day_decreases_monthly', '5', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (25, 'contract_paid_for_unemployment', '1', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (26, 'maternity_leave_regime', '1', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (27, 'unpaid_leave_of_more_than', '10', 1);
INSERT INTO `tblhrm_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (28, 'reduced_premiums', '1', 1);


#
# TABLE STRUCTURE FOR: tblhrm_timesheet
#

DROP TABLE IF EXISTS `tblhrm_timesheet`;

CREATE TABLE `tblhrm_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblinsurance_type
#

DROP TABLE IF EXISTS `tblinsurance_type`;

CREATE TABLE `tblinsurance_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_month` date NOT NULL,
  `social_company` varchar(15) DEFAULT NULL,
  `social_staff` varchar(15) DEFAULT NULL,
  `labor_accident_company` varchar(15) DEFAULT NULL,
  `labor_accident_staff` varchar(15) DEFAULT NULL,
  `health_company` varchar(15) DEFAULT NULL,
  `health_staff` varchar(15) DEFAULT NULL,
  `unemployment_company` varchar(15) DEFAULT NULL,
  `unemployment_staff` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblinternal_delivery_note
#

DROP TABLE IF EXISTS `tblinternal_delivery_note`;

CREATE TABLE `tblinternal_delivery_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_c` date DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `internal_delivery_code` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblinternal_delivery_note_detail
#

DROP TABLE IF EXISTS `tblinternal_delivery_note_detail`;

CREATE TABLE `tblinternal_delivery_note_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `internal_delivery_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `from_stock_name` text DEFAULT NULL,
  `to_stock_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `available_quantity` text DEFAULT NULL,
  `quantities` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `into_money` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblinventory_commodity_min
#

DROP TABLE IF EXISTS `tblinventory_commodity_min`;

CREATE TABLE `tblinventory_commodity_min` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` varchar(100) DEFAULT NULL,
  `inventory_number_min` varchar(100) DEFAULT NULL,
  `inventory_number_max` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`,`commodity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblinventory_manage
#

DROP TABLE IF EXISTS `tblinventory_manage`;

CREATE TABLE `tblinventory_manage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `commodity_id` int(11) NOT NULL,
  `inventory_number` varchar(100) DEFAULT NULL,
  `date_manufacture` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`,`commodity_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` mediumtext DEFAULT NULL,
  `transactionid` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `formatted_number` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` mediumtext DEFAULT NULL,
  `adminnote` mediumtext DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` longtext DEFAULT NULL,
  `token` longtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`),
  KEY `formatted_number` (`formatted_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblitem_tax
#

DROP TABLE IF EXISTS `tblitem_tax`;

CREATE TABLE `tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblitemable
#

DROP TABLE IF EXISTS `tblitemable`;

CREATE TABLE `tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` longtext NOT NULL,
  `long_description` longtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  `wh_delivered_quantity` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `commodity_code` varchar(100) NOT NULL,
  `commodity_barcode` text DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `sku_code` varchar(200) DEFAULT NULL,
  `sku_name` varchar(200) DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT NULL,
  `commodity_type` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `sub_group` varchar(200) DEFAULT NULL,
  `commodity_name` varchar(200) NOT NULL,
  `color` text DEFAULT NULL,
  `guarantee` text DEFAULT NULL,
  `profif_ratio` text DEFAULT NULL,
  `active` int(11) DEFAULT 1,
  `long_descriptions` longtext DEFAULT NULL,
  `without_checking_warehouse` int(11) DEFAULT 0,
  `series_id` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL,
  `parent_attributes` longtext DEFAULT NULL,
  `can_be_sold` varchar(100) DEFAULT 'can_be_sold',
  `can_be_purchased` varchar(100) DEFAULT 'can_be_purchased',
  `can_be_manufacturing` varchar(100) DEFAULT 'can_be_manufacturing',
  `can_be_inventory` varchar(100) DEFAULT 'can_be_inventory',
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `commodity_group_code` varchar(100) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbljob_industry
#

DROP TABLE IF EXISTS `tbljob_industry`;

CREATE TABLE `tbljob_industry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(200) NOT NULL,
  `industry_description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbljob_position
#

DROP TABLE IF EXISTS `tbljob_position`;

CREATE TABLE `tbljob_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblknowedge_base_article_feedback
#

DROP TABLE IF EXISTS `tblknowedge_base_article_feedback`;

CREATE TABLE `tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblknowledge_base
#

DROP TABLE IF EXISTS `tblknowledge_base`;

CREATE TABLE `tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` longtext NOT NULL,
  `description` mediumtext NOT NULL,
  `slug` longtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  `question_answers` int(11) DEFAULT 0,
  `file_name` varchar(255) DEFAULT '',
  `curator` varchar(11) DEFAULT '',
  `benchmark` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblknowledge_base_groups
#

DROP TABLE IF EXISTS `tblknowledge_base_groups`;

CREATE TABLE `tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbllead_activity_log
#

DROP TABLE IF EXISTS `tbllead_activity_log`;

CREATE TABLE `tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbllead_integration_emails
#

DROP TABLE IF EXISTS `tbllead_integration_emails`;

CREATE TABLE `tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `lead_value` decimal(15,2) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblleads_email_integration
#

DROP TABLE IF EXISTS `tblleads_email_integration`;

CREATE TABLE `tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` longtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblleads_email_integration` (`id`, `active`, `email`, `imap_server`, `password`, `check_every`, `responsible`, `lead_source`, `lead_status`, `encryption`, `folder`, `last_run`, `notify_lead_imported`, `notify_lead_contact_more_times`, `notify_type`, `notify_ids`, `mark_public`, `only_loop_on_unseen_emails`, `delete_after_import`, `create_task_if_customer`) VALUES (1, 0, '', '', '', 10, 0, 0, 0, 'tls', 'INBOX', '', 1, 1, 'assigned', '', 0, 1, 0, 1);


#
# TABLE STRUCTURE FOR: tblleads_sources
#

DROP TABLE IF EXISTS `tblleads_sources`;

CREATE TABLE `tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (2, 'Facebook');
INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (1, 'Google');


#
# TABLE STRUCTURE FOR: tblleads_status
#

DROP TABLE IF EXISTS `tblleads_status`;

CREATE TABLE `tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (1, 'Customer', 1000, '#7cb342', 1);


#
# TABLE STRUCTURE FOR: tblleave_of_the_year
#

DROP TABLE IF EXISTS `tblleave_of_the_year`;

CREATE TABLE `tblleave_of_the_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `value` double DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbllist_widget
#

DROP TABLE IF EXISTS `tbllist_widget`;

CREATE TABLE `tbllist_widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `add_from` int(11) NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(45) DEFAULT NULL,
  `layout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblmail_queue
#

DROP TABLE IF EXISTS `tblmail_queue`;

CREATE TABLE `tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `bcc` mediumtext DEFAULT NULL,
  `message` longtext NOT NULL,
  `alt_message` longtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` mediumtext DEFAULT NULL,
  `attachments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblmanage_leave
#

DROP TABLE IF EXISTS `tblmanage_leave`;

CREATE TABLE `tblmanage_leave` (
  `leave_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_staff` int(11) NOT NULL,
  `leave_date` int(11) DEFAULT NULL,
  `leave_year` int(11) DEFAULT NULL,
  `accumulated_leave` int(11) DEFAULT NULL,
  `seniority_leave` int(11) DEFAULT NULL,
  `borrow_leave` int(11) DEFAULT NULL,
  `actual_leave` int(11) DEFAULT NULL,
  `expected_leave` int(11) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblmigrations
#

DROP TABLE IF EXISTS `tblmigrations`;

CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblmigrations` (`version`) VALUES ('321');


#
# TABLE STRUCTURE FOR: tblmilestones
#

DROP TABLE IF EXISTS `tblmilestones`;

CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblmodules
#

DROP TABLE IF EXISTS `tblmodules`;

CREATE TABLE `tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (1, 'backup', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (2, 'goals', '2.3.0', 0);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (3, 'menu_setup', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (4, 'theme_style', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (5, 'purchase', '1.0.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (6, 'warehouse', '1.2.9', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (7, 'wiki', '1.0.3', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (8, 'whatsapp_api', '1.2.1', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (9, 'task_bookmarks', '1.0.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (10, 'graphql', '1.0.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (11, 'advanced_task_status_manager', '1.1.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (12, 'si_timesheet', '1.1.3', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (13, 'timesheets', '1.1.8', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (14, 'saas', '1.1.9', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (15, 'accounting', '1.0.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (16, 'recruitment', '1.1.5', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (17, 'hr_profile', '1.0.3', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (18, 'hrm', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (19, 'exports', '1.0.0', 1);


#
# TABLE STRUCTURE FOR: tblnewsfeed_comment_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_comment_likes`;

CREATE TABLE `tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_comments
#

DROP TABLE IF EXISTS `tblnewsfeed_post_comments`;

CREATE TABLE `tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_post_likes`;

CREATE TABLE `tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnewsfeed_posts
#

DROP TABLE IF EXISTS `tblnewsfeed_posts`;

CREATE TABLE `tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnotes
#

DROP TABLE IF EXISTS `tblnotes`;

CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` mediumtext NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=682 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (1, 'dateformat', 'd-m-Y|%d-%m-%Y', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (2, 'companyname', 'ERP Smart Net', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (3, 'services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (4, 'maximum_allowed_ticket_attachments', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (5, 'ticket_attachments_file_extensions', '.jpg,.jpeg,.png,.pdf,.doc,.zip,.rar', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (6, 'staff_access_only_assigned_departments', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (7, 'use_knowledge_base', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (8, 'smtp_email', 'erp@smartnetgt.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (9, 'smtp_password', '851e734322b495dba230c38f2cee54b287c29c3d9e4fd9962ec4712b7e2fd8a57058fe76ac1a1d413b85a151bb41aed2c4c23360c0080a6629dcfd122e2d06c2Ros3hXET1jj6GFVFMrDPIbFh4x1IddIFpxik6FWXFwI=', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (10, 'company_info_format', '{company_name}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (11, 'smtp_port', '465', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (12, 'smtp_host', 'mail.smartnetgt.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (13, 'smtp_email_charset', 'utf-8', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (14, 'default_timezone', 'America/Guatemala', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (15, 'clients_default_theme', 'perfex', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (16, 'company_logo', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (17, 'tables_pagination_limit', '25', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (18, 'main_domain', 'smartnetgt.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (19, 'allow_registration', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (20, 'knowledge_base_without_registration', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (21, 'email_signature', 'Correo automático, por favor no responder.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (22, 'default_staff_role', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (23, 'newsfeed_maximum_files_upload', '20', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (24, 'contract_expiration_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (25, 'invoice_prefix', 'DTE-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (26, 'decimal_separator', '.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (27, 'thousand_separator', ',', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (28, 'invoice_company_name', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (29, 'invoice_company_address', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (30, 'invoice_company_city', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (31, 'invoice_company_country_code', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (32, 'invoice_company_postal_code', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (33, 'invoice_company_phonenumber', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (34, 'view_invoice_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (35, 'invoice_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (36, 'next_invoice_number', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (37, 'active_language', 'spanish', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (38, 'invoice_number_decrement_on_delete', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (39, 'automatically_send_invoice_overdue_reminder_after', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (40, 'automatically_resend_invoice_overdue_reminder_after', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (41, 'expenses_auto_operations_hour', '9', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (42, 'delete_only_on_last_invoice', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (43, 'delete_only_on_last_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (44, 'create_invoice_from_recurring_only_on_paid_invoices', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (45, 'allow_payment_amount_to_be_modified', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (46, 'rtl_support_client', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (47, 'limit_top_search_bar_results_to', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (48, 'estimate_prefix', 'EST-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (49, 'next_estimate_number', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (50, 'estimate_number_decrement_on_delete', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (51, 'estimate_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (52, 'estimate_auto_convert_to_invoice_on_client_accept', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (53, 'exclude_estimate_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (54, 'rtl_support_admin', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (55, 'last_cron_run', '1735598832', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (56, 'show_sale_agent_on_estimates', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (57, 'show_sale_agent_on_invoices', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (58, 'predefined_terms_invoice', 'FORMA DE PAGO:\r\n1. Transferencia Bancaria, Visalink, Cheque de empresa.\r\n2. Crédito disponible: De acuerdo a condiciones de cotizacion aceptada.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (59, 'predefined_terms_estimate', '1. Los productos ofertados en esta propuesta están sujetos a disponibilidad al momento de la aceptación de la misma.\r\n2. Servicios, accesorios, licencias de software o cualquier soporte que no este incluido en esta propuesta deberá ser cotizado por separado.\r\n3. Garantía de servicios y productos se indica en cada linea al final de la cotización.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (60, 'default_task_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (61, 'dropbox_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (62, 'show_expense_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (63, 'only_show_contact_tickets', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (64, 'predefined_clientnote_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (65, 'predefined_clientnote_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (66, 'custom_pdf_logo_image_url', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (67, 'favicon', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (68, 'invoice_due_after', '30', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (69, 'google_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (70, 'google_calendar_main_calendar', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (71, 'default_tax', 'a:0:{}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (72, 'show_invoices_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (73, 'show_estimates_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (74, 'show_contracts_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (75, 'show_tasks_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (76, 'show_customer_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (77, 'output_client_pdfs_from_admin_area_in_client_language', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (78, 'show_lead_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (79, 'send_estimate_expiry_reminder_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (80, 'leads_default_source', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (81, 'leads_default_status', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (82, 'proposal_expiry_reminder_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (83, 'send_proposal_expiry_reminder_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (84, 'default_contact_permissions', 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (85, 'pdf_logo_width', '150', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (86, 'access_tickets_to_none_staff_members', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (87, 'customer_default_country', '91', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (88, 'view_estimate_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (89, 'show_status_on_pdf_ei', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (90, 'email_piping_only_replies', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (91, 'email_piping_only_registered', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (92, 'default_view_calendar', 'dayGridMonth', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (93, 'email_piping_default_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (94, 'total_to_words_lowercase', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (95, 'show_tax_per_item', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (96, 'total_to_words_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (97, 'receive_notification_on_new_ticket', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (98, 'autoclose_tickets_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (99, 'media_max_file_size_upload', '100', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (100, 'client_staff_add_edit_delete_task_comments_first_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (101, 'show_projects_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (102, 'leads_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (103, 'tasks_reminder_notification_before', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (104, 'pdf_font', 'freesans', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (105, 'pdf_table_heading_color', '#e5e7eb', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (106, 'pdf_table_heading_text_color', '#030712', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (107, 'pdf_font_size', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (108, 'default_leads_kanban_sort', 'leadorder', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (109, 'default_leads_kanban_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (110, 'allowed_files', '.png,.jpg,.jpeg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (111, 'show_all_tasks_for_project_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (112, 'email_protocol', 'smtp', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (113, 'calendar_first_day', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (114, 'recaptcha_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (115, 'show_help_on_setup_menu', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (116, 'show_proposals_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (117, 'smtp_encryption', 'ssl', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (118, 'recaptcha_site_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (119, 'smtp_username', 'erp@smartnetgt.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (120, 'auto_stop_tasks_timers_on_new_timer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (121, 'notification_when_customer_pay_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (122, 'calendar_invoice_color', '#FF6F00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (123, 'calendar_estimate_color', '#FF6F00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (124, 'calendar_proposal_color', '#84c529', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (125, 'new_task_auto_assign_current_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (126, 'calendar_reminder_color', '#03A9F4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (127, 'calendar_contract_color', '#B72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (128, 'calendar_project_color', '#B72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (129, 'update_info_message', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (130, 'show_estimate_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (131, 'show_invoice_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (132, 'show_proposal_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (133, 'proposal_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (134, 'allow_customer_to_change_ticket_status', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (135, 'lead_lock_after_convert_to_customer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (136, 'default_proposals_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (137, 'default_proposals_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (138, 'default_estimates_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (139, 'default_estimates_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (140, 'use_recaptcha_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (141, 'remove_decimals_on_zero', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (142, 'remove_tax_name_from_item_table', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (143, 'pdf_format_invoice', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (144, 'pdf_format_estimate', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (145, 'pdf_format_proposal', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (146, 'pdf_format_payment', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (147, 'pdf_format_contract', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (148, 'swap_pdf_info', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (149, 'exclude_invoice_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (150, 'cron_has_run_from_cli', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (151, 'hide_cron_is_required_message', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (152, 'auto_assign_customer_admin_after_lead_convert', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (153, 'show_transactions_on_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (154, 'show_pay_link_to_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (155, 'tasks_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (156, 'purchase_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (157, 'estimates_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (158, 'proposals_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (159, 'proposal_number_prefix', 'PRO-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (160, 'number_padding_prefixes', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (161, 'show_page_number_on_pdf', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (162, 'calendar_events_limit', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (163, 'show_setup_menu_item_only_on_hover', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (164, 'company_requires_vat_number_field', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (165, 'company_is_required', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (166, 'allow_contact_to_delete_files', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (167, 'company_vat', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (168, 'di', '1734315136', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (169, 'invoice_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (170, 'use_minified_files', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (171, 'only_own_files_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (172, 'allow_primary_contact_to_view_edit_billing_and_shipping', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (173, 'estimate_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (174, 'staff_members_open_tickets_to_all_contacts', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (175, 'time_format', '24', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (176, 'delete_activity_log_older_then', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (177, 'disable_language', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (178, 'company_state', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (179, 'email_header', '<!doctype html>\r\n      <html>\r\n      <head>\r\n      <meta name=\"viewport\" content=\"width=device-width\" />\r\n      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n      <style>\r\n      body {\r\n        background-color: #f6f6f6;\r\n        font-family: sans-serif;\r\n        -webkit-font-smoothing: antialiased;\r\n        font-size: 14px;\r\n        line-height: 1.4;\r\n        margin: 0;\r\n        padding: 0;\r\n        -ms-text-size-adjust: 100%;\r\n        -webkit-text-size-adjust: 100%;\r\n      }\r\n      table {\r\n        border-collapse: separate;\r\n        mso-table-lspace: 0pt;\r\n        mso-table-rspace: 0pt;\r\n        width: 100%;\r\n      }\r\n      table td {\r\n        font-family: sans-serif;\r\n        font-size: 14px;\r\n        vertical-align: top;\r\n      }\r\n      /* -------------------------------------\r\n      BODY & CONTAINER\r\n      ------------------------------------- */\r\n      .body {\r\n        background-color: #f6f6f6;\r\n        width: 100%;\r\n      }\r\n      /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n      \r\n      .container {\r\n        display: block;\r\n        margin: 0 auto !important;\r\n        /* makes it centered */\r\n        max-width: 680px;\r\n        padding: 10px;\r\n        width: 680px;\r\n      }\r\n      /* This should also be a block element, so that it will fill 100% of the .container */\r\n      \r\n      .content {\r\n        box-sizing: border-box;\r\n        display: block;\r\n        margin: 0 auto;\r\n        max-width: 680px;\r\n        padding: 10px;\r\n      }\r\n      /* -------------------------------------\r\n      HEADER, FOOTER, MAIN\r\n      ------------------------------------- */\r\n      \r\n      .main {\r\n        background: #fff;\r\n        border-radius: 3px;\r\n        width: 100%;\r\n      }\r\n      .wrapper {\r\n        box-sizing: border-box;\r\n        padding: 20px;\r\n      }\r\n      .footer {\r\n        clear: both;\r\n        padding-top: 10px;\r\n        text-align: center;\r\n        width: 100%;\r\n      }\r\n      .footer td,\r\n      .footer p,\r\n      .footer span,\r\n      .footer a {\r\n        color: #999999;\r\n        font-size: 12px;\r\n        text-align: center;\r\n      }\r\n      hr {\r\n        border: 0;\r\n        border-bottom: 1px solid #f6f6f6;\r\n        margin: 20px 0;\r\n      }\r\n      /* -------------------------------------\r\n      RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n      ------------------------------------- */\r\n      \r\n      @media only screen and (max-width: 620px) {\r\n        table[class=body] .content {\r\n          padding: 0 !important;\r\n        }\r\n        table[class=body] .container {\r\n          padding: 0 !important;\r\n          width: 100% !important;\r\n        }\r\n        table[class=body] .main {\r\n          border-left-width: 0 !important;\r\n          border-radius: 0 !important;\r\n          border-right-width: 0 !important;\r\n        }\r\n      }\r\n      </style>\r\n      </head>\r\n      <body class=\"\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n      <tr>\r\n      <td>&nbsp;</td>\r\n      <td class=\"container\">\r\n      <div class=\"content\">\r\n      <!-- START CENTERED WHITE CONTAINER -->\r\n      <table class=\"main\">\r\n      <!-- START MAIN CONTENT AREA -->\r\n      <tr>\r\n      <td class=\"wrapper\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (180, 'show_pdf_signature_invoice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (181, 'show_pdf_signature_estimate', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (182, 'signature_image', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (183, 'email_footer', '</td>\r\n      </tr>\r\n      </table>\r\n      </td>\r\n      </tr>\r\n      <!-- END MAIN CONTENT AREA -->\r\n      </table>\r\n      <!-- START FOOTER -->\r\n      <div class=\"footer\">\r\n      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tr>\r\n      <td class=\"content-block\">\r\n      <span>{companyname}</span>\r\n      </td>\r\n      </tr>\r\n      </table>\r\n      </div>\r\n      <!-- END FOOTER -->\r\n      <!-- END CENTERED WHITE CONTAINER -->\r\n      </div>\r\n      </td>\r\n      <td>&nbsp;</td>\r\n      </tr>\r\n      </table>\r\n      </body>\r\n      </html>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (184, 'exclude_proposal_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (185, 'pusher_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (186, 'pusher_app_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (187, 'pusher_app_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (188, 'pusher_realtime_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (189, 'pdf_format_statement', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (190, 'pusher_cluster', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (191, 'show_table_export_button', 'to_all', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (192, 'allow_staff_view_proposals_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (193, 'show_cloudflare_notice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (194, 'task_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (195, 'lead_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (196, 'show_timesheets_overview_all_members_notice_admins', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (197, 'desktop_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (198, 'hide_notified_reminders_from_calendar', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (199, 'customer_info_format', '{company_name}<br />\r\n      {street}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (200, 'timer_started_change_status_in_progress', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (201, 'default_ticket_reply_status', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (202, 'default_task_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (203, 'email_queue_skip_with_attachments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (204, 'email_queue_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (205, 'last_email_queue_retry', '1735598832', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (206, 'auto_dismiss_desktop_notifications_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (207, 'proposal_info_format', '{proposal_to}<br />\r\n      {address}<br />\r\n      {city} {state}<br />\r\n      {country_code} {zip_code}<br />\r\n      {phone}<br />\r\n      {email}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (208, 'ticket_replies_order', 'desc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (209, 'new_recurring_invoice_action', 'generate_and_send', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (210, 'bcc_emails', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (211, 'email_templates_language_checks', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (212, 'proposal_accept_identity_confirmation', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (213, 'estimate_accept_identity_confirmation', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (214, 'new_task_auto_follower_current_member', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (215, 'task_biillable_checked_on_creation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (216, 'predefined_clientnote_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (217, 'predefined_terms_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (218, 'next_credit_note_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (219, 'credit_note_prefix', 'NC-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (220, 'credit_note_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (221, 'pdf_format_credit_note', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (222, 'show_pdf_signature_credit_note', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (223, 'show_credit_note_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (224, 'show_amount_due_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (225, 'show_total_paid_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (226, 'show_credits_applied_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (227, 'staff_members_create_inline_lead_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (228, 'staff_members_create_inline_customer_groups', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (229, 'staff_members_create_inline_ticket_services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (230, 'staff_members_save_tickets_predefined_replies', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (231, 'staff_members_create_inline_contract_types', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (232, 'staff_members_create_inline_expense_categories', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (233, 'show_project_on_credit_note', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (234, 'proposals_auto_operations_hour', '9', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (235, 'estimates_auto_operations_hour', '9', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (236, 'contracts_auto_operations_hour', '9', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (237, 'credit_note_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (238, 'allow_non_admin_members_to_import_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (239, 'e_sign_legal_text', 'By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (240, 'show_pdf_signature_contract', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (241, 'view_contract_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (242, 'show_subscriptions_in_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (243, 'calendar_only_assigned_tasks', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (244, 'after_subscription_payment_captured', 'nothing', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (245, 'mail_engine', 'phpmailer', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (246, 'gdpr_enable_terms_and_conditions', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (247, 'privacy_policy', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (248, 'terms_and_conditions', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (249, 'gdpr_enable_terms_and_conditions_lead_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (250, 'gdpr_enable_terms_and_conditions_ticket_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (251, 'gdpr_contact_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (252, 'show_gdpr_in_customers_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (253, 'show_gdpr_link_in_footer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (254, 'enable_gdpr', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (255, 'gdpr_on_forgotten_remove_invoices_credit_notes', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (256, 'gdpr_on_forgotten_remove_estimates', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (257, 'gdpr_enable_consent_for_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (258, 'gdpr_consent_public_page_top_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (259, 'gdpr_page_top_information_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (260, 'gdpr_enable_lead_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (261, 'gdpr_show_lead_custom_fields_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (262, 'gdpr_lead_attachments_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (263, 'gdpr_enable_consent_for_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (264, 'gdpr_lead_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (265, 'allow_staff_view_invoices_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (266, 'gdpr_data_portability_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (267, 'gdpr_lead_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (268, 'gdpr_contact_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (269, 'gdpr_data_portability_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (270, 'allow_staff_view_estimates_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (271, 'gdpr_after_lead_converted_delete', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (272, 'gdpr_show_terms_and_conditions_in_footer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (273, 'save_last_order_for_tables', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (274, 'company_logo_dark', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (275, 'customers_register_require_confirmation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (276, 'allow_non_admin_staff_to_delete_ticket_attachments', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (277, 'receive_notification_on_new_ticket_replies', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (278, 'google_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (279, 'enable_google_picker', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (280, 'show_ticket_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (281, 'ticket_import_reply_only', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (282, 'visible_customer_profile_tabs', 'a:19:{s:7:\"profile\";b:0;s:8:\"contacts\";b:0;s:5:\"notes\";b:0;s:9:\"statement\";b:1;s:8:\"invoices\";b:1;s:8:\"payments\";b:1;s:9:\"proposals\";b:1;s:12:\"credit_notes\";b:1;s:9:\"estimates\";b:1;s:13:\"subscriptions\";b:0;s:8:\"expenses\";b:0;s:9:\"contracts\";b:1;s:8:\"projects\";b:1;s:5:\"tasks\";b:1;s:7:\"tickets\";b:1;s:11:\"attachments\";b:1;s:5:\"vault\";b:1;s:9:\"reminders\";b:1;s:3:\"map\";b:0;}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (283, 'show_project_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (284, 'show_project_on_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (285, 'staff_members_create_inline_lead_source', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (286, 'lead_unique_validation', '[\"email\"]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (287, 'last_upgrade_copy_data', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (288, 'custom_js_admin_scripts', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (289, 'custom_js_customer_scripts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (290, 'stripe_webhook_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (291, 'stripe_webhook_signing_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (292, 'stripe_ideal_webhook_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (293, 'stripe_ideal_webhook_signing_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (294, 'show_php_version_notice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (295, 'recaptcha_ignore_ips', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (296, 'show_task_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (297, 'customer_settings', 'true', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (298, 'tasks_reminder_notification_hour', '9', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (299, 'allow_primary_contact_to_manage_other_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (300, 'items_table_amounts_exclude_currency_symbol', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (301, 'round_off_task_timer_option', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (302, 'round_off_task_timer_time', '5', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (303, 'bitly_access_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (304, 'enable_support_menu_badges', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (305, 'attach_invoice_to_payment_receipt_email', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (306, 'invoice_due_notice_before', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (307, 'invoice_due_notice_resend_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (308, '_leads_settings', 'true', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (309, 'show_estimate_request_in_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (310, 'gdpr_enable_terms_and_conditions_estimate_request_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (311, 'identification_key', '12857832251734315166675f8c9ee5d6d', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (312, 'automatically_stop_task_timer_after_hours', '8', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (313, 'automatically_assign_ticket_to_first_staff_responding', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (314, 'reminder_for_completed_but_not_billed_tasks', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (315, 'staff_notify_completed_but_not_billed_tasks', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (316, 'reminder_for_completed_but_not_billed_tasks_days', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (317, 'tasks_reminder_notification_last_notified_day', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (318, 'staff_related_ticket_notification_to_assignee_only', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (319, 'show_pdf_signature_proposal', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (320, 'enable_honeypot_spam_validation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (321, 'microsoft_mail_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (322, 'microsoft_mail_client_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (323, 'microsoft_mail_azure_tenant_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (324, 'google_mail_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (325, 'google_mail_client_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (326, 'google_mail_refresh_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (327, 'automatically_set_logged_in_staff_sales_agent', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (328, 'contract_sign_reminder_every_days', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (329, 'last_updated_date', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (330, 'v310_incompatible_tables', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (331, 'microsoft_mail_refresh_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (332, 'required_register_fields', '[]', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (333, 'allow_non_admin_members_to_delete_tickets_and_replies', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (334, 'proposal_auto_convert_to_invoice_on_client_accept', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (335, 'show_project_on_proposal', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (336, 'disable_ticket_public_url', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (337, 'upgraded_from_version', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (338, 'sms_clickatell_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (339, 'sms_clickatell_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (340, 'sms_clickatell_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (341, 'sms_msg91_sender_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (342, 'sms_msg91_api_type', 'api', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (343, 'sms_msg91_auth_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (344, 'sms_msg91_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (345, 'sms_msg91_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (346, 'sms_twilio_account_sid', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (347, 'sms_twilio_auth_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (348, 'sms_twilio_phone_number', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (349, 'sms_twilio_sender_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (350, 'sms_twilio_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (351, 'sms_twilio_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (352, 'auto_backup_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (353, 'auto_backup_every', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (354, 'last_auto_backup', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (355, 'delete_backups_older_then', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (356, 'auto_backup_hour', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (357, 'aside_menu_active', '{\"dashboard\":{\"id\":\"dashboard\",\"icon\":\"\",\"disabled\":\"false\",\"position\":1},\"projects\":{\"id\":\"projects\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"10\"},\"tasks\":{\"id\":\"tasks\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"15\"},\"customers\":{\"id\":\"customers\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"20\"},\"warehouse\":{\"id\":\"warehouse\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"25\",\"children\":{\"wa_commodity_list\":{\"disabled\":\"false\",\"id\":\"wa_commodity_list\",\"icon\":\"\",\"position\":\"5\"},\"wa_manage_goods_receipt\":{\"disabled\":\"false\",\"id\":\"wa_manage_goods_receipt\",\"icon\":\"\",\"position\":\"10\"},\"wa_manage_goods_delivery\":{\"disabled\":\"false\",\"id\":\"wa_manage_goods_delivery\",\"icon\":\"\",\"position\":\"15\"},\"wa_manage_packing_list\":{\"disabled\":\"false\",\"id\":\"wa_manage_packing_list\",\"icon\":\"\",\"position\":\"20\"},\"wa_manage_internal_delivery\":{\"disabled\":\"false\",\"id\":\"wa_manage_internal_delivery\",\"icon\":\"\",\"position\":\"25\"},\"wa_manage_loss_adjustment\":{\"disabled\":\"false\",\"id\":\"wa_manage_loss_adjustment\",\"icon\":\"\",\"position\":\"30\"},\"wa_manage_order_return\":{\"disabled\":\"false\",\"id\":\"wa_manage_order_return\",\"icon\":\"\",\"position\":\"35\"},\"wa_manage_warehouse\":{\"disabled\":\"false\",\"id\":\"wa_manage_warehouse\",\"icon\":\"\",\"position\":\"40\"},\"wa_warehouse_history\":{\"disabled\":\"false\",\"id\":\"wa_warehouse_history\",\"icon\":\"\",\"position\":\"45\"},\"wa_report\":{\"disabled\":\"false\",\"id\":\"wa_report\",\"icon\":\"\",\"position\":\"50\"},\"ware_settings\":{\"disabled\":\"false\",\"id\":\"ware_settings\",\"icon\":\"\",\"position\":\"55\"}}},\"sales\":{\"id\":\"sales\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"30\",\"children\":{\"proposals\":{\"disabled\":\"false\",\"id\":\"proposals\",\"icon\":\"\",\"position\":\"5\"},\"estimates\":{\"disabled\":\"false\",\"id\":\"estimates\",\"icon\":\"\",\"position\":\"10\"},\"invoices\":{\"disabled\":\"false\",\"id\":\"invoices\",\"icon\":\"\",\"position\":\"15\"},\"payments\":{\"disabled\":\"false\",\"id\":\"payments\",\"icon\":\"\",\"position\":\"20\"},\"credit_notes\":{\"disabled\":\"false\",\"id\":\"credit_notes\",\"icon\":\"\",\"position\":\"25\"},\"items\":{\"disabled\":\"false\",\"id\":\"items\",\"icon\":\"\",\"position\":\"30\"}}},\"subscriptions\":{\"id\":\"subscriptions\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"35\"},\"si_timesheet_menu\":{\"id\":\"si_timesheet_menu\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"40\",\"children\":{\"si-timesheets\":{\"disabled\":\"false\",\"id\":\"si-timesheets\",\"icon\":\"\",\"position\":\"5\"},\"si-timesheets-summary\":{\"disabled\":\"false\",\"id\":\"si-timesheets-summary\",\"icon\":\"\",\"position\":\"10\"},\"si-timesheet-templates\":{\"disabled\":\"false\",\"id\":\"si-timesheet-templates\",\"icon\":\"\",\"position\":\"15\"},\"expenses\":{\"disabled\":\"false\",\"id\":\"expenses\",\"icon\":\"\",\"position\":\"20\"}}},\"contracts\":{\"id\":\"contracts\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"45\"},\"timesheets\":{\"id\":\"timesheets\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"50\",\"children\":{\"timesheets_timekeeping\":{\"disabled\":\"false\",\"id\":\"timesheets_timekeeping\",\"icon\":\"\",\"position\":\"5\"},\"timesheets_timekeeping_mnrh\":{\"disabled\":\"false\",\"id\":\"timesheets_timekeeping_mnrh\",\"icon\":\"\",\"position\":\"10\"},\"timesheets_table_shiftwork\":{\"disabled\":\"false\",\"id\":\"timesheets_table_shiftwork\",\"icon\":\"\",\"position\":\"15\"},\"timesheets_shift_management\":{\"disabled\":\"false\",\"id\":\"timesheets_shift_management\",\"icon\":\"\",\"position\":\"20\"},\"timesheets_shift_type\":{\"disabled\":\"false\",\"id\":\"timesheets_shift_type\",\"icon\":\"\",\"position\":\"25\"},\"timesheets-report\":{\"disabled\":\"false\",\"id\":\"timesheets-report\",\"icon\":\"\",\"position\":\"30\"},\"timesheets_setting\":{\"disabled\":\"false\",\"id\":\"timesheets_setting\",\"icon\":\"\",\"position\":\"35\"}}},\"whatsapp_api\":{\"id\":\"whatsapp_api\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"55\",\"children\":{\"whatsapp_template_view\":{\"disabled\":\"false\",\"id\":\"whatsapp_template_view\",\"icon\":\"\",\"position\":\"5\"},\"whatsapp_template_details\":{\"disabled\":\"false\",\"id\":\"whatsapp_template_details\",\"icon\":\"\",\"position\":\"10\"},\"whatsapp_log_details\":{\"disabled\":\"false\",\"id\":\"whatsapp_log_details\",\"icon\":\"\",\"position\":\"15\"}}},\"support\":{\"id\":\"support\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"60\",\"children\":{\"support-1\":{\"disabled\":\"false\",\"id\":\"support-1\",\"icon\":\"\",\"position\":\"5\"},\"support-2\":{\"disabled\":\"false\",\"id\":\"support-2\",\"icon\":\"\",\"position\":\"10\"},\"support-3\":{\"disabled\":\"false\",\"id\":\"support-3\",\"icon\":\"\",\"position\":\"15\"},\"support-4\":{\"disabled\":\"false\",\"id\":\"support-4\",\"icon\":\"\",\"position\":\"20\"},\"support-5\":{\"disabled\":\"false\",\"id\":\"support-5\",\"icon\":\"\",\"position\":\"25\"}}},\"leads\":{\"id\":\"leads\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"65\"},\"estimate_request\":{\"id\":\"estimate_request\",\"icon\":\"\",\"disabled\":\"true\",\"position\":\"70\"},\"utilities\":{\"id\":\"utilities\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"75\",\"children\":{\"media\":{\"disabled\":\"false\",\"id\":\"media\",\"icon\":\"\",\"position\":\"5\"},\"task_bookmarks\":{\"disabled\":\"false\",\"id\":\"task_bookmarks\",\"icon\":\"\",\"position\":\"10\"},\"bulk-pdf-exporter\":{\"disabled\":\"false\",\"id\":\"bulk-pdf-exporter\",\"icon\":\"\",\"position\":\"15\"},\"calendar\":{\"disabled\":\"false\",\"id\":\"calendar\",\"icon\":\"\",\"position\":\"20\"},\"announcements\":{\"disabled\":\"false\",\"id\":\"announcements\",\"icon\":\"\",\"position\":\"25\"},\"activity-log\":{\"disabled\":\"false\",\"id\":\"activity-log\",\"icon\":\"\",\"position\":\"30\"},\"utility_backup\":{\"disabled\":\"false\",\"id\":\"utility_backup\",\"icon\":\"\",\"position\":\"35\"},\"ticket-pipe-log\":{\"disabled\":\"false\",\"id\":\"ticket-pipe-log\",\"icon\":\"\",\"position\":\"40\"}}},\"reports\":{\"id\":\"reports\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"80\",\"children\":{\"sales-reports\":{\"disabled\":\"false\",\"id\":\"sales-reports\",\"icon\":\"\",\"position\":\"5\"},\"expenses-reports\":{\"disabled\":\"false\",\"id\":\"expenses-reports\",\"icon\":\"\",\"position\":\"10\"},\"expenses-vs-income-reports\":{\"disabled\":\"false\",\"id\":\"expenses-vs-income-reports\",\"icon\":\"\",\"position\":\"15\"},\"leads-reports\":{\"disabled\":\"false\",\"id\":\"leads-reports\",\"icon\":\"\",\"position\":\"20\"},\"timesheets-reports\":{\"disabled\":\"false\",\"id\":\"timesheets-reports\",\"icon\":\"\",\"position\":\"25\"},\"knowledge-base-reports\":{\"disabled\":\"false\",\"id\":\"knowledge-base-reports\",\"icon\":\"\",\"position\":\"30\"}}},\"purchase\":{\"id\":\"purchase\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"85\",\"children\":{\"purchase-items\":{\"disabled\":\"false\",\"id\":\"purchase-items\",\"icon\":\"\",\"position\":\"5\"},\"vendors\":{\"disabled\":\"false\",\"id\":\"vendors\",\"icon\":\"\",\"position\":\"10\"},\"purchase-request\":{\"disabled\":\"false\",\"id\":\"purchase-request\",\"icon\":\"\",\"position\":\"15\"},\"quotation\":{\"disabled\":\"false\",\"id\":\"quotation\",\"icon\":\"\",\"position\":\"20\"},\"purchase-order\":{\"disabled\":\"false\",\"id\":\"purchase-order\",\"icon\":\"\",\"position\":\"25\"},\"contract\":{\"disabled\":\"false\",\"id\":\"contract\",\"icon\":\"\",\"position\":\"30\"},\"reports\":{\"disabled\":\"false\",\"id\":\"reports\",\"icon\":\"\",\"position\":\"35\"},\"settings\":{\"disabled\":\"false\",\"id\":\"settings\",\"icon\":\"\",\"position\":\"40\"}}},\"wiki-module-menu-wiki-master\":{\"id\":\"wiki-module-menu-wiki-master\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"90\",\"children\":{\"wiki-books\":{\"disabled\":\"false\",\"id\":\"wiki-books\",\"icon\":\"\",\"position\":\"5\"},\"wiki-articles\":{\"disabled\":\"false\",\"id\":\"wiki-articles\",\"icon\":\"\",\"position\":\"10\"},\"wiki-articles-posted-by-me\":{\"disabled\":\"false\",\"id\":\"wiki-articles-posted-by-me\",\"icon\":\"\",\"position\":\"15\"},\"knowledge-base\":{\"disabled\":\"false\",\"id\":\"knowledge-base\",\"icon\":\"\",\"position\":\"20\"},\"wiki-articles-bookmark\":{\"disabled\":\"false\",\"id\":\"wiki-articles-bookmark\",\"icon\":\"\",\"position\":\"25\"}}},\"saas\":{\"id\":\"saas\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"95\"},\"graphqlapi-options\":{\"id\":\"graphqlapi-options\",\"icon\":\"\",\"disabled\":\"false\",\"position\":\"100\",\"children\":{\"graphqlusermanagement\":{\"disabled\":\"false\",\"id\":\"graphqlusermanagement\",\"icon\":\"\",\"position\":\"5\"},\"graphqlapi-guide\":{\"disabled\":\"false\",\"id\":\"graphqlapi-guide\",\"icon\":\"\",\"position\":\"10\"}}}}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (358, 'setup_menu_active', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (359, 'theme_style', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (360, 'theme_style_custom_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (361, 'theme_style_custom_clients_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (362, 'theme_style_custom_clients_and_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (363, 'paymentmethod_authorize_acceptjs_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (364, 'paymentmethod_authorize_acceptjs_label', 'Authorize.net Accept.js', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (365, 'paymentmethod_authorize_acceptjs_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (366, 'paymentmethod_authorize_acceptjs_api_login_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (367, 'paymentmethod_authorize_acceptjs_api_transaction_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (368, 'paymentmethod_authorize_acceptjs_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (369, 'paymentmethod_authorize_acceptjs_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (370, 'paymentmethod_authorize_acceptjs_test_mode_enabled', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (371, 'paymentmethod_authorize_acceptjs_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (372, 'paymentmethod_authorize_acceptjs_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (373, 'paymentmethod_instamojo_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (374, 'paymentmethod_instamojo_label', 'Instamojo', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (375, 'paymentmethod_instamojo_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (376, 'paymentmethod_instamojo_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (377, 'paymentmethod_instamojo_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (378, 'paymentmethod_instamojo_auth_token', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (379, 'paymentmethod_instamojo_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (380, 'paymentmethod_instamojo_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (381, 'paymentmethod_instamojo_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (382, 'paymentmethod_instamojo_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (383, 'paymentmethod_instamojo_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (384, 'paymentmethod_mollie_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (385, 'paymentmethod_mollie_label', 'Mollie', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (386, 'paymentmethod_mollie_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (387, 'paymentmethod_mollie_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (388, 'paymentmethod_mollie_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (389, 'paymentmethod_mollie_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (390, 'paymentmethod_mollie_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (391, 'paymentmethod_mollie_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (392, 'paymentmethod_paypal_braintree_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (393, 'paymentmethod_paypal_braintree_label', 'Braintree', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (394, 'paymentmethod_paypal_braintree_merchant_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (395, 'paymentmethod_paypal_braintree_api_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (396, 'paymentmethod_paypal_braintree_api_private_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (397, 'paymentmethod_paypal_braintree_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (398, 'paymentmethod_paypal_braintree_paypal_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (399, 'paymentmethod_paypal_braintree_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (400, 'paymentmethod_paypal_braintree_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (401, 'paymentmethod_paypal_braintree_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (402, 'paymentmethod_paypal_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (403, 'paymentmethod_paypal_checkout_label', 'Paypal Smart Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (404, 'paymentmethod_paypal_checkout_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (405, 'paymentmethod_paypal_checkout_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (406, 'paymentmethod_paypal_checkout_client_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (407, 'paymentmethod_paypal_checkout_secret', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (408, 'paymentmethod_paypal_checkout_payment_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (409, 'paymentmethod_paypal_checkout_currencies', 'USD,CAD,EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (410, 'paymentmethod_paypal_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (411, 'paymentmethod_paypal_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (412, 'paymentmethod_paypal_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (413, 'paymentmethod_paypal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (414, 'paymentmethod_paypal_label', 'Paypal', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (415, 'paymentmethod_paypal_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (416, 'paymentmethod_paypal_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (417, 'paymentmethod_paypal_username', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (418, 'paymentmethod_paypal_password', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (419, 'paymentmethod_paypal_signature', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (420, 'paymentmethod_paypal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (421, 'paymentmethod_paypal_currencies', 'EUR,USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (422, 'paymentmethod_paypal_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (423, 'paymentmethod_paypal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (424, 'paymentmethod_paypal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (425, 'paymentmethod_payu_money_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (426, 'paymentmethod_payu_money_label', 'PayU Money', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (427, 'paymentmethod_payu_money_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (428, 'paymentmethod_payu_money_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (429, 'paymentmethod_payu_money_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (430, 'paymentmethod_payu_money_salt', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (431, 'paymentmethod_payu_money_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (432, 'paymentmethod_payu_money_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (433, 'paymentmethod_payu_money_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (434, 'paymentmethod_payu_money_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (435, 'paymentmethod_payu_money_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (436, 'paymentmethod_stripe_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (437, 'paymentmethod_stripe_label', 'Stripe Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (438, 'paymentmethod_stripe_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (439, 'paymentmethod_stripe_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (440, 'paymentmethod_stripe_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (441, 'paymentmethod_stripe_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (442, 'paymentmethod_stripe_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (443, 'paymentmethod_stripe_currencies', 'USD,CAD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (444, 'paymentmethod_stripe_allow_primary_contact_to_update_credit_card', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (445, 'paymentmethod_stripe_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (446, 'paymentmethod_stripe_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (447, 'paymentmethod_stripe_ideal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (448, 'paymentmethod_stripe_ideal_label', 'Stripe iDEAL', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (449, 'paymentmethod_stripe_ideal_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (450, 'paymentmethod_stripe_ideal_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (451, 'paymentmethod_stripe_ideal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (452, 'paymentmethod_stripe_ideal_statement_descriptor', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (453, 'paymentmethod_stripe_ideal_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (454, 'paymentmethod_stripe_ideal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (455, 'paymentmethod_stripe_ideal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (456, 'paymentmethod_two_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (457, 'paymentmethod_two_checkout_label', '2Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (458, 'paymentmethod_two_checkout_fee_fixed', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (459, 'paymentmethod_two_checkout_fee_percent', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (460, 'paymentmethod_two_checkout_merchant_code', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (461, 'paymentmethod_two_checkout_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (462, 'paymentmethod_two_checkout_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (463, 'paymentmethod_two_checkout_currencies', 'USD, EUR, GBP', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (464, 'paymentmethod_two_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (465, 'paymentmethod_two_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (466, 'paymentmethod_two_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (467, 'allow_non_admin_members_to_edit_ticket_messages', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (468, 'sms_trigger_invoice_overdue_notice', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (469, 'sms_trigger_invoice_due_notice', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (470, 'sms_trigger_invoice_payment_recorded', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (471, 'sms_trigger_estimate_expiration_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (472, 'sms_trigger_proposal_expiration_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (473, 'sms_trigger_proposal_new_comment_to_customer', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (474, 'sms_trigger_proposal_new_comment_to_staff', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (475, 'sms_trigger_contract_new_comment_to_customer', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (476, 'sms_trigger_contract_new_comment_to_staff', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (477, 'sms_trigger_contract_expiration_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (478, 'sms_trigger_contract_sign_reminder_to_customer', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (479, 'sms_trigger_staff_reminder', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (480, 'warehouse_selling_price_rule_profif_ratio', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (481, 'profit_rate_by_purchase_price_sale', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (482, 'warehouse_the_fractional_part', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (483, 'warehouse_integer_part', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (484, 'auto_create_goods_received', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (485, 'auto_create_goods_delivery', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (486, 'goods_receipt_warehouse', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (487, 'barcode_with_sku_code', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (488, 'revert_goods_receipt_goods_delivery', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (489, 'cancelled_invoice_reverse_inventory_delivery_voucher', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (490, 'uncancelled_invoice_create_inventory_delivery_voucher', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (491, 'inventory_auto_operations_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (492, 'automatically_send_items_expired_before', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (493, 'inventorys_cronjob_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (494, 'inventory_cronjob_notification_recipients', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (495, 'inventory_received_number_prefix', 'NK', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (496, 'next_inventory_received_mumber', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (497, 'inventory_delivery_number_prefix', 'XK', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (498, 'next_inventory_delivery_mumber', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (499, 'internal_delivery_number_prefix', 'ID', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (500, 'next_internal_delivery_mumber', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (501, 'item_sku_prefix', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (502, 'goods_receipt_required_po', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (503, 'goods_delivery_required_po', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (504, 'goods_delivery_pdf_display', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (505, 'display_product_name_when_print_barcode', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (506, 'show_item_cf_on_pdf', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (507, 'goods_delivery_pdf_display_outstanding', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (508, 'goods_delivery_pdf_display_warehouse_lotnumber_bottom_infor', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (509, 'packing_list_number_prefix', 'PL', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (510, 'next_packing_list_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (511, 'wh_return_request_within_x_day', '30', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (512, 'wh_fee_for_return_order', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (513, 'wh_return_policies_information', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (514, 'wh_refund_loyaty_point', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (515, 'order_return_number_prefix', 'ReReturn', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (516, 'next_order_return_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (517, 'e_order_return_number_prefix', 'DEReturn', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (518, 'e_next_order_return_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (519, 'warehouse_receive_return_order ', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (520, 'wh_display_shipment_on_client_portal', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (521, 'wh_on_total_items', '200', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (522, 'whatsapp_api_verification_id', '38690826', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (523, 'whatsapp_api_last_verification', '999999999', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (524, 'whatsapp_api_verified', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (525, 'whatsapp_api_heartbeat', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (526, 'whatsapp_api_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (527, 'task_bookmarks_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (528, 'graphqltoken', '1734317356', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (529, 'current_perfex_version', '321', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (530, 'excluded_uri_for_graphqlintegration_once', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (531, 'si_timesheet_completed_task_allow_add', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (532, 'si_timesheet_completed_task_allow_edit', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (533, 'si_timesheet_show_task_custom_fields', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (534, 'si_timesheet_show_staff_icon_in_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (535, 'si_timesheet_task_status_exclude_add', 'a:0:{}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (536, 'saas_companyname', 'ERP SmartNet GT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (537, 'saas_allowed_files', '.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt,.jpeg,.psd,.ai,.kmz,.dwg,.ppt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (538, 'saas_company_logo', 'd33bf9a5e1bb7471b7534ecfe8e12ff1.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (539, 'saas_company_logo_dark', 'd85f63a4a464cba0dcc2e84805f209c4.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (540, 'saas_favicon', 'favicon.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (541, 'saas_dateformat', 'd-m-Y|%d-%m-%Y', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (542, 'saas_time_format', '24', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (543, 'saas_default_timezone', 'America/Guatemala', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (544, 'saas_active_language', 'spanish', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (545, 'saas_mail_engine', 'phpmailer', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (546, 'saas_email_protocol', 'smtp', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (547, 'saas_microsoft_mail_client_id', 'd', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (548, 'saas_microsoft_mail_client_secret', '+XMWQ0rwL5X7zYHiyLQ=', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (549, 'saas_microsoft_mail_azure_tenant_id', 'd', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (550, 'saas_google_mail_client_id', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (551, 'saas_google_mail_client_secret', '125455/=', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (552, 'saas_smtp_encryption', 'tls', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (553, 'saas_smtp_host', 'd', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (554, 'saas_smtp_port', 'd', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (555, 'saas_smtp_email', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (556, 'saas_smtp_username', 'admin@gmail.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (557, 'saas_smtp_password', '125455', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (558, 'saas_smtp_email_charset', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (559, 'saas_bcc_emails', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (560, 'saas_email_signature', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (561, 'saas_email_header', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (562, 'saas_email_footer', 'e', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (563, 'saas_server', 'cpanel', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (564, 'saas_cpanel_host', 'designtechgt.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (565, 'saas_cpanel_port', '2083', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (566, 'saas_cpanel_username', 'designtech', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (567, 'saas_cpanel_password', '9605c4f0d63893b979de575b393e7196084ea19b2bfdcec75ba0c6013f97c59c92a52b7b54d3db51a7d9d802f4a20eb61ea5257822ce2a02b3591502d2fbbe72s3dCNshVwz5amk22wiK380Z0j1zVZ90GO6nWWV6ukr4=', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (568, 'saas_cpanel_output', 'json', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (569, 'saas_plesk_host', '45.77.230.168', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (570, 'saas_plesk_username', 'admin2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (571, 'saas_plesk_password', '0d5c9a888b93b38243ee37557238881851ed0627b83dfe33c135f6df01c0183fe79a823a77d2c243b734e8c2140e3bf20db727a01f85298f22daa3a36bcb76e0zx5yGhWV/vlsh/8vbFPwNqbA0ADJd4CJ3J1HqvlZ63M=', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (572, 'saas_plesk_webspace_id', 'asdsdasda', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (573, 'saas_paymentmethod_authorize_acceptjs_label', 'Authorize.net Accept.js', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (574, 'saas_paymentmethod_authorize_acceptjs_public_key', 'asddsa', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (575, 'saas_paymentmethod_authorize_acceptjs_api_login_id', 'sdadsa', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (576, 'saas_paymentmethod_authorize_acceptjs_api_transaction_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (577, 'saas_paymentmethod_authorize_acceptjs_description_dashboard', 'asddsa', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (578, 'saas_paymentmethod_authorize_acceptjs_currencies', 'sdadsa', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (579, 'saas_paymentmethod_instamojo_label', 'Instamojo', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (580, 'saas_paymentmethod_instamojo_fee_fixed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (581, 'saas_paymentmethod_instamojo_fee_percent', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (582, 'saas_paymentmethod_instamojo_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (583, 'saas_paymentmethod_instamojo_auth_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (584, 'saas_paymentmethod_instamojo_description_dashboard', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (585, 'saas_paymentmethod_mollie_label', 'Mollie', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (586, 'saas_paymentmethod_mollie_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (587, 'saas_paymentmethod_mollie_description_dashboard', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (588, 'saas_paymentmethod_mollie_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (589, 'saas_paymentmethod_paypal_braintree_label', 'Braintree', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (590, 'saas_paymentmethod_paypal_braintree_merchant_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (591, 'saas_paymentmethod_paypal_braintree_api_public_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (592, 'saas_paymentmethod_paypal_braintree_api_private_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (593, 'saas_paymentmethod_paypal_braintree_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (594, 'saas_paymentmethod_paypal_checkout_label', 'Paypal Smart Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (595, 'saas_paymentmethod_paypal_checkout_fee_fixed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (596, 'saas_paymentmethod_paypal_checkout_fee_percent', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (597, 'saas_paymentmethod_paypal_checkout_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (598, 'saas_paymentmethod_paypal_checkout_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (599, 'saas_paymentmethod_paypal_checkout_payment_description', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (600, 'saas_paymentmethod_paypal_checkout_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (601, 'saas_paymentmethod_paypal_label', 'Paypal', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (602, 'saas_paymentmethod_paypal_fee_fixed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (603, 'saas_paymentmethod_paypal_fee_percent', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (604, 'saas_paymentmethod_paypal_username', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (605, 'saas_paymentmethod_paypal_password', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (606, 'saas_paymentmethod_paypal_signature', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (607, 'saas_paymentmethod_paypal_description_dashboard', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (608, 'saas_paymentmethod_paypal_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (609, 'saas_paymentmethod_payu_money_label', 'PayU Money', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (610, 'saas_paymentmethod_payu_money_fee_fixed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (611, 'saas_paymentmethod_payu_money_fee_percent', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (612, 'saas_paymentmethod_payu_money_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (613, 'saas_paymentmethod_payu_money_salt', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (614, 'saas_paymentmethod_payu_money_description_dashboard', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (615, 'saas_paymentmethod_payu_money_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (616, 'saas_paymentmethod_stripe_label', 'Stripe Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (617, 'saas_paymentmethod_stripe_fee_fixed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (618, 'saas_paymentmethod_stripe_fee_percent', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (619, 'saas_paymentmethod_stripe_api_publishable_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (620, 'saas_paymentmethod_stripe_api_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (621, 'saas_paymentmethod_stripe_description_dashboard', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (622, 'saas_paymentmethod_stripe_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (623, 'saas_paymentmethod_stripe_ideal_label', 'Stripe iDEAL', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (624, 'saas_paymentmethod_stripe_ideal_api_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (625, 'saas_paymentmethod_stripe_ideal_api_publishable_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (626, 'saas_paymentmethod_stripe_ideal_description_dashboard', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (627, 'saas_paymentmethod_stripe_ideal_statement_descriptor', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (628, 'saas_paymentmethod_two_checkout_label', '2Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (629, 'saas_paymentmethod_two_checkout_fee_fixed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (630, 'saas_paymentmethod_two_checkout_fee_percent', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (631, 'saas_paymentmethod_two_checkout_merchant_code', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (632, 'saas_paymentmethod_two_checkout_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (633, 'saas_paymentmethod_two_checkout_description', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (634, 'saas_paymentmethod_two_checkout_currencies', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (635, 'saas_front_pricing_title', 'Nuestros Precios', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (636, 'saas_front_pricing_description', '<p>Comienza a utilizar este grandioso sistema para tu negocio o empresa</p>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (637, 'saas_front_slider', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (638, 'home_slider_speed', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (639, 'saas_server_wildcard', 'on', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (640, 'enable_affiliate', 'TRUE', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (641, 'affiliate_commission_amount', '203', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (642, 'payment_rules_for_affiliates', 'no_payment_required', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (643, 'withdrawal_payment_method', 'a:2:{i:0;s:1:\"1\";i:1;s:9:\"instamojo\";}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (644, 'affiliate_commission_type', 'percentage', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (645, 'affiliate_rule', 'only_first_subscription', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (646, 'saas_calculate_disk_space', 'both', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (647, 'saas_reserved_tenant', 'admin,administrator,root,perfectsaas,acme,saaserp,hack,www', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (648, 'custom_domain_title', 'Dominio Personalizado', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (649, 'saas_default_theme', 'qest', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (650, 'custom_domain_details', '<p>La integración de un dominio personalizado con la configuración DNS normalmente implica los siguientes pasos:</p>\r\n<p><br>Compra un nombre de dominio: deberás comprar un nombre de dominio de un registrador de dominios como GoDaddy, Namecheap o Google Domains.<br>Obtenga sus registros DNS: una vez que tenga un proveedor de dominio, este le proporcionará registros DNS que deberá configurar para su dominio. Estos registros normalmente incluirán un registro A y un registro CNAME.<br>Configure los ajustes de DNS: inicie sesión en la cuenta de su registrador de dominio y navegue hasta la sección de administración de DNS. Debe agregar 2 registros DNS nuevos, elegir el tipo de registro (A y CNAME) y seguir las configuraciones siguientes (Configuración de DNS uno y Configuración de DNS dos). ), e introduzca el valor correspondiente.<br>Espere la propagación: una vez que haya realizado los cambios en la configuración de DNS, los cambios pueden tardar hasta 48 horas en propagarse por Internet. Durante este tiempo, es posible que su sitio web o aplicación no esté disponible temporalmente.<br>¡Eso es todo! Una vez que sus registros DNS se hayan propagado, su dominio personalizado debería estar completamente integrado con nuestra aplicación.</p>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (651, 'minimum_payout_amount', '20', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (652, 'saas_cron_cache', '{\"last_proccessed_company_id\":0,\"cron_last_success_runtime\":1735598832,\"new_module_activation\":0}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (653, 'acc_first_month_of_financial_year', 'January', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (654, 'acc_first_month_of_tax_year', 'same_as_financial_year', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (655, 'acc_accounting_method', 'accrual', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (656, 'acc_close_the_books', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (657, 'acc_allow_changes_after_viewing', 'allow_changes_after_viewing_a_warning', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (658, 'acc_close_book_password', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (659, 'acc_close_book_passwordr', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (660, 'acc_enable_account_numbers', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (661, 'acc_show_account_numbers', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (662, 'acc_closing_date', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (663, 'acc_add_default_account', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (664, 'acc_add_default_account_new', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (665, 'acc_automatic_conversion', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (666, 'acc_invoice_payment_account', '66', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (667, 'acc_invoice_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (668, 'acc_payment_payment_account', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (669, 'acc_payment_deposit_to', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (670, 'acc_expense_payment_account', '13', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (671, 'acc_expense_deposit_to', '37', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (672, 'acc_tax_payment_account', '29', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (673, 'acc_tax_deposit_to', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (674, 'recruitment_create_campaign_with_plan', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (675, 'saas_landing_page_url', 'https://smarterp.smartnetgt.com', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (676, 'saas_landing_page_url_mode', 'default', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (677, 'disable_email_verification', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (678, 'done_server_settings', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (679, 'created_sample_database', 'designtech_company_seed_1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (680, 'custom_domain_ip_address', '192.250.227.14', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (681, 'saas_buy_now_page', 'modal', 1);


#
# TABLE STRUCTURE FOR: tblp_t_form_question_box_description
#

DROP TABLE IF EXISTS `tblp_t_form_question_box_description`;

CREATE TABLE `tblp_t_form_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  `correct` int(11) DEFAULT 1 COMMENT '0: correct 1: incorrect',
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpayment_attempts
#

DROP TABLE IF EXISTS `tblpayment_attempts`;

CREATE TABLE `tblpayment_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `fee` double NOT NULL,
  `payment_gateway` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblpayment_modes
#

DROP TABLE IF EXISTS `tblpayment_modes`;

CREATE TABLE `tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblpayment_modes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES (1, 'Bank', NULL, 0, 0, 0, 1, 1);


#
# TABLE STRUCTURE FOR: tblpayroll_table
#

DROP TABLE IF EXISTS `tblpayroll_table`;

CREATE TABLE `tblpayroll_table` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payroll_month` date NOT NULL,
  `payroll_type` int(11) unsigned DEFAULT NULL,
  `template_data` longtext DEFAULT NULL,
  `status` int(11) unsigned DEFAULT 0 COMMENT '1:đã chốt 0:chưa chốt',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpayroll_type
#

DROP TABLE IF EXISTS `tblpayroll_type`;

CREATE TABLE `tblpayroll_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `payroll_type_name` varchar(100) NOT NULL,
  `department_id` longtext DEFAULT NULL,
  `role_id` longtext DEFAULT NULL,
  `position_id` longtext DEFAULT NULL,
  `salary_form_id` int(11) unsigned DEFAULT NULL COMMENT '1:Chính 2:Phụ cấp',
  `manager_id` int(11) unsigned DEFAULT NULL,
  `follower_id` int(11) unsigned DEFAULT NULL,
  `template` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpinned_projects
#

DROP TABLE IF EXISTS `tblpinned_projects`;

CREATE TABLE `tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblposition_training_question_form
#

DROP TABLE IF EXISTS `tblposition_training_question_form`;

CREATE TABLE `tblposition_training_question_form` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblproject_activity
#

DROP TABLE IF EXISTS `tblproject_activity`;

CREATE TABLE `tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_files
#

DROP TABLE IF EXISTS `tblproject_files`;

CREATE TABLE `tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` longtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` mediumtext DEFAULT NULL,
  `thumbnail_link` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_members
#

DROP TABLE IF EXISTS `tblproject_members`;

CREATE TABLE `tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_notes
#

DROP TABLE IF EXISTS `tblproject_notes`;

CREATE TABLE `tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_settings
#

DROP TABLE IF EXISTS `tblproject_settings`;

CREATE TABLE `tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_status_can_change
#

DROP TABLE IF EXISTS `tblproject_status_can_change`;

CREATE TABLE `tblproject_status_can_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_status_id` int(11) NOT NULL,
  `project_status_id_can_change_to` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_status_can_change_project_status_id` (`project_status_id`),
  KEY `project_status_can_change_project_status_id_2` (`project_status_id_can_change_to`),
  CONSTRAINT `project_status_can_change_project_status_id` FOREIGN KEY (`project_status_id`) REFERENCES `tblproject_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_status_can_change_project_status_id_2` FOREIGN KEY (`project_status_id_can_change_to`) REFERENCES `tblproject_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproject_statuses
#

DROP TABLE IF EXISTS `tblproject_statuses`;

CREATE TABLE `tblproject_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `name` text NOT NULL,
  `color` text NOT NULL,
  `filter_default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tblproject_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (1, 1, 'No iniciado', '#475569', 1);
INSERT INTO `tblproject_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (2, 2, 'En desarrollo', '#2563eb', 1);
INSERT INTO `tblproject_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (3, 3, 'En espera', '#f97316', 1);
INSERT INTO `tblproject_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (4, 5, 'Finalizado', '#16a34a', 0);
INSERT INTO `tblproject_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (5, 4, 'Cancelado', '#94a3b8', 0);


#
# TABLE STRUCTURE FOR: tblprojectdiscussioncomments
#

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;

CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblprojectdiscussions
#

DROP TABLE IF EXISTS `tblprojectdiscussions`;

CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproposal_comments
#

DROP TABLE IF EXISTS `tblproposal_comments`;

CREATE TABLE `tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) DEFAULT 1,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  `processing` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblprovince_city
#

DROP TABLE IF EXISTS `tblprovince_city`;

CREATE TABLE `tblprovince_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province_code` varchar(45) NOT NULL,
  `province_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_approval_details
#

DROP TABLE IF EXISTS `tblpur_approval_details`;

CREATE TABLE `tblpur_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_approval_setting
#

DROP TABLE IF EXISTS `tblpur_approval_setting`;

CREATE TABLE `tblpur_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_contacts
#

DROP TABLE IF EXISTS `tblpur_contacts`;

CREATE TABLE `tblpur_contacts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_contracts
#

DROP TABLE IF EXISTS `tblpur_contracts`;

CREATE TABLE `tblpur_contracts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(200) NOT NULL,
  `contract_name` varchar(200) NOT NULL,
  `content` longtext DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `pur_order` int(11) NOT NULL,
  `contract_value` decimal(15,0) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `buyer` int(11) DEFAULT NULL,
  `time_payment` date DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `signed` int(32) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `signer` int(11) DEFAULT NULL,
  `signed_date` date DEFAULT NULL,
  `signed_status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_estimate_detail
#

DROP TABLE IF EXISTS `tblpur_estimate_detail`;

CREATE TABLE `tblpur_estimate_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_estimate` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,0) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `into_money` decimal(15,0) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,0) DEFAULT NULL,
  `total_money` decimal(15,0) DEFAULT NULL,
  `discount_money` decimal(15,0) DEFAULT NULL,
  `discount_%` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_estimates
#

DROP TABLE IF EXISTS `tblpur_estimates`;

CREATE TABLE `tblpur_estimates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `vendor` int(11) NOT NULL,
  `deleted_vendor_name` varchar(100) DEFAULT NULL,
  `pur_request` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `vendornote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_order_detail
#

DROP TABLE IF EXISTS `tblpur_order_detail`;

CREATE TABLE `tblpur_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,0) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `into_money` decimal(15,0) DEFAULT NULL,
  `tax` text DEFAULT NULL,
  `total` decimal(15,0) DEFAULT NULL,
  `discount_%` decimal(15,0) DEFAULT NULL,
  `discount_money` decimal(15,0) DEFAULT NULL,
  `total_money` decimal(15,0) DEFAULT NULL,
  `wh_quantity_received` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_order_payment
#

DROP TABLE IF EXISTS `tblpur_order_payment`;

CREATE TABLE `tblpur_order_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` longtext DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_orders
#

DROP TABLE IF EXISTS `tblpur_orders`;

CREATE TABLE `tblpur_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pur_order_name` varchar(100) NOT NULL,
  `vendor` int(11) NOT NULL,
  `estimate` int(11) NOT NULL,
  `pur_order_number` varchar(30) NOT NULL,
  `order_date` date NOT NULL,
  `status` int(32) NOT NULL DEFAULT 1,
  `approve_status` int(32) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `days_owed` int(11) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `vendornote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `buyer` int(11) NOT NULL DEFAULT 0,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_request
#

DROP TABLE IF EXISTS `tblpur_request`;

CREATE TABLE `tblpur_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_rq_code` varchar(45) NOT NULL,
  `pur_rq_name` varchar(100) NOT NULL,
  `rq_description` text DEFAULT NULL,
  `requester` int(11) NOT NULL,
  `department` int(11) NOT NULL,
  `request_date` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  `status_goods` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_request_detail
#

DROP TABLE IF EXISTS `tblpur_request_detail`;

CREATE TABLE `tblpur_request_detail` (
  `prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `pur_request` int(11) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,0) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `into_money` decimal(15,0) DEFAULT NULL,
  `inventory_quantity` int(11) NOT NULL,
  PRIMARY KEY (`prd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_unit
#

DROP TABLE IF EXISTS `tblpur_unit`;

CREATE TABLE `tblpur_unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpur_vendor
#

DROP TABLE IF EXISTS `tblpur_vendor`;

CREATE TABLE `tblpur_vendor` (
  `userid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) DEFAULT NULL,
  `vat` varchar(200) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblpur_vendor_admin
#

DROP TABLE IF EXISTS `tblpur_vendor_admin`;

CREATE TABLE `tblpur_vendor_admin` (
  `staff_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblpurchase_option
#

DROP TABLE IF EXISTS `tblpurchase_option`;

CREATE TABLE `tblpurchase_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblpurchase_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (1, 'purchase_order_setting', '1', 1);


#
# TABLE STRUCTURE FOR: tblrec_campaign
#

DROP TABLE IF EXISTS `tblrec_campaign`;

CREATE TABLE `tblrec_campaign` (
  `cp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) NOT NULL,
  `campaign_name` varchar(200) NOT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) NOT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date NOT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) NOT NULL,
  `cp_date_add` date NOT NULL,
  `cp_status` int(11) NOT NULL,
  `display_salary` int(15) DEFAULT NULL,
  `rec_channel_form_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  PRIMARY KEY (`cp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_campaign_form_web
#

DROP TABLE IF EXISTS `tblrec_campaign_form_web`;

CREATE TABLE `tblrec_campaign_form_web` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign_id` int(11) NOT NULL,
  `form_type` int(11) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `r_form_name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`,`rec_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_candidate
#

DROP TABLE IF EXISTS `tblrec_candidate`;

CREATE TABLE `tblrec_candidate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rec_campaign` int(11) DEFAULT NULL,
  `candidate_code` varchar(200) NOT NULL,
  `candidate_name` varchar(200) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `birthplace` text DEFAULT NULL,
  `home_town` text DEFAULT NULL,
  `identification` varchar(45) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `place_of_issue` varchar(255) DEFAULT NULL,
  `marital_status` varchar(11) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `nation` varchar(100) NOT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `introduce_yourself` text DEFAULT NULL,
  `phonenumber` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `skype` text DEFAULT NULL,
  `facebook` text DEFAULT NULL,
  `resident` text DEFAULT NULL,
  `current_accommodation` text DEFAULT NULL,
  `status` int(11) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `desired_salary` decimal(15,0) DEFAULT NULL,
  `date_add` date DEFAULT NULL,
  `recruitment_channel` int(11) DEFAULT NULL,
  `skill` text DEFAULT NULL,
  `interests` text DEFAULT NULL,
  `linkedin` text DEFAULT NULL,
  `alternate_contact_number` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_cd_evaluation
#

DROP TABLE IF EXISTS `tblrec_cd_evaluation`;

CREATE TABLE `tblrec_cd_evaluation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria` int(11) NOT NULL,
  `rate_score` int(11) NOT NULL,
  `assessor` int(11) NOT NULL,
  `evaluation_date` datetime NOT NULL,
  `percent` int(11) NOT NULL,
  `candidate` int(11) NOT NULL,
  `feedback` text NOT NULL,
  `group_criteria` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_company
#

DROP TABLE IF EXISTS `tblrec_company`;

CREATE TABLE `tblrec_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL,
  `company_description` text DEFAULT NULL,
  `company_address` varchar(200) DEFAULT NULL,
  `company_industry` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_criteria
#

DROP TABLE IF EXISTS `tblrec_criteria`;

CREATE TABLE `tblrec_criteria` (
  `criteria_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `criteria_type` varchar(45) NOT NULL,
  `criteria_title` varchar(200) NOT NULL,
  `group_criteria` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  `score_des1` text DEFAULT NULL,
  `score_des2` text DEFAULT NULL,
  `score_des3` text DEFAULT NULL,
  `score_des4` text DEFAULT NULL,
  `score_des5` text DEFAULT NULL,
  PRIMARY KEY (`criteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_evaluation_form
#

DROP TABLE IF EXISTS `tblrec_evaluation_form`;

CREATE TABLE `tblrec_evaluation_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date DEFAULT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_interview
#

DROP TABLE IF EXISTS `tblrec_interview`;

CREATE TABLE `tblrec_interview` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign` int(11) NOT NULL,
  `is_name` varchar(100) NOT NULL,
  `interview_day` varchar(200) NOT NULL,
  `from_time` text NOT NULL,
  `to_time` text NOT NULL,
  `from_hours` datetime DEFAULT NULL,
  `to_hours` datetime DEFAULT NULL,
  `interviewer` text NOT NULL,
  `added_from` int(11) NOT NULL,
  `added_date` date NOT NULL,
  `position` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_job_position
#

DROP TABLE IF EXISTS `tblrec_job_position`;

CREATE TABLE `tblrec_job_position` (
  `position_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `position_name` varchar(200) NOT NULL,
  `position_description` text DEFAULT NULL,
  `industry_id` int(15) DEFAULT NULL,
  `company_id` int(15) DEFAULT NULL,
  `job_skill` text DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_list_criteria
#

DROP TABLE IF EXISTS `tblrec_list_criteria`;

CREATE TABLE `tblrec_list_criteria` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_form` int(11) NOT NULL,
  `group_criteria` int(11) NOT NULL,
  `evaluation_criteria` int(11) NOT NULL,
  `percent` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_proposal
#

DROP TABLE IF EXISTS `tblrec_proposal`;

CREATE TABLE `tblrec_proposal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_name` varchar(200) NOT NULL,
  `position` int(11) NOT NULL,
  `department` int(11) DEFAULT NULL,
  `amount_recruiment` int(11) DEFAULT NULL,
  `form_work` varchar(45) DEFAULT NULL,
  `workplace` varchar(255) DEFAULT NULL,
  `salary_from` decimal(15,0) DEFAULT NULL,
  `salary_to` decimal(15,0) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date NOT NULL,
  `reason_recruitment` text DEFAULT NULL,
  `job_description` text DEFAULT NULL,
  `approver` int(11) NOT NULL,
  `ages_from` int(11) DEFAULT NULL,
  `ages_to` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `literacy` varchar(200) DEFAULT NULL,
  `experience` varchar(200) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `date_add` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_set_transfer_record
#

DROP TABLE IF EXISTS `tblrec_set_transfer_record`;

CREATE TABLE `tblrec_set_transfer_record` (
  `set_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `send_to` varchar(45) NOT NULL,
  `email_to` text DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `subject` text NOT NULL,
  `content` text DEFAULT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_skill
#

DROP TABLE IF EXISTS `tblrec_skill`;

CREATE TABLE `tblrec_skill` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skill_name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrec_transfer_records
#

DROP TABLE IF EXISTS `tblrec_transfer_records`;

CREATE TABLE `tblrec_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` varchar(11) DEFAULT NULL,
  `staff_identifi` varchar(20) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblrecords_meta
#

DROP TABLE IF EXISTS `tblrecords_meta`;

CREATE TABLE `tblrecords_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (1, 'staff_identifi', 'staff_identifi');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (2, 'firstname', 'firstname');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (3, 'email', 'email');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (4, 'phonenumber', 'phonenumber');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (5, 'facebook', 'facebook');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (6, 'skype', 'skype');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (7, 'birthday', 'birthday');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (8, 'birthplace', 'birthplace');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (9, 'home_town', 'home_town');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (10, 'marital_status', 'marital_status');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (11, 'nation', 'nation');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (12, 'religion', 'religion');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (13, 'identification', 'identification');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (14, 'days_for_identity', 'days_for_identity');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (15, 'place_of_issue', 'place_of_issue');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (16, 'resident', 'resident');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (17, 'current_address', 'current_address');
INSERT INTO `tblrecords_meta` (`id`, `name`, `meta`) VALUES (18, 'literacy', 'literacy');


#
# TABLE STRUCTURE FOR: tblrelated_items
#

DROP TABLE IF EXISTS `tblrelated_items`;

CREATE TABLE `tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblreminders
#

DROP TABLE IF EXISTS `tblreminders`;

CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblrequest
#

DROP TABLE IF EXISTS `tblrequest`;

CREATE TABLE `tblrequest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `request_type_id` varchar(45) DEFAULT NULL,
  `date_create` datetime NOT NULL,
  `approval_deadline` datetime DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `code` varchar(255) DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_approval_details
#

DROP TABLE IF EXISTS `tblrequest_approval_details`;

CREATE TABLE `tblrequest_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `staffid` varchar(255) NOT NULL,
  `approve` varchar(45) NOT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT 0,
  `action` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_files
#

DROP TABLE IF EXISTS `tblrequest_files`;

CREATE TABLE `tblrequest_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `filetype` varchar(255) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_follow
#

DROP TABLE IF EXISTS `tblrequest_follow`;

CREATE TABLE `tblrequest_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` varchar(45) DEFAULT NULL,
  `staffid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_form
#

DROP TABLE IF EXISTS `tblrequest_form`;

CREATE TABLE `tblrequest_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `value` varchar(255) NOT NULL,
  `slug` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_log
#

DROP TABLE IF EXISTS `tblrequest_log`;

CREATE TABLE `tblrequest_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` varchar(45) DEFAULT NULL,
  `staffid` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_related
#

DROP TABLE IF EXISTS `tblrequest_related`;

CREATE TABLE `tblrequest_related` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `rel_id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_type
#

DROP TABLE IF EXISTS `tblrequest_type`;

CREATE TABLE `tblrequest_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `maximum_number_day` varchar(45) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `data_chart` longtext NOT NULL,
  `active` varchar(45) NOT NULL DEFAULT '1',
  `related_to` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_type_form
#

DROP TABLE IF EXISTS `tblrequest_type_form`;

CREATE TABLE `tblrequest_type_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_type_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblrequest_type_workflow
#

DROP TABLE IF EXISTS `tblrequest_type_workflow`;

CREATE TABLE `tblrequest_type_workflow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_type_id` varchar(45) NOT NULL,
  `staffid` varchar(255) NOT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (1, 'Employee', NULL);
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (2, 'Huawei Site', 'a:23:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"customers\";a:1:{i:0;s:4:\"view\";}s:8:\"expenses\";a:4:{i:0;s:8:\"view_own\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"items\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"create\";}s:14:\"knowledge_base\";a:3:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:8:\"projects\";a:5:{i:0;s:4:\"view\";i:1;s:4:\"edit\";i:2;s:17:\"create_milestones\";i:3;s:15:\"edit_milestones\";i:4;s:17:\"delete_milestones\";}s:7:\"reports\";a:2:{i:0;s:4:\"view\";i:1;s:15:\"view-timesheets\";}s:5:\"tasks\";a:2:{i:0;s:6:\"create\";i:1;s:4:\"edit\";}s:19:\"checklist_templates\";a:2:{i:0;s:6:\"create\";i:1;s:6:\"delete\";}s:12:\"whatsapp_api\";a:1:{i:0;s:18:\"broadcast_messages\";}s:9:\"warehouse\";a:3:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:21:\"attendance_management\";a:1:{i:0;s:8:\"view_own\";}s:16:\"leave_management\";a:1:{i:0;s:8:\"view_own\";}s:16:\"route_management\";a:1:{i:0;s:8:\"view_own\";}s:32:\"additional_timesheets_management\";a:1:{i:0;s:8:\"view_own\";}s:26:\"table_shiftwork_management\";a:1:{i:0;s:8:\"view_own\";}s:17:\"report_management\";a:1:{i:0;s:8:\"view_own\";}s:26:\"table_workplace_management\";a:1:{i:0;s:8:\"view_own\";}s:8:\"purchase\";a:3:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:10:\"wiki_books\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:13:\"wiki_articles\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:12:\"si_timesheet\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:14:\"task_bookmarks\";a:1:{i:0;s:4:\"view\";}}');


#
# TABLE STRUCTURE FOR: tblsalary_form
#

DROP TABLE IF EXISTS `tblsalary_form`;

CREATE TABLE `tblsalary_form` (
  `form_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  `salary_val` decimal(15,2) NOT NULL,
  `tax` tinyint(1) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblsales_activity
#

DROP TABLE IF EXISTS `tblsales_activity`;

CREATE TABLE `tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` mediumtext DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblscheduled_emails
#

DROP TABLE IF EXISTS `tblscheduled_emails`;

CREATE TABLE `tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` mediumtext DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblservices
#

DROP TABLE IF EXISTS `tblservices`;

CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('008sep9j1kt9f3nhnpgmmh2u2icneh2m', '192.250.227.14', 1735588273, '__ci_last_regenerate|i:1735588272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01f3e4bmvqsqklhultje5vd6693bh3cp', '192.250.227.14', 1735580772, '__ci_last_regenerate|i:1735580772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01hebh4jsbiqrtcsqk5m8234svalvfju', '192.250.227.14', 1735589112, '__ci_last_regenerate|i:1735589112;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01job301gtqgur1qudocg79rejr2q56j', '192.250.227.14', 1735581073, '__ci_last_regenerate|i:1735581072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02e5udm8lgek277fua0ojciiqrvoo2fr', '192.250.227.14', 1735573332, '__ci_last_regenerate|i:1735573332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('06lfs2q4dttvn3k9g2sdgneifgq6qf7u', '192.250.227.14', 1735565352, '__ci_last_regenerate|i:1735565352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('08d4a8isjdbl87eh42e9bfvjuoo7hejf', '192.250.227.14', 1735595892, '__ci_last_regenerate|i:1735595892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('08nptip68qb9ldcsbip5o17m0i0jrpbc', '192.250.227.14', 1735561814, '__ci_last_regenerate|i:1735561814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('092ru4v7r3o5c6mka99acd2bcon4uevo', '192.250.227.14', 1735587373, '__ci_last_regenerate|i:1735587372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ak47jtc7lp0aen0v3utgpq086hh9uq6', '192.250.227.14', 1735557132, '__ci_last_regenerate|i:1735557132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b428rmd7hd0km71d3kdq8q9mgnu3p10', '192.250.227.14', 1735566913, '__ci_last_regenerate|i:1735566913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0bsuos7bamrva8e6k7nphl7g6juvqqob', '192.250.227.14', 1735574472, '__ci_last_regenerate|i:1735574472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0cqm55mpipla4f0i8tbt7ijq8itt35v2', '192.250.227.14', 1735581132, '__ci_last_regenerate|i:1735581132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d0suelnhae27jb41u8omouc4t13aab6', '192.250.227.14', 1735559173, '__ci_last_regenerate|i:1735559172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0dv7e3svgrcvu9k39c4qggrpvjsk70b9', '192.250.227.14', 1735560914, '__ci_last_regenerate|i:1735560914;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0en2jbts1mcvq4f0f7apm8b38jv0qm4l', '192.250.227.14', 1735571832, '__ci_last_regenerate|i:1735571832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f45ot1d499u1sudlcunrnn9c1q937eg', '192.250.227.14', 1735570215, '__ci_last_regenerate|i:1735570214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f809p12qaouctpcivdqn8jmm9l1o59q', '192.250.227.14', 1735569973, '__ci_last_regenerate|i:1735569973;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0g2a3usrmph2rrumsvd67gd9ciheto3o', '181.174.105.63', 1735599041, '__ci_last_regenerate|i:1735598928;staff_user_id|s:1:\"1\";staff_logged_in|b:1;db_name|N;_prev_url|s:44:\"https://smarterp.smartnetgt.com/admin/backup\";setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0grs1aoq8gi6u3un4qj5rb7ucdcj03un', '192.250.227.14', 1735568892, '__ci_last_regenerate|i:1735568892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0h0fm4mq7vc48tn6n6e7vev62dvelou5', '192.250.227.14', 1735598592, '__ci_last_regenerate|i:1735598592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0h2r800t2e5bf4q00dvf970oik4hnac5', '192.250.227.14', 1735583292, '__ci_last_regenerate|i:1735583292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0iguirv8k6014aqs889ufemj2p4e1j8f', '192.250.227.14', 1735574713, '__ci_last_regenerate|i:1735574713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0jmmf70tt14r7dr73annhltk8g6dssv9', '192.250.227.14', 1735549813, '__ci_last_regenerate|i:1735549813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0nrp4rpjuothpqfqc6utbrd4i1bm6pcq', '192.250.227.14', 1735585092, '__ci_last_regenerate|i:1735585092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0pbr6uikm9n6dhfc6htoj1fg95tlifk3', '192.250.227.14', 1735566193, '__ci_last_regenerate|i:1735566193;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0qu4c6sb3eo58elh7a013j1boe4djsku', '192.250.227.14', 1735546213, '__ci_last_regenerate|i:1735546212;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0r263iob3ikvstii028cg8j7fj9n42e1', '192.250.227.14', 1735576092, '__ci_last_regenerate|i:1735576092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0snglsdefh62a63ij31jf43qkd93uhm5', '192.250.227.14', 1735551672, '__ci_last_regenerate|i:1735551672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0u867nbn619vsjpnvjkgb93bdbtgp2dg', '192.250.227.14', 1735589773, '__ci_last_regenerate|i:1735589772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0val9rcm4i7i8u6e1nk249si8ob8fbdq', '192.250.227.14', 1735588092, '__ci_last_regenerate|i:1735588092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11mgauud50k1sc9u89f5j8cc03isdu66', '192.250.227.14', 1735558452, '__ci_last_regenerate|i:1735558452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12irp8tpvsui2g1rlee7g4ptoe8sitkb', '192.250.227.14', 1735551793, '__ci_last_regenerate|i:1735551792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12vi089nb951u71955jmhh6hbdg80pof', '192.250.227.14', 1735577953, '__ci_last_regenerate|i:1735577952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14r4t9m03c7128fces0r5gri85ijv95q', '192.250.227.14', 1735555033, '__ci_last_regenerate|i:1735555033;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15kqbiag8nek3dkbedbvnsld6cag3usd', '192.250.227.14', 1735598413, '__ci_last_regenerate|i:1735598412;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('171tdh5og56311h2c1u442dvdqhpe9pm', '192.250.227.14', 1735542793, '__ci_last_regenerate|i:1735542792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('173rgfmbsc0b9f7kvl0l4eh05709of8d', '192.250.227.14', 1735593672, '__ci_last_regenerate|i:1735593671;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('180vj0unedgr4uqj2vud1p710vephq6j', '192.250.227.14', 1735571352, '__ci_last_regenerate|i:1735571352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1839m31an1fjuri5d1ohhpg113glgg0q', '192.250.227.14', 1735585992, '__ci_last_regenerate|i:1735585992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('19tllhs2p9arplvh9ce8fnhjl20nnegm', '192.250.227.14', 1735553652, '__ci_last_regenerate|i:1735553652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1aa4brv4ae2kq317g5fja9qrsjkq64qf', '192.250.227.14', 1735552213, '__ci_last_regenerate|i:1735552213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1c3lg1pkvn80ub04deel9g8jb5rarf5v', '192.250.227.14', 1735597692, '__ci_last_regenerate|i:1735597692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1debn1fd2pm5ouiqlvm5gflhbuejr2hv', '192.250.227.14', 1735573692, '__ci_last_regenerate|i:1735573692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1edmcdksqbpk043gjs3n8g6dn919j5rj', '192.250.227.14', 1735593013, '__ci_last_regenerate|i:1735593013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1eet807scqcj99o388v2v7uu6p7d8tk3', '192.250.227.14', 1735546033, '__ci_last_regenerate|i:1735546033;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fmgrdu3o8ij8qdgg1migafjvlr0fhvp', '192.250.227.14', 1735555633, '__ci_last_regenerate|i:1735555633;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1g29r23mphjqpa2he8lc9lbghmhb4mcs', '192.250.227.14', 1735555214, '__ci_last_regenerate|i:1735555214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1gj3n1chvqmmnvsh8k3blo9kisi6ghsp', '192.250.227.14', 1735564151, '__ci_last_regenerate|i:1735564151;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1gvuu17nscd548rr1ajl8t8cucadoj4q', '192.250.227.14', 1735563013, '__ci_last_regenerate|i:1735563013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1h0di2nbllvq2fk5rq89mjv4ak4gponk', '192.250.227.14', 1735574415, '__ci_last_regenerate|i:1735574415;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1i5icuu5bssv1s6qgl3p8me1qk8gfmqe', '192.250.227.14', 1735578972, '__ci_last_regenerate|i:1735578972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ic1p4btc5ormj452daoiban5imal7f8', '192.250.227.14', 1735545492, '__ci_last_regenerate|i:1735545492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1it4nmhjhvkbrjht3rbhdt3749l8l180', '192.250.227.14', 1735546572, '__ci_last_regenerate|i:1735546572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1jn4lteraln2gboqhh4oat79us7c4hft', '192.250.227.14', 1735597453, '__ci_last_regenerate|i:1735597453;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1m3v52f36v2t4godakhlpvpulhrqej7j', '192.250.227.14', 1735563616, '__ci_last_regenerate|i:1735563615;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1magltlak4f1dc9ngh2m4b1gq7rp47vr', '192.250.227.14', 1735553472, '__ci_last_regenerate|i:1735553472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1mi0eq9mhmh0dgm5gdj1n5rdjfa0jib8', '192.250.227.14', 1735584552, '__ci_last_regenerate|i:1735584552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1n0rsjkbq4k5eu0s1iuqms6kna94gqik', '192.250.227.14', 1735584972, '__ci_last_regenerate|i:1735584972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1o5jdcs8bqo7sio27n9k6t93h36isjp8', '192.250.227.14', 1735575613, '__ci_last_regenerate|i:1735575613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1oge8d83i286s29fgt0sft876as6vbrg', '192.250.227.14', 1735552872, '__ci_last_regenerate|i:1735552872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1opnq9piq07pk0ak17q2aq5bqo29f4hb', '192.250.227.14', 1735547892, '__ci_last_regenerate|i:1735547892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1p1o1bg8udn2cn446dgsuc4b99q12jvt', '192.250.227.14', 1735584013, '__ci_last_regenerate|i:1735584013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1p5gkc17d9eqijofghntpn1a68n854uj', '192.250.227.14', 1735587792, '__ci_last_regenerate|i:1735587792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1r56ob6tvn08ss83fo0qghhhqd48cr57', '192.250.227.14', 1735543513, '__ci_last_regenerate|i:1735543513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1t7vli1plld87fii6edd1tv44c7o048q', '192.250.227.14', 1735563792, '__ci_last_regenerate|i:1735563792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1vl87obn2a5od4oaic2dsmna1gjhm0o5', '192.250.227.14', 1735591752, '__ci_last_regenerate|i:1735591752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('229nlqnfu7v1e4ed5a1jutkr0n7do4rt', '192.250.227.14', 1735558992, '__ci_last_regenerate|i:1735558992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23ovni92m7h6ubhlgoag2cjrcksbfc6r', '192.250.227.14', 1735554552, '__ci_last_regenerate|i:1735554552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('23t9reb7pgmtg8gi5raiegev8pidgl2d', '192.250.227.14', 1735571952, '__ci_last_regenerate|i:1735571952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24h65vjkvh7h5andvi8ejb1h8ggqp5rg', '192.250.227.14', 1735562352, '__ci_last_regenerate|i:1735562352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('258cm2284b8shbs930kv8bk64jjuedlo', '192.250.227.14', 1735567931, '__ci_last_regenerate|i:1735567931;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25kknnpqc6teilkaith7ftoj46mqotkg', '192.250.227.14', 1735590433, '__ci_last_regenerate|i:1735590432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('26vl16f7hngcih7k8100qtrlkaj99nth', '192.250.227.14', 1735571713, '__ci_last_regenerate|i:1735571713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('27d5m0bcn6ufskiv91ie9biekjp7siml', '192.250.227.14', 1735594752, '__ci_last_regenerate|i:1735594752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('281u9ahl07c6vij2t10stl01n6e387k7', '192.250.227.14', 1735589414, '__ci_last_regenerate|i:1735589414;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29dgutsmi129n74rkgs3mrej2m6g64gr', '192.250.227.14', 1735575132, '__ci_last_regenerate|i:1735575132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2a0oh02m03l17eai0au4a9m33cq8311q', '192.250.227.14', 1735589893, '__ci_last_regenerate|i:1735589893;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2acq4r4c4ihl4bgjlid2nlpasje3985j', '192.250.227.14', 1735559413, '__ci_last_regenerate|i:1735559413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2adumq9bs01u9osptebt57n4na7pu11l', '192.250.227.14', 1735562233, '__ci_last_regenerate|i:1735562233;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ariv1sv4se8m8h1vcqfl48eeo4dr63o', '192.250.227.14', 1735570452, '__ci_last_regenerate|i:1735570452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b5jqrmqtudi2d7hu90p052lqfp5lcid', '192.250.227.14', 1735559833, '__ci_last_regenerate|i:1735559833;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2di8q6mpoeeq0mb01g45infl8q65b8cp', '192.250.227.14', 1735570152, '__ci_last_regenerate|i:1735570152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ejjba20invc3o17h2aoic8cd2rqj41e', '192.250.227.14', 1735568773, '__ci_last_regenerate|i:1735568772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2j1ljiphaclcku419qq54qbrbflr5mjo', '192.250.227.14', 1735545013, '__ci_last_regenerate|i:1735545013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2j3503vo3dmu7fofr56dsc000fg6aslo', '192.250.227.14', 1735594514, '__ci_last_regenerate|i:1735594514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2jl64sdj34c7j0qhtki6r8folni42b3t', '192.250.227.14', 1735581553, '__ci_last_regenerate|i:1735581553;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2l5d8uubbuc0aufbmdhpvhrdbdgtum4s', '192.250.227.14', 1735569252, '__ci_last_regenerate|i:1735569252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2qpnemlaea0nqk86reeclio0uueup7pb', '192.250.227.14', 1735580053, '__ci_last_regenerate|i:1735580053;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2rbd9f1bj0qcruf0smdd7f1r5avahj3v', '192.250.227.14', 1735563253, '__ci_last_regenerate|i:1735563253;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2soqeuksisod880m7kq2m06n8nth0uhc', '192.250.227.14', 1735594152, '__ci_last_regenerate|i:1735594152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2tia1n00f16ig5kci3uhlgauq9mekr7h', '192.250.227.14', 1735583713, '__ci_last_regenerate|i:1735583713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2tscl7lm26v5uo0j9tjm1kbak2nohnhb', '192.250.227.14', 1735587614, '__ci_last_regenerate|i:1735587613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2ue1lls0tjvcfhqvsl68qt1fb2239g4j', '192.250.227.14', 1735570392, '__ci_last_regenerate|i:1735570392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2uq3cjie1jcpfg9svfbt9ugjps2f5dg6', '192.250.227.14', 1735566613, '__ci_last_regenerate|i:1735566613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2veip9igjcrgo0giopb31pm3s65hjj9l', '192.250.227.14', 1735589592, '__ci_last_regenerate|i:1735589592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32v902v8oa2crseq113keffk4dvisrq0', '192.250.227.14', 1735597814, '__ci_last_regenerate|i:1735597814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('33sfm73ikklc400fvlikh6ig6qukq0pa', '192.250.227.14', 1735549872, '__ci_last_regenerate|i:1735549872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('363haafcn9eb5reaf2q3f7ieen2mcq70', '192.250.227.14', 1735569133, '__ci_last_regenerate|i:1735569133;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36kasqnl1ht8a963po5n1ib6mrsd21hb', '192.250.227.14', 1735594873, '__ci_last_regenerate|i:1735594873;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36opecqklkbht5e7uinr9q1j0so794g1', '192.250.227.14', 1735546752, '__ci_last_regenerate|i:1735546752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39e4g9dd15kuprkqt2rdjk25kj9t0k0p', '192.250.227.14', 1735553772, '__ci_last_regenerate|i:1735553772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3a8ps0dknk2pmhs5djbabtmb58vvg02h', '192.250.227.14', 1735572973, '__ci_last_regenerate|i:1735572973;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3bj79q1i5hnmmhnt15bql7lah857vj8e', '192.250.227.14', 1735557072, '__ci_last_regenerate|i:1735557072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d03la8ouvi0v1mnu3oebl90lmnkk55i', '192.250.227.14', 1735565414, '__ci_last_regenerate|i:1735565414;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3dmbjt6s3hdardu3iibvaauincmrvco2', '192.250.227.14', 1735584851, '__ci_last_regenerate|i:1735584851;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3fp3dq0ktk2250724u0s8jhnke2uduno', '192.250.227.14', 1735592592, '__ci_last_regenerate|i:1735592592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3h577ns375sof71q7dq3ijijhoraiatn', '192.250.227.14', 1735573452, '__ci_last_regenerate|i:1735573452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3i4l9g5fc4kipq4qd932ag13cpn18evv', '192.250.227.14', 1735572193, '__ci_last_regenerate|i:1735572193;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3jg81aj0kt5f74hmjabh1df5et4e75a7', '192.250.227.14', 1735577714, '__ci_last_regenerate|i:1735577713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3jgpag35gpqfeuhhscu7v117g3ho329c', '192.250.227.14', 1735557552, '__ci_last_regenerate|i:1735557552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3kjvkb6b0aorv020n3t7ognvboemldsd', '192.250.227.14', 1735552814, '__ci_last_regenerate|i:1735552814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3mhjm9rn4b5906u0o86obslia1jtp5de', '192.250.227.14', 1735573392, '__ci_last_regenerate|i:1735573392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3q565enbdr0gln8dam9ujca4a82q78a8', '192.250.227.14', 1735548732, '__ci_last_regenerate|i:1735548732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3qe2cfu0bpcu3h4vohss0nkgod9n1sv0', '192.250.227.14', 1735586832, '__ci_last_regenerate|i:1735586832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3qgag7pif81olu4ik7b43jlhqar3ce3j', '192.250.227.14', 1735584614, '__ci_last_regenerate|i:1735584613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3sh37scvcp7n00u2qr4cvi6a6na8nuln', '192.250.227.14', 1735567272, '__ci_last_regenerate|i:1735567272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3srvkip2skh2fv2d5ip0ocailbrg2e4c', '192.250.227.14', 1735570933, '__ci_last_regenerate|i:1735570932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3t70nr3iiof76baegq6530m363cdttog', '192.250.227.14', 1735581432, '__ci_last_regenerate|i:1735581432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3vsk1ut6j2ule0kd90el69fu3c0ftsla', '192.250.227.14', 1735558813, '__ci_last_regenerate|i:1735558813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40mvi6hud549e051et0vtmur7o91pun1', '192.250.227.14', 1735554912, '__ci_last_regenerate|i:1735554912;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('42dpnht55n40mmcb4vdu5sraruclo5qn', '192.250.227.14', 1735593193, '__ci_last_regenerate|i:1735593193;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('42vvp55f2qragcf7ronvocs25b0gqc3m', '192.250.227.14', 1735588392, '__ci_last_regenerate|i:1735588392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44ve4sbr9v8vjcllt6jngmbnjadd2es7', '192.250.227.14', 1735547233, '__ci_last_regenerate|i:1735547233;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46cd9kisias2673s5ek766uj64e1l8pb', '134.209.178.195', 1735587038, '__ci_last_regenerate|i:1735587037;db_name|N;_prev_url|s:32:\"https://smarterp.smartnetgt.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('47v49ampqq0ue756e2nievn68srb7oi7', '192.250.227.14', 1735555092, '__ci_last_regenerate|i:1735555092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('48f7fmeivji1f5ssuji7jogaj5690i6o', '192.250.227.14', 1735547053, '__ci_last_regenerate|i:1735547053;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('48n96pu6ja8a9dj7ibroi5vdrce5d3c5', '192.250.227.14', 1735543872, '__ci_last_regenerate|i:1735543872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a2r6k4tji59slcevrumv2636m97etgh', '192.250.227.14', 1735546633, '__ci_last_regenerate|i:1735546633;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4b637uk87i9avsaepaoviduhooqaaubi', '192.250.227.14', 1735567572, '__ci_last_regenerate|i:1735567572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d07jbibtbc8uiceltc46ipu8f0i7dt9', '192.250.227.14', 1735575192, '__ci_last_regenerate|i:1735575192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4er6i6dc5bavkq4kjo24mm3pqo2gg1tl', '192.250.227.14', 1735590252, '__ci_last_regenerate|i:1735590252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f4i7a3qh6ocosk6051jejhn748afdj7', '192.250.227.14', 1735550533, '__ci_last_regenerate|i:1735550533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4gsf7d17sitc64e0l1rl6m7rh4epn1g5', '192.250.227.14', 1735588452, '__ci_last_regenerate|i:1735588452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4hk2b02otdqmvapfoacjt1s9ret2o23r', '192.250.227.14', 1735594273, '__ci_last_regenerate|i:1735594273;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4i7uj44kp46kmmer5g3o1nc2adftpcdk', '192.250.227.14', 1735545372, '__ci_last_regenerate|i:1735545372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4iakgpg7grghrv2b48ahgupbkquuab6v', '192.250.227.14', 1735571293, '__ci_last_regenerate|i:1735571292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4itd1gdj1469dmg44gk4s0adkj77gvis', '192.250.227.14', 1735583832, '__ci_last_regenerate|i:1735583832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ja3i3k7n74v58fp7lv8qe2mru08igpg', '192.250.227.14', 1735565773, '__ci_last_regenerate|i:1735565773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ls16gv375g9t7q4j979htte8sfhj9jq', '192.250.227.14', 1735594452, '__ci_last_regenerate|i:1735594452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4nvsvjugeqtr9d4a8esd3jl2kqunh2bo', '192.250.227.14', 1735582332, '__ci_last_regenerate|i:1735582332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4q3n8bo32ou2clhr2spppiudqid15ge4', '192.250.227.14', 1735579273, '__ci_last_regenerate|i:1735579273;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4qfdgqfvcqjjir4nngn4rs58cqci5rv6', '192.250.227.14', 1735544173, '__ci_last_regenerate|i:1735544172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4qj9to405q8hk0knae4ed7ctpk3r2gjc', '192.250.227.14', 1735555752, '__ci_last_regenerate|i:1735555752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4rqvs83c3ni8gs3rdu027cbkqdpd1v5i', '192.250.227.14', 1735551372, '__ci_last_regenerate|i:1735551372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4tjeh78d7pp775rvkkqo5duvbd4fqn5k', '192.250.227.14', 1735549393, '__ci_last_regenerate|i:1735549393;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ud44q6cgt60em6fs93cilcq2usc9n9r', '192.250.227.14', 1735597152, '__ci_last_regenerate|i:1735597152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ueem18q3u2raqvcqva0b2l4l4b1ntt1', '192.250.227.14', 1735573572, '__ci_last_regenerate|i:1735573572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50dmn4q487a362ga4pj7r4jv3hknse5m', '192.250.227.14', 1735553532, '__ci_last_regenerate|i:1735553532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50jknsb6bsduualgqf0q5m072n14cgsf', '192.250.227.14', 1735572792, '__ci_last_regenerate|i:1735572792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50n3188ljor79mpkernjci9nplup6jo3', '192.250.227.14', 1735597332, '__ci_last_regenerate|i:1735597332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51a008q84sr6uej65r3njjsv05vbccgc', '192.250.227.14', 1735553593, '__ci_last_regenerate|i:1735553592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51et26vtjom08pmmi697vr6g9cfuk4o9', '192.250.227.14', 1735560252, '__ci_last_regenerate|i:1735560252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('52q0taigpafc3qamlvn2k3otae6rsh2m', '192.250.227.14', 1735543633, '__ci_last_regenerate|i:1735543632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55g199vqvt3p58edor1fqa7fnulfl7q9', '192.250.227.14', 1735581372, '__ci_last_regenerate|i:1735581372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57q03rbtlvmbss21n0nlsodq1o0ofuul', '192.250.227.14', 1735561573, '__ci_last_regenerate|i:1735561572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('582l4v5l6v7a25qb9c77r8u40dpmp6dq', '192.250.227.14', 1735587252, '__ci_last_regenerate|i:1735587252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('582n1ne7kug9pqfr2qpmh8hb77qs56j9', '192.250.227.14', 1735568652, '__ci_last_regenerate|i:1735568652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('587vii7e380tbl4jk4g575gue3th6e6d', '192.250.227.14', 1735591514, '__ci_last_regenerate|i:1735591514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('58uojbm9hh82iee5lcbmeogjq7apm5kj', '192.250.227.14', 1735572373, '__ci_last_regenerate|i:1735572372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c0in3ogrld3qm9ei4so59vq4eq648e1', '192.250.227.14', 1735564573, '__ci_last_regenerate|i:1735564573;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5dfl01nv4qovn1pp7e37g04js4a7ftru', '192.250.227.14', 1735543094, '__ci_last_regenerate|i:1735543093;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e334lubuj82ke34qc147509urinlcec', '192.250.227.14', 1735556352, '__ci_last_regenerate|i:1735556352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ed827q94rb6p8cb2ok8ukk2khqhapqj', '192.250.227.14', 1735581492, '__ci_last_regenerate|i:1735581492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ehjhhmn79ossptjpqmf9vgnteca4uq8', '192.250.227.14', 1735565113, '__ci_last_regenerate|i:1735565113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5fbdclo9im0lh2ci2tmtf8r1utoosng7', '192.250.227.14', 1735560972, '__ci_last_regenerate|i:1735560972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5fdo8pa6pkoi4a6p3u1imgdljpr56a7b', '192.250.227.14', 1735590492, '__ci_last_regenerate|i:1735590492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5fdu9c8c5mfqddjsahb97m1hrn6n5bo7', '192.250.227.14', 1735569433, '__ci_last_regenerate|i:1735569433;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5g6ekpao53e23o5sglakmldi5svefkui', '134.209.178.195', 1735587038, '__ci_last_regenerate|i:1735587038;db_name|N;_prev_url|s:32:\"https://smarterp.smartnetgt.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5h2ttb1n9m0l9akv06h7tikphs4spksi', '192.250.227.14', 1735563313, '__ci_last_regenerate|i:1735563313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5jbatv47iq2r1i30b2vi378f9l84lco0', '192.250.227.14', 1735569733, '__ci_last_regenerate|i:1735569733;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5jnremu168jqosfnkn79h0f88i8s7i6g', '192.250.227.14', 1735562413, '__ci_last_regenerate|i:1735562413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5kh9s33tma6mgockap7s5uj7pno34u2k', '192.250.227.14', 1735584492, '__ci_last_regenerate|i:1735584492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5mkkue1t09rfl1h9q139beqh7of1nras', '192.250.227.14', 1735560793, '__ci_last_regenerate|i:1735560792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5mv54sgv8ct4cgbjqv6g0m9vjkavrrt5', '192.250.227.14', 1735579815, '__ci_last_regenerate|i:1735579814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5nouimnm121qq4dn5amrjbbjq4dpfurh', '192.250.227.14', 1735595172, '__ci_last_regenerate|i:1735595172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5o2gi0nmu16tdrc0bdurqja9lvroa5a0', '192.250.227.14', 1735547352, '__ci_last_regenerate|i:1735547352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5pel2m5ub4e1biepsgn77b365sai3n4l', '192.250.227.14', 1735558573, '__ci_last_regenerate|i:1735558572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5ra17j37h263tbqsve148lg1jussnlt7', '192.250.227.14', 1735577532, '__ci_last_regenerate|i:1735577532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5rf0alvp2f1li0o9p5g2mnmaln15mdp2', '192.250.227.14', 1735578252, '__ci_last_regenerate|i:1735578252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5s61g6gor8utml68upm660820let50iq', '192.250.227.14', 1735548432, '__ci_last_regenerate|i:1735548432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5tqcghupa2p1dmcrdmna3en7epso5kq6', '192.250.227.14', 1735565893, '__ci_last_regenerate|i:1735565893;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5upp3rbjqb7ves2vqp53d3d17t3n5s0h', '192.250.227.14', 1735543814, '__ci_last_regenerate|i:1735543813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('60gvnfdpua8oe65h228p604bf5j2aa5k', '192.250.227.14', 1735548192, '__ci_last_regenerate|i:1735548192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('61tvjfvvpf3emfntpbvgqugh8e5umbt6', '192.250.227.14', 1735558752, '__ci_last_regenerate|i:1735558752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('61u1ltkb4f7o79q2qs22slctcdolg7r5', '192.250.227.14', 1735569554, '__ci_last_regenerate|i:1735569553;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62km9nripfsqp8e6pois4ls8bed4dle2', '192.250.227.14', 1735595052, '__ci_last_regenerate|i:1735595052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66fsp828cjl3sf0iism99o7vmlo1lb3d', '192.250.227.14', 1735547172, '__ci_last_regenerate|i:1735547172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6754oatl7rc9kj38n6ga63cpkpvajelr', '192.250.227.14', 1735551072, '__ci_last_regenerate|i:1735551072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67itgmesb3d4rekfbniq7mfiplofj3ij', '192.250.227.14', 1735579753, '__ci_last_regenerate|i:1735579752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67knvcdumk9dne6m55e568k49po324eg', '181.174.105.63', 1735598933, '__ci_last_regenerate|i:1735598933;db_name|N;_prev_url|s:41:\"https://smarterp.smartnetgt.com/site.html\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6d5mbbh1cd9bg7v96502rf748retjr6m', '192.250.227.14', 1735560072, '__ci_last_regenerate|i:1735560072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6edtvmgies49r5mou5pduutqumsg65jg', '192.250.227.14', 1735578852, '__ci_last_regenerate|i:1735578852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6goj7l201vompiip531mt9it6fp8re6p', '192.250.227.14', 1735547113, '__ci_last_regenerate|i:1735547113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6goua847ua4omaarc6fa29261i11lgp7', '192.250.227.14', 1735578492, '__ci_last_regenerate|i:1735578492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6h7fjqn3t2k1qu2b64epp79o9e6o1t8i', '192.250.227.14', 1735550592, '__ci_last_regenerate|i:1735550592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6lbf2lmb139vdudcqt86bgjb8jahed6a', '192.250.227.14', 1735565232, '__ci_last_regenerate|i:1735565232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6olf5ejtn4vug0btpdldmvd257o7ntei', '192.250.227.14', 1735582933, '__ci_last_regenerate|i:1735582933;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6pn7ree3u53j8lv28m5jr0km72k0lad8', '192.250.227.14', 1735581852, '__ci_last_regenerate|i:1735581852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6srojdvhsvlimhen40e3bvgcbed7rdqp', '192.250.227.14', 1735591151, '__ci_last_regenerate|i:1735591151;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6u0v6sjrul3a6bonbisnt1psf44s5f9i', '192.250.227.14', 1735578132, '__ci_last_regenerate|i:1735578132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6unnpupmuirvrh5mufqr75bmbv1bpg01', '192.250.227.14', 1735575792, '__ci_last_regenerate|i:1735575792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6v1quas3bsgm5b682u46h17lt7vi7sbu', '192.250.227.14', 1735588932, '__ci_last_regenerate|i:1735588932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6v2j9ei4e4tlefp9tk82u4e5aprjat2d', '192.250.227.14', 1735560373, '__ci_last_regenerate|i:1735560373;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6vchtarphmjl2jcnhfkrv5tks86fqs3e', '192.250.227.14', 1735571892, '__ci_last_regenerate|i:1735571892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70eqtm59s9rq6mrtfbtmmsqv9q0qdpul', '192.250.227.14', 1735556532, '__ci_last_regenerate|i:1735556532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('71echjvr8b9fffn6ca3k2ao74ao35023', '192.250.227.14', 1735588692, '__ci_last_regenerate|i:1735588692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72mmrajvt0317b9r0r54psq9rsuf65hh', '192.250.227.14', 1735590852, '__ci_last_regenerate|i:1735590852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72rb6gp8mk2jc37ddoivn0u44tn60qfs', '192.250.227.14', 1735594933, '__ci_last_regenerate|i:1735594932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('73h9akrlqhq95nljv5m5mk5dfb26uq4j', '192.250.227.14', 1735544832, '__ci_last_regenerate|i:1735544832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('746rq0p86eojklhup1dv2cpgr0i023qu', '192.250.227.14', 1735551914, '__ci_last_regenerate|i:1735551914;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76ob0tvcpm88an02758gg0gm3pukmhnb', '192.250.227.14', 1735551851, '__ci_last_regenerate|i:1735551851;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('772h40m5t5u93l2tlrl13uftvegbub44', '192.250.227.14', 1735575493, '__ci_last_regenerate|i:1735575493;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('774f5kbm1sk7399jqe208f605hv43qsg', '192.250.227.14', 1735586713, '__ci_last_regenerate|i:1735586713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7962gjkgh86s09ckntfhatbpgql8ijkq', '192.250.227.14', 1735572313, '__ci_last_regenerate|i:1735572312;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ae1h49ckbm0dj082gupk1ud6j72toat', '192.250.227.14', 1735576992, '__ci_last_regenerate|i:1735576992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7bqg4gigcsn9caabsu1caib5uqt9kknp', '192.250.227.14', 1735582032, '__ci_last_regenerate|i:1735582032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7eb17cvbbbt7s7sottauq05j9c63uq5v', '192.250.227.14', 1735561393, '__ci_last_regenerate|i:1735561392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ekfcl05ijsjpmdjg2pt0t4hsonh5gj2', '192.250.227.14', 1735574172, '__ci_last_regenerate|i:1735574172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f7hmuockledsj3citf2e0r4t5gvkpiq', '192.250.227.14', 1735548913, '__ci_last_regenerate|i:1735548912;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ft6elghvm2c116shiaqmf9aho8mk2l6', '192.250.227.14', 1735570633, '__ci_last_regenerate|i:1735570632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7i42kpa3o1obgam690oa8914mdbbtc6j', '192.250.227.14', 1735595473, '__ci_last_regenerate|i:1735595473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7igh7ri96l9c49t9cnngbm7hbtd3ovkj', '192.250.227.14', 1735597632, '__ci_last_regenerate|i:1735597632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7iik4cv0i8o93mb9bofbmk10otj7kjon', '192.250.227.14', 1735544892, '__ci_last_regenerate|i:1735544892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7ikuspt0cmd7jmvf4gthitacnmduaoih', '192.250.227.14', 1735588633, '__ci_last_regenerate|i:1735588633;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7jcsdbi1bkajpd6dbgnf1u01vq7b967i', '192.250.227.14', 1735543392, '__ci_last_regenerate|i:1735543392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7kub2tap8aa95odldpu5g5ecv1vph0ab', '192.250.227.14', 1735586653, '__ci_last_regenerate|i:1735586652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7mof1q20o2feop0eo8qc2aef69fmuel9', '192.250.227.14', 1735544352, '__ci_last_regenerate|i:1735544352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7mtoq99cfn1idrplp1kiibe2r21kfuce', '192.250.227.14', 1735584792, '__ci_last_regenerate|i:1735584792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7njj60u0ar91ev7p3a8v5auetpfit8no', '192.250.227.14', 1735568232, '__ci_last_regenerate|i:1735568232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7psnr852jglipub0730qhrqs1j3v6brq', '192.250.227.14', 1735549033, '__ci_last_regenerate|i:1735549032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7qnk23v5tm4qbu2snolq0mjao52he2tk', '192.250.227.14', 1735585814, '__ci_last_regenerate|i:1735585814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7r2jid1jls1c5ga145jgq7m83j2mtnfe', '192.250.227.14', 1735588871, '__ci_last_regenerate|i:1735588871;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7rcfpf5lh788dno5ccm49671blvkcv8a', '192.250.227.14', 1735587313, '__ci_last_regenerate|i:1735587313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7sgp4qvu9qas3uli59h5mhih7v51m21b', '192.250.227.14', 1735566252, '__ci_last_regenerate|i:1735566252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7sk7ib7oo0rqm7gq68mjr0m0lk59ibgn', '192.250.227.14', 1735596015, '__ci_last_regenerate|i:1735596014;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82pk2s5pekv79qcmrkc251f07j0satl1', '192.250.227.14', 1735596132, '__ci_last_regenerate|i:1735596132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('857g1p7jite4tcr4vi4m5vdub7hal09d', '192.250.227.14', 1735542252, '__ci_last_regenerate|i:1735542252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86b94q45fdv8v56jud0o4k9betis06tt', '192.250.227.14', 1735552332, '__ci_last_regenerate|i:1735552332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89gc2dh652vjp2cao5j2vs5mnv3t1r64', '192.250.227.14', 1735587553, '__ci_last_regenerate|i:1735587553;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89jfj63su2ccd0aoe85jlppf536m1l7p', '192.250.227.14', 1735550233, '__ci_last_regenerate|i:1735550233;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d7728n9hqsjacn7ue7gmgn4voncere0', '192.250.227.14', 1735576152, '__ci_last_regenerate|i:1735576152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d8k4eli493ehhhjciji6b6k8u4vndvo', '192.250.227.14', 1735591933, '__ci_last_regenerate|i:1735591933;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ec8c62dh84nv3rkq4jgeuctb8iasei6', '192.250.227.14', 1735556773, '__ci_last_regenerate|i:1735556772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8fci6a9v25fgdktuuh7gbbqsm6aqp0la', '192.250.227.14', 1735557492, '__ci_last_regenerate|i:1735557492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8gd8ov67ff04fagp6aicfosnt6m0loq8', '192.250.227.14', 1735567152, '__ci_last_regenerate|i:1735567152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8gd9kso3sdescli9cguf268loej3jkma', '192.250.227.14', 1735576572, '__ci_last_regenerate|i:1735576572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8gieeqjbrq1qansu69hfd167qlcf5q9f', '192.250.227.14', 1735588992, '__ci_last_regenerate|i:1735588991;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8j6m7duk74j1a1d80n53oqo5io1oekn0', '192.250.227.14', 1735568952, '__ci_last_regenerate|i:1735568952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8j8mf98ov25e9lfvj2vg2piatke4ae2v', '192.250.227.14', 1735552572, '__ci_last_regenerate|i:1735552572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8k7q5vj8ev264abtvn5e18q3pqcgl0n5', '192.250.227.14', 1735559713, '__ci_last_regenerate|i:1735559713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8kcovs5qbhn8ek3srjoe0n5tce8balhb', '192.250.227.14', 1735556052, '__ci_last_regenerate|i:1735556052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8kf6lrdr81dim9tm40kr0r0fce6rvlcc', '192.250.227.14', 1735568592, '__ci_last_regenerate|i:1735568592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8kmpcflbi147jlknlttve481g1nif7dl', '192.250.227.14', 1735563973, '__ci_last_regenerate|i:1735563972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ktu0snb94vfj1uau784nqiptftgvb27', '192.250.227.14', 1735561333, '__ci_last_regenerate|i:1735561333;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8n3plle3hinfk65f2psanvc0ephn342t', '192.250.227.14', 1735583414, '__ci_last_regenerate|i:1735583414;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8o29ltsit246e98l5b4a3fb7p8d68gsd', '192.250.227.14', 1735564692, '__ci_last_regenerate|i:1735564692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8o9gi7tp2ta3e9bknc5or6tfepn6llrq', '192.250.227.14', 1735571472, '__ci_last_regenerate|i:1735571472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8orckbeait3gvgjob69n5rq63k1ovt9k', '192.250.227.14', 1735580952, '__ci_last_regenerate|i:1735580952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8rs9tphr72ipgpfsele48jk423jqqbgd', '192.250.227.14', 1735567992, '__ci_last_regenerate|i:1735567992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8s8fos3ok4bjp7codipde4gur88pgdq1', '192.250.227.14', 1735596732, '__ci_last_regenerate|i:1735596732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ta2bolr8ublpp3c6ktnqjd1l9obsv1l', '192.250.227.14', 1735546514, '__ci_last_regenerate|i:1735546514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8vrpc6747qaolvs5a82hvgmdufnp753b', '192.250.227.14', 1735551314, '__ci_last_regenerate|i:1735551313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('903sofc6bd45tkvkn0ihucpb6lseln5u', '192.250.227.14', 1735596793, '__ci_last_regenerate|i:1735596793;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91l938cb42350o80qogb257tig5etuve', '192.250.227.14', 1735572432, '__ci_last_regenerate|i:1735572432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('931q8a077m3oiptel30h23bi5sodgk93', '192.250.227.14', 1735593852, '__ci_last_regenerate|i:1735593852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9455b0kit0jpmmpg53isbhbmqmbpr9vb', '192.250.227.14', 1735580352, '__ci_last_regenerate|i:1735580352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('957f2e0gu32rordeh3e5cu2kgfggk7sb', '192.250.227.14', 1735545912, '__ci_last_regenerate|i:1735545912;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95kgrj4db23girlhafjbquvvluri4cg9', '192.250.227.14', 1735542852, '__ci_last_regenerate|i:1735542852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('97ju1aefkvuggmqatnv4u20pae9v3i2i', '192.250.227.14', 1735562533, '__ci_last_regenerate|i:1735562533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('99fsn9k7md46t1l1ubvl0t3uict4elpa', '192.250.227.14', 1735558513, '__ci_last_regenerate|i:1735558513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('99nt1ncdg4q8odtor40gr4fqrhnt3j4p', '192.250.227.14', 1735561093, '__ci_last_regenerate|i:1735561093;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9b77l3mq8epdbu2fso4eklt0gkmm02le', '192.250.227.14', 1735557973, '__ci_last_regenerate|i:1735557973;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9b7ee5s0aafjju2pt8lh6p4gebl7v95o', '192.250.227.14', 1735542913, '__ci_last_regenerate|i:1735542913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bcqmulvejqim578cp9nm23ot6u3qnru', '192.250.227.14', 1735562772, '__ci_last_regenerate|i:1735562772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bjia4n2hun2qmrjp12g3okv1vvomene', '192.250.227.14', 1735587853, '__ci_last_regenerate|i:1735587853;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c7a3ilq7r6mrjl534hrb131fvch4g3b', '192.250.227.14', 1735555992, '__ci_last_regenerate|i:1735555991;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9civgl0i657enbks9l6ncegtkd2s5s9d', '192.250.227.14', 1735581912, '__ci_last_regenerate|i:1735581912;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d6pj6vkipiposhdr8j4k134rqg556t2', '192.250.227.14', 1735545732, '__ci_last_regenerate|i:1735545732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9e0s40kj5eoq9ksi2a8r2agjpdtn8m2h', '192.250.227.14', 1735590013, '__ci_last_regenerate|i:1735590013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9g4qkjfgrggeddfspm81fjfah38nqpsj', '192.250.227.14', 1735573092, '__ci_last_regenerate|i:1735573092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9h92hl8bfoblmqi155rjhbtddf264i7g', '192.250.227.14', 1735585272, '__ci_last_regenerate|i:1735585272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9i1fhplfkcpvpocej4i335sn4o4h643q', '192.250.227.14', 1735598051, '__ci_last_regenerate|i:1735598051;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9j9bk21fd8rvct0nj1c50hfjpc1qane2', '192.250.227.14', 1735563133, '__ci_last_regenerate|i:1735563132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9kb7jvj6lg4bndd7528mchj9kaflber5', '192.250.227.14', 1735592233, '__ci_last_regenerate|i:1735592233;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ksuqhkud8p88v550dgm6ti4lm05qj3j', '192.250.227.14', 1735577052, '__ci_last_regenerate|i:1735577052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ku2d2e9fgrp3ou9nbscjguvupi92i2b', '192.250.227.14', 1735597213, '__ci_last_regenerate|i:1735597213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9l83k5d0srnpnsfpn58qp5o9veto4lmh', '192.250.227.14', 1735570032, '__ci_last_regenerate|i:1735570032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9lu0pfr1m5mc2hvou8kvfvfef4ffdeg4', '192.250.227.14', 1735578732, '__ci_last_regenerate|i:1735578732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9np3jrs0m6nq0ttt54b38soqmr0n358s', '192.250.227.14', 1735560614, '__ci_last_regenerate|i:1735560614;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9s1tcthg23is98nfgmk4p0o3vc7i22qi', '192.250.227.14', 1735591992, '__ci_last_regenerate|i:1735591992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9spkhe999mm4tqtsljgun3fm22gpl21e', '192.250.227.14', 1735579632, '__ci_last_regenerate|i:1735579632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9tgqccq22hfrm0142t7ik783ud8mj8j6', '192.250.227.14', 1735583652, '__ci_last_regenerate|i:1735583652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9u3oen4olqvca7r4768nkdtd1r5ipv1e', '192.250.227.14', 1735590372, '__ci_last_regenerate|i:1735590372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9vkd8oiacatv8j5keknjbctib8hinn01', '192.250.227.14', 1735552092, '__ci_last_regenerate|i:1735552092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9vqmcvdsj8sv9bbtdevsi3qpskcl8jsq', '192.250.227.14', 1735553714, '__ci_last_regenerate|i:1735553714;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0lkcok5koasorhe6ugfnhbfiqsjdqqi', '192.250.227.14', 1735558092, '__ci_last_regenerate|i:1735558092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a11bfc4nb5g3rhsnjs1gfjkjcff31v6a', '192.250.227.14', 1735583953, '__ci_last_regenerate|i:1735583952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1b0mnu943i93eck0s9rfr1j0l60pgp2', '192.250.227.14', 1735542432, '__ci_last_regenerate|i:1735542432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a2iao87ufv2bn3bire179jnj7a1dff35', '192.250.227.14', 1735553414, '__ci_last_regenerate|i:1735553413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4c6d8eaeu0uao876r3t4o8am3t1lcbg', '192.250.227.14', 1735562652, '__ci_last_regenerate|i:1735562652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4fp5vcqi1vm7ljk7rnt931i1qub5r2f', '192.250.227.14', 1735566491, '__ci_last_regenerate|i:1735566491;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a8tbb873dqne51s6t33j284596fn8vsv', '192.250.227.14', 1735564392, '__ci_last_regenerate|i:1735564392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a90ungpvrri23tggbrqnv0ctrlbb1emm', '192.250.227.14', 1735550712, '__ci_last_regenerate|i:1735550712;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a96u95pnerl7fpctbc5jnmk6mtso7jhm', '192.250.227.14', 1735554013, '__ci_last_regenerate|i:1735554013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa7vuroq4ciepplg3p0q5oqcnpo2c8eo', '192.250.227.14', 1735584314, '__ci_last_regenerate|i:1735584314;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ab5r83dp1rcj6926fu1sf5in06iun62d', '192.250.227.14', 1735553952, '__ci_last_regenerate|i:1735553952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('abe2s28g7lpac679t6egcskg1qr3j64o', '192.250.227.14', 1735559953, '__ci_last_regenerate|i:1735559953;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('adhf4ig4uk1vtbdjvsa47krumon18u3i', '192.250.227.14', 1735582993, '__ci_last_regenerate|i:1735582993;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afsud0233v78jv727dg822cgqeris1nr', '192.250.227.14', 1735551492, '__ci_last_regenerate|i:1735551492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ag5rkkkabjgv99aqlhr848errg6mo949', '192.250.227.14', 1735548314, '__ci_last_regenerate|i:1735548313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('agudbs37v0jl99uhspf361s9vghms810', '192.250.227.14', 1735560552, '__ci_last_regenerate|i:1735560552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aheiktrnl93ij1b25ili949s41luh4fi', '192.250.227.14', 1735590552, '__ci_last_regenerate|i:1735590552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('alodpojim6nks80s1o1vbvft9927bcam', '192.250.227.14', 1735571113, '__ci_last_regenerate|i:1735571113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('anf6u4o3p4cspajhmfbhd4mcf4hqs80m', '192.250.227.14', 1735581192, '__ci_last_regenerate|i:1735581192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('apbn0vp4ga84sspnhk1nkvtiho9eib1e', '192.250.227.14', 1735586773, '__ci_last_regenerate|i:1735586773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('apoih5j5f82r26not9m979qjg0bjurmj', '192.250.227.14', 1735574952, '__ci_last_regenerate|i:1735574952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('apvanike81jjnnvova7u4kphgso5ptu5', '192.250.227.14', 1735561214, '__ci_last_regenerate|i:1735561214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aq78v98cungikbues21k72an1d6nq68i', '192.250.227.14', 1735593972, '__ci_last_regenerate|i:1735593972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ars9jelpok41d4534blhiq0pd3aqccav', '192.250.227.14', 1735552693, '__ci_last_regenerate|i:1735552693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('as7d788ev9r8i22vbij39sctdqbk4mmc', '192.250.227.14', 1735598292, '__ci_last_regenerate|i:1735598292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('at36cfg7skom7sos8tfhbr216lht2p30', '192.250.227.14', 1735544592, '__ci_last_regenerate|i:1735544592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('attl9g714hoe1bres3q0uedbbsgj4ne6', '192.250.227.14', 1735561453, '__ci_last_regenerate|i:1735561452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0s34fc5h3ev1q3t5tcndrq89egjbh39', '192.250.227.14', 1735555453, '__ci_last_regenerate|i:1735555453;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3hb0un63u9v5q7kqt328fh6f2gstm27', '192.250.227.14', 1735544052, '__ci_last_regenerate|i:1735544052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6nimdi04ka3iqqffdh0duh2n10aml7b', '192.250.227.14', 1735546393, '__ci_last_regenerate|i:1735546393;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b7vqdgco8j2vi7sgvt87qe7cmku2no9v', '192.250.227.14', 1735597274, '__ci_last_regenerate|i:1735597274;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b87vfonppcdb4aacbgcn1ia628b7r3as', '192.250.227.14', 1735598114, '__ci_last_regenerate|i:1735598114;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bacpq2g3r11c6l7c9o105ksucu40ah83', '192.250.227.14', 1735563672, '__ci_last_regenerate|i:1735563672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('baq78v1l6n5pngjhjr134cpgiomm388j', '192.250.227.14', 1735560313, '__ci_last_regenerate|i:1735560313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbm9p05fbr2m5c2gllk4b8h8efkea7av', '192.250.227.14', 1735569313, '__ci_last_regenerate|i:1735569313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf26h3jen7jgibh7aldu1r5aab0lj7av', '192.250.227.14', 1735567392, '__ci_last_regenerate|i:1735567392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bfit5ref65pa84l9mbcfj63eug3ahvq1', '192.250.227.14', 1735547414, '__ci_last_regenerate|i:1735547414;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bgh4adcsnh5nma5rqbpp2brba2ckpqsr', '192.250.227.14', 1735571593, '__ci_last_regenerate|i:1735571593;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bhjsf0p4skoc3oaccoj0m1o8106uian1', '192.250.227.14', 1735558872, '__ci_last_regenerate|i:1735558872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bhpc2ib4hutalom1prvv94arbm21so16', '192.250.227.14', 1735591452, '__ci_last_regenerate|i:1735591452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bhv8n33ev0mcjpg6iojv4506bikc3bcf', '192.250.227.14', 1735586952, '__ci_last_regenerate|i:1735586952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('biejtsoteu59n43atusgaqi71bedcepf', '192.250.227.14', 1735588153, '__ci_last_regenerate|i:1735588153;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bjd3cb5mj28lb3d0qdpfqibbtn81ujc5', '192.250.227.14', 1735575013, '__ci_last_regenerate|i:1735575013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bjq97e41ldcorjrp85fil6vbnshpc59p', '192.250.227.14', 1735555392, '__ci_last_regenerate|i:1735555392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bkdo6dqoln89anjeei1a19al9hv4h53s', '192.250.227.14', 1735572673, '__ci_last_regenerate|i:1735572673;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bktmi9j5823jn4seafc1jg2r7c74ltca', '192.250.227.14', 1735579092, '__ci_last_regenerate|i:1735579092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bloh7j8fvug94mf1pptktchnh3phigjt', '192.250.227.14', 1735570514, '__ci_last_regenerate|i:1735570514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bphbacvm586cgseul4sgn17tonpfu8uc', '192.250.227.14', 1735569672, '__ci_last_regenerate|i:1735569672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bqa9pkq668lcndftp35bulkk1hqk141u', '192.250.227.14', 1735582093, '__ci_last_regenerate|i:1735582093;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('br8fhle1u108j20n5mvqjvb6nh4l5k0m', '192.250.227.14', 1735585152, '__ci_last_regenerate|i:1735585152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('brn079dchompoffjlsr89fthjvlld8rp', '192.250.227.14', 1735577172, '__ci_last_regenerate|i:1735577172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bt1gu7fia3jbmv8o0e6pdfu8seup9tho', '192.250.227.14', 1735589713, '__ci_last_regenerate|i:1735589713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('btobbn1v9heqsl9bsb4jo266rviakuiv', '192.250.227.14', 1735561933, '__ci_last_regenerate|i:1735561932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bvvto33lfu652m3kde58qujcbpkjc0gv', '192.250.227.14', 1735565952, '__ci_last_regenerate|i:1735565952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c1l96hf9hafi7jcb6ie19dnm1accf070', '192.250.227.14', 1735556893, '__ci_last_regenerate|i:1735556893;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c1o6b0d9mvqg84d6jabien3d9focj7ci', '192.250.227.14', 1735543932, '__ci_last_regenerate|i:1735543932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c1pcmu4qtm1pq6i4toeoeg8vopk3llo7', '192.250.227.14', 1735550172, '__ci_last_regenerate|i:1735550172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c28sugjrsl16tkp32pv868b49j5t68vo', '192.250.227.14', 1735564214, '__ci_last_regenerate|i:1735564214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c6glmakaic1gnq1mibj41332dpr6gms8', '192.250.227.14', 1735587132, '__ci_last_regenerate|i:1735587132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c73usj7ek18tm77169krcut079humu27', '192.250.227.14', 1735547713, '__ci_last_regenerate|i:1735547713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca01ib72g3krsmego0c68qmv508l2dbb', '192.250.227.14', 1735572013, '__ci_last_regenerate|i:1735572013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca28mn3ulve2qbol3hcckaoj89hqnl24', '192.250.227.14', 1735549153, '__ci_last_regenerate|i:1735549153;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cai6cckfv69e5fp2bsha8rs737cgp986', '192.250.227.14', 1735583773, '__ci_last_regenerate|i:1735583773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cbfqa1l65ff9okhrhu7uoq1a7uf1c3lf', '192.250.227.14', 1735569916, '__ci_last_regenerate|i:1735569916;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cc1vfc1ve85pppts4umfahcsiturur0i', '192.250.227.14', 1735557913, '__ci_last_regenerate|i:1735557913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cfts2jacf0st469hcnlthvt8k1fm22df', '192.250.227.14', 1735549452, '__ci_last_regenerate|i:1735549452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cg0m05s213shuanlnl0dcde5vgqlkv9r', '192.250.227.14', 1735597572, '__ci_last_regenerate|i:1735597572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ciaus55m9lugq9445qtn7fi2gps0doi3', '192.250.227.14', 1735598772, '__ci_last_regenerate|i:1735598772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cic4gvme8r72cg2uk6l33jlt9jei91t2', '192.250.227.14', 1735576513, '__ci_last_regenerate|i:1735576513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('clrv9fgqv2l0ejo9bkftakkgip37nu5v', '192.250.227.14', 1735545553, '__ci_last_regenerate|i:1735545553;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cngado7rhmspu46s1vm5k7me5tr5j300', '192.250.227.14', 1735568532, '__ci_last_regenerate|i:1735568532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cqri58guhmfnt30sak8ndpe6hn9ukioh', '192.250.227.14', 1735590913, '__ci_last_regenerate|i:1735590913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cskh7nou26h6vismdegajn65nratokbg', '192.250.227.14', 1735562592, '__ci_last_regenerate|i:1735562591;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('csq9uupt72kb7uthtuu6p3bllo9ggr45', '192.250.227.14', 1735583052, '__ci_last_regenerate|i:1735583052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ct1pm1vm0lemghdjl487pm4di8r2d0hl', '192.250.227.14', 1735550472, '__ci_last_regenerate|i:1735550472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ct4s06t9ibf1cf4f3h1l3kamukv29pd5', '192.250.227.14', 1735556472, '__ci_last_regenerate|i:1735556472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cubk12g57inec2jt54dnb7gm07v5cg3r', '192.250.227.14', 1735569613, '__ci_last_regenerate|i:1735569613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cum9l6mb80885vi64kh96aegqk8frtnr', '192.250.227.14', 1735542552, '__ci_last_regenerate|i:1735542552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cvo7f8hm7rrjk6qhoaqjkh9u6hu8pud1', '192.250.227.14', 1735588032, '__ci_last_regenerate|i:1735588032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0ggtdkglcc7f4u0q8vcu7grlug995qf', '192.250.227.14', 1735545313, '__ci_last_regenerate|i:1735545313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0n4b0976e7ungcejeskc0r3avmkqij5', '192.250.227.14', 1735579572, '__ci_last_regenerate|i:1735579572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d34tmiso45pdlt7o8hfl00vu38bb8p5a', '192.250.227.14', 1735560191, '__ci_last_regenerate|i:1735560191;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d44i85dta70ra9fnlqp6vtmldetgehmi', '192.250.227.14', 1735568414, '__ci_last_regenerate|i:1735568413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4vjgfbmmigpr9k6aof85g6kik3id2lu', '192.250.227.14', 1735551252, '__ci_last_regenerate|i:1735551252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5rqdioh0khusfgb26kee9ndql9qi6kn', '192.250.227.14', 1735586352, '__ci_last_regenerate|i:1735586352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d76n441nqgp2pqte8ecve3na79mausgm', '192.250.227.14', 1735596493, '__ci_last_regenerate|i:1735596492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9imuriqpvq1b2vn8dmf8f0avmvvu3ss', '192.250.227.14', 1735559232, '__ci_last_regenerate|i:1735559232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9jb7tu9qffn29644unboru06194qnj3', '192.250.227.14', 1735584072, '__ci_last_regenerate|i:1735584072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dar2hp00nt56jk41n3sg7qo4k5olhrsi', '192.250.227.14', 1735548973, '__ci_last_regenerate|i:1735548972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dctddta509gf9oj6mtkrd88tg8lnha1g', '192.250.227.14', 1735552753, '__ci_last_regenerate|i:1735552752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfln7lr9k6hs13shis1j6udukkhhaclt', '192.250.227.14', 1735542972, '__ci_last_regenerate|i:1735542972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfuc4ejs6soregh74pjc3oha3obrpr1h', '192.250.227.14', 1735563432, '__ci_last_regenerate|i:1735563432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dgv7635g61039m8knjt4eo6pdd1d2uhd', '192.250.227.14', 1735548133, '__ci_last_regenerate|i:1735548133;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dh2nceh2c13g2f6jpa3n6p13rk90k641', '192.250.227.14', 1735592472, '__ci_last_regenerate|i:1735592472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dh7cjkvf5trbauhjlb1u9vfhrk41pt86', '192.250.227.14', 1735577593, '__ci_last_regenerate|i:1735577592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dh82cm51ufm8scb6daoof74gvp1f739v', '192.250.227.14', 1735565593, '__ci_last_regenerate|i:1735565592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('didstr3n9k63cau0t803snqcalj2l3pf', '192.250.227.14', 1735568292, '__ci_last_regenerate|i:1735568292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dik5mbahv6nv6qljsr9jl63v56jkjidr', '192.250.227.14', 1735583532, '__ci_last_regenerate|i:1735583532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('djmj92e0b15g5urrtg5qf2fvaqjsd4eg', '192.250.227.14', 1735587492, '__ci_last_regenerate|i:1735587492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dnt000kjjaqs8anbpa59g9pc970qek5n', '192.250.227.14', 1735585392, '__ci_last_regenerate|i:1735585392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dui77adi51qs5beue3rqg60q6ekfdp51', '192.250.227.14', 1735558332, '__ci_last_regenerate|i:1735558332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dvotuk4i5ovk2ba6p0ikeu2ubuu3rjp8', '192.250.227.14', 1735567215, '__ci_last_regenerate|i:1735567215;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e03tipvlqfm8abu9ejnjkn0l5v3uimq7', '192.250.227.14', 1735564093, '__ci_last_regenerate|i:1735564093;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e1ivqqi2u2padtt84smad76enr96i8ur', '192.250.227.14', 1735579393, '__ci_last_regenerate|i:1735579393;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e6g5qm8h1d3msrdvadkoo8tc28ochu68', '192.250.227.14', 1735589173, '__ci_last_regenerate|i:1735589172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e6vcqj2ufevjp6d40c555ic29ej4spn2', '192.250.227.14', 1735593432, '__ci_last_regenerate|i:1735593432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7bulq1n5h576j2odqggrq0eisbmump2', '192.250.227.14', 1735594692, '__ci_last_regenerate|i:1735594692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e803oeg72kuftdsdvleuvb68bocvi7pm', '192.250.227.14', 1735595593, '__ci_last_regenerate|i:1735595592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea2n5fiotvh5eg9qh8etle4skqd6s6e3', '192.250.227.14', 1735561153, '__ci_last_regenerate|i:1735561153;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eath6o0kca6q1a508b9nr6v40li8qbe5', '192.250.227.14', 1735593252, '__ci_last_regenerate|i:1735593252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb7il4p8caaga7dqpaqt8emd4qp63pb4', '192.250.227.14', 1735577352, '__ci_last_regenerate|i:1735577352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec1a9a75v2jeta4q5idr56utmvono37o', '192.250.227.14', 1735557673, '__ci_last_regenerate|i:1735557673;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef81545k3hhjgmr53q56i59dqqakpslq', '192.250.227.14', 1735579873, '__ci_last_regenerate|i:1735579873;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef8nd2mlodvsf0ls2ssl5qkcfjv9g89s', '192.250.227.14', 1735568713, '__ci_last_regenerate|i:1735568713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('efijkfcthqh8fo4dkghj3d986e4a13br', '192.250.227.14', 1735560492, '__ci_last_regenerate|i:1735560492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ego383g1rtlnobo4vc444jb3adu5l2qh', '192.250.227.14', 1735551613, '__ci_last_regenerate|i:1735551613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ei7vh2cn7s4ic02hu2jss8enupttubhm', '192.250.227.14', 1735596432, '__ci_last_regenerate|i:1735596432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('elpirv8a3ni58n29cia75a80kcbt2rm7', '192.250.227.14', 1735569192, '__ci_last_regenerate|i:1735569192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('enfi0veu53j90pltva8t149q5946i6e7', '192.250.227.14', 1735580172, '__ci_last_regenerate|i:1735580172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ephsa82r1su6lm4qdkpt0fd48rvkbktv', '192.250.227.14', 1735590974, '__ci_last_regenerate|i:1735590974;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqkql2kn37nrh9g71bii2ar45ou6p7nm', '192.250.227.14', 1735564453, '__ci_last_regenerate|i:1735564453;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('etmeq67242b5f3c1p7crks9boqdp1gtf', '192.250.227.14', 1735590732, '__ci_last_regenerate|i:1735590732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0ci6e38nqd0pusjd2g7h7e25r8cemgg', '192.250.227.14', 1735548613, '__ci_last_regenerate|i:1735548613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0s0a8h681cfgo8jrpq93udilemfvggk', '192.250.227.14', 1735585752, '__ci_last_regenerate|i:1735585752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f16bjo490htieh36c46bru4uq50nkgjm', '192.250.227.14', 1735574653, '__ci_last_regenerate|i:1735574653;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f390kk5tcshhgg9idks0ki31ps5fko7g', '192.250.227.14', 1735567872, '__ci_last_regenerate|i:1735567872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f4o1pa5hnage52sgj93p08fhue872h1u', '192.250.227.14', 1735592772, '__ci_last_regenerate|i:1735592772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f99l28aqgablglql8ddvpio658dt7or7', '192.250.227.14', 1735576451, '__ci_last_regenerate|i:1735576451;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa0k91q5grqjjf4u54o2p1gd7r5p0tq3', '192.250.227.14', 1735543453, '__ci_last_regenerate|i:1735543452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa4cvj598blhh1oikhtdirb14u57ckke', '192.250.227.14', 1735598473, '__ci_last_regenerate|i:1735598473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc1dbkhkrmj0e8g83s0rb05sa288u1vf', '192.250.227.14', 1735543032, '__ci_last_regenerate|i:1735543032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fdiog57433aif66rgeocko8tdcq33egc', '192.250.227.14', 1735563553, '__ci_last_regenerate|i:1735563553;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('febvfu9si81ufufppnqo6493v9hd502a', '192.250.227.14', 1735549513, '__ci_last_regenerate|i:1735549513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('feu3uh1nr143vrfjf7enjvshqd09fp2m', '192.250.227.14', 1735545673, '__ci_last_regenerate|i:1735545672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ffupe4c0r26i51sh65be7fonn82upg1r', '192.250.227.14', 1735576693, '__ci_last_regenerate|i:1735576693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fgn6o3i2c8ersj920v13r613rp7f1n8j', '192.250.227.14', 1735579213, '__ci_last_regenerate|i:1735579213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('flp9op2t75tpmdb4tdsi003mnnchnhsp', '192.250.227.14', 1735586232, '__ci_last_regenerate|i:1735586232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('flrv5qe1iab7s88kjo19f9vi526vjsb3', '192.250.227.14', 1735585513, '__ci_last_regenerate|i:1735585513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('flsqcob77gajm08l3ppf5flk3rco0k2d', '192.250.227.14', 1735585932, '__ci_last_regenerate|i:1735585932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fm1m9iarq72vnladmb8d5tabpvmni1e8', '192.250.227.14', 1735582514, '__ci_last_regenerate|i:1735582514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fnejpv6jjfnh4mvdc92adjvbeag32dkt', '192.250.227.14', 1735587014, '__ci_last_regenerate|i:1735587013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fo58k51kvgbsah6h9vgsu6h2idjhvh1j', '192.250.227.14', 1735580413, '__ci_last_regenerate|i:1735580412;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fos6ff541736ffnusnsm0b008gjjns4h', '192.250.227.14', 1735556114, '__ci_last_regenerate|i:1735556114;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fotp2iags25ev5s1qsk9hc1hdifpp16a', '192.250.227.14', 1735573752, '__ci_last_regenerate|i:1735573752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fq1quk8eeekc3oohc43c4fn3jchjjmcn', '192.250.227.14', 1735597753, '__ci_last_regenerate|i:1735597752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('frf4ijv0etgegvh89upog2984snd5tce', '192.250.227.14', 1735555152, '__ci_last_regenerate|i:1735555152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fs4pb6a0ahhevrbu5gfh1e1mh6jeec8v', '192.250.227.14', 1735557432, '__ci_last_regenerate|i:1735557432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fsmgl0bf2qnhm208pffogi5ld2nn5294', '192.250.227.14', 1735544473, '__ci_last_regenerate|i:1735544473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fui4u9nnlc8bfgrjupttm24pp4dobbb5', '192.250.227.14', 1735588332, '__ci_last_regenerate|i:1735588332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fv0pmae47ar9pvo1udd0h3kkkng9vk6u', '192.250.227.14', 1735596972, '__ci_last_regenerate|i:1735596972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fvca90dddqrb5gvq4i1q3h2o1scroqi9', '192.250.227.14', 1735594632, '__ci_last_regenerate|i:1735594632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fvql81d89h1o46g4qojnuta33tjtbg4t', '192.250.227.14', 1735563493, '__ci_last_regenerate|i:1735563493;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g0b0kvir2721ean4a8gt7sc7avjtk8n9', '192.250.227.14', 1735550292, '__ci_last_regenerate|i:1735550292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g0om6fhsv1ggd6ajb0k5etihgnjmohc7', '192.250.227.14', 1735549573, '__ci_last_regenerate|i:1735549573;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g1i7j7r97ht9tp6cdr3ujs6ujt9pi4ir', '192.250.227.14', 1735570993, '__ci_last_regenerate|i:1735570993;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g3apvr1pv20ct3fi56iot3jkfkocmq8l', '192.250.227.14', 1735554672, '__ci_last_regenerate|i:1735554672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g5llkfus94hvj7ls36r18k9gcggpf26v', '192.250.227.14', 1735566733, '__ci_last_regenerate|i:1735566733;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g66ejfrmrc77ik3fnu1on4p4dco4bpk5', '192.250.227.14', 1735543572, '__ci_last_regenerate|i:1735543572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g7ugteij4mrhttv4q878tpupv1l6j6to', '192.250.227.14', 1735560673, '__ci_last_regenerate|i:1735560673;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g832hs5cb9robug1c71db7inaqafi5e9', '192.250.227.14', 1735548493, '__ci_last_regenerate|i:1735548493;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g8etfsf61m3o1jvee7us41vj335pnmf1', '192.250.227.14', 1735572614, '__ci_last_regenerate|i:1735572613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g96sfsj057s7m5rblaq5q3bvkllvbn37', '192.250.227.14', 1735548252, '__ci_last_regenerate|i:1735548252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gajfmuc7rqi5h43fdu61do6177goigjk', '192.250.227.14', 1735555333, '__ci_last_regenerate|i:1735555333;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gajje7pd1klk8g17vsq7akrbr9b310a5', '192.250.227.14', 1735589652, '__ci_last_regenerate|i:1735589652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gb2io725e7u61jctj24nd4p41nnnae8v', '192.250.227.14', 1735559533, '__ci_last_regenerate|i:1735559533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gbkcrdstcrg7ctedmha3mnee1rdk01th', '192.250.227.14', 1735574774, '__ci_last_regenerate|i:1735574773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gbl9p1ord9d3937ll18q955vvhnfc62p', '192.250.227.14', 1735551434, '__ci_last_regenerate|i:1735551434;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gcbalcnbivplkoa50ph9hs6p5a8ct068', '192.250.227.14', 1735575672, '__ci_last_regenerate|i:1735575672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gcf3k22b2vdl7j2svvdnh0glmhk7347g', '192.250.227.14', 1735542672, '__ci_last_regenerate|i:1735542672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gcr5of300h0rsrqpaeq291u1k8b9legn', '192.250.227.14', 1735567032, '__ci_last_regenerate|i:1735567032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gd8rtv7kr3hiuc2js882gcao2ale6vhd', '192.250.227.14', 1735595953, '__ci_last_regenerate|i:1735595953;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gdvo3vgmle8rlmmobt3sfquouq3p6g14', '192.250.227.14', 1735578552, '__ci_last_regenerate|i:1735578552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ge20o3kln0mo0sotnganurdqecgsgd9n', '192.250.227.14', 1735585215, '__ci_last_regenerate|i:1735585214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gh7qo0g9kb4krfalkq79m58u85i0pgco', '192.250.227.14', 1735583232, '__ci_last_regenerate|i:1735583232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gisqhutp5gp0rerjkh8j30u13si94psj', '192.250.227.14', 1735557192, '__ci_last_regenerate|i:1735557192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjcfpl3io0e6smn3qtrb9aiv45e5n123', '192.250.227.14', 1735579513, '__ci_last_regenerate|i:1735579512;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjookijperthddervkviefvfssi62jbb', '192.250.227.14', 1735557373, '__ci_last_regenerate|i:1735557373;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gjottt919tnknqm1b3vtt1qohbmkvshe', '192.250.227.14', 1735580234, '__ci_last_regenerate|i:1735580233;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gn5a31dg67r1nqqnkn8j45jkpj54fitn', '192.250.227.14', 1735566553, '__ci_last_regenerate|i:1735566553;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('go86fs66sqjd69ba2l8con6mo0sn4kei', '192.250.227.14', 1735543692, '__ci_last_regenerate|i:1735543692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gooenaq8qqlpg0jfcjmdrk7ftcog7lfa', '192.250.227.14', 1735560432, '__ci_last_regenerate|i:1735560432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gorpv3u2th4h40ms7ce5i23584mr5cl8', '192.250.227.14', 1735597932, '__ci_last_regenerate|i:1735597932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gp3v4ebiqq2l26tp5egnnhg0lgrqv8kb', '192.250.227.14', 1735543752, '__ci_last_regenerate|i:1735543752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gpaqstn23hrsr7223kn6dmusc5miumv9', '192.250.227.14', 1735593793, '__ci_last_regenerate|i:1735593792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gpldctrbru7ede46kr6r4o904n9b1efq', '192.250.227.14', 1735576632, '__ci_last_regenerate|i:1735576632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gr3k1r0047007lg7gquvs89ts168ie77', '192.250.227.14', 1735573932, '__ci_last_regenerate|i:1735573932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('grftafen91vd8ursebr1rt0tlfn0n43n', '192.250.227.14', 1735591092, '__ci_last_regenerate|i:1735591092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gvcubgm4ud6lc1avmhtk3qol2cvbktdb', '192.250.227.14', 1735589052, '__ci_last_regenerate|i:1735589052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0o3crh9anqefp9r2jva4dgdrs1j44rk', '192.250.227.14', 1735576392, '__ci_last_regenerate|i:1735576392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0pvu1mfj0e66fovi04gbetb90q6ss8f', '192.250.227.14', 1735544293, '__ci_last_regenerate|i:1735544292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h0uuhca4i3glpl8f1lchjv8g96h9t36q', '192.250.227.14', 1735551972, '__ci_last_regenerate|i:1735551972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h1tdjcg3hhvg5q2kv7va6039sdukf12d', '192.250.227.14', 1735598352, '__ci_last_regenerate|i:1735598352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h1vi2l26mmmprisuudurn3tnlgpbvdil', '192.250.227.14', 1735595113, '__ci_last_regenerate|i:1735595113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h35ckq97m5m0bmna4geirgvkij26evkc', '192.250.227.14', 1735571232, '__ci_last_regenerate|i:1735571232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h3t9qljpn09idm5kn8r4g753aihek7hs', '192.250.227.14', 1735596072, '__ci_last_regenerate|i:1735596072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h4mggarqcvkj4dph98q0jghfsiso3sku', '192.250.227.14', 1735568053, '__ci_last_regenerate|i:1735568052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h6irihsn8g97p88poupgl09s71fljohn', '192.250.227.14', 1735562173, '__ci_last_regenerate|i:1735562172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h7238q1m2foj1i9p2ov2b33lt33ceari', '192.250.227.14', 1735581615, '__ci_last_regenerate|i:1735581615;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h78qounfje1ativh2gr9tgoug2etf18l', '192.250.227.14', 1735575913, '__ci_last_regenerate|i:1735575912;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h8fvh3nli1io9hiqaqc3osnv89k40fkc', '192.250.227.14', 1735552152, '__ci_last_regenerate|i:1735552152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h9d375qe68p68b3aojpg2v50mdc4u1ok', '192.250.227.14', 1735544113, '__ci_last_regenerate|i:1735544113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ha0mjc9vb53a5spfj1un1c04oq4g7ehv', '192.250.227.14', 1735592352, '__ci_last_regenerate|i:1735592352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hap30bjdtpcat464683td1vnb7p11530', '192.250.227.14', 1735573272, '__ci_last_regenerate|i:1735573272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('haq94mao3jvf50td5je4331b07k2to5v', '192.250.227.14', 1735544652, '__ci_last_regenerate|i:1735544652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hcm37plfqlju6ltpl94uprlp8bvm79vu', '192.250.227.14', 1735573632, '__ci_last_regenerate|i:1735573632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hdm1k64q5ucpurs041cjmkif2gkomm9s', '192.250.227.14', 1735550353, '__ci_last_regenerate|i:1735550353;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hdriptvaa7gj1q3ffrq1bsqj6i37jmom', '192.250.227.14', 1735553292, '__ci_last_regenerate|i:1735553292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('heh0iss20det5ck5tvmdm1hc98og9960', '192.250.227.14', 1735557013, '__ci_last_regenerate|i:1735557013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hel05afo30ne9g9h9majql4j3p71as1e', '192.250.227.14', 1735582873, '__ci_last_regenerate|i:1735582873;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hg80opiaoese6l9r5ia3qin9m3pr8j2v', '192.250.227.14', 1735552452, '__ci_last_regenerate|i:1735552452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hhcvjit094soapvgu3udromsmqe63qjn', '192.250.227.14', 1735564633, '__ci_last_regenerate|i:1735564632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hinaud7hn0ovf8tshi5p1hoerh681dh3', '192.250.227.14', 1735592892, '__ci_last_regenerate|i:1735592892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hjgc0g3u83qmdrtme5hb0ngbk1cafnpc', '192.250.227.14', 1735564812, '__ci_last_regenerate|i:1735564812;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hla2nsiig5s2eu0rgecrvo097pgihifp', '192.250.227.14', 1735573514, '__ci_last_regenerate|i:1735573514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hm349ebcfjg8f3bhkdp1esm3gnu0lpet', '192.250.227.14', 1735591873, '__ci_last_regenerate|i:1735591873;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hm8h8aq6jd9ekdj569l7uilsuan3jauc', '192.250.227.14', 1735545852, '__ci_last_regenerate|i:1735545852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq5lu3u5rkhvoksi103mn9mepmqbm5l4', '192.250.227.14', 1735558632, '__ci_last_regenerate|i:1735558632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hqp8br671v1hennu9q3pu5qcm230nv3q', '192.250.227.14', 1735565173, '__ci_last_regenerate|i:1735565173;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hr092hnafd2s0dumqfshet0u476jmc8p', '192.250.227.14', 1735566013, '__ci_last_regenerate|i:1735566013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hs1cas1upohkr1qqkqajpi807gklsbpk', '192.250.227.14', 1735557314, '__ci_last_regenerate|i:1735557314;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hssc7ll234fejrjce3lk4h0d32i3catb', '192.250.227.14', 1735561693, '__ci_last_regenerate|i:1735561692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('huho73nlv4fhu0hkfbir9ge7n62cq43l', '192.250.227.14', 1735549932, '__ci_last_regenerate|i:1735549932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hvqspuop4o5qibruoq2ci51h90iprmsh', '192.250.227.14', 1735581972, '__ci_last_regenerate|i:1735581972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i0p4ol2j0g7cujsf0ofmmu51ov9s7oqo', '192.250.227.14', 1735569014, '__ci_last_regenerate|i:1735569013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i2bbgt4osk973c8oo1do3gckap9p71rv', '192.250.227.14', 1735566672, '__ci_last_regenerate|i:1735566672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i49u0f4jtr7d997doell5n0n1jot99uq', '192.250.227.14', 1735565053, '__ci_last_regenerate|i:1735565053;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i4so7msihcnr5d7jqnfs67lod8evatmu', '192.250.227.14', 1735589293, '__ci_last_regenerate|i:1735589293;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i58ino2159b8sdupubq93crqna0rn7qn', '192.250.227.14', 1735593072, '__ci_last_regenerate|i:1735593072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i5k7n0hijb9j0pnhq07h1g4vg2aocfdn', '192.250.227.14', 1735581312, '__ci_last_regenerate|i:1735581312;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i6hsv6ubks23135c30facauicqak6p0i', '192.250.227.14', 1735589833, '__ci_last_regenerate|i:1735589833;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i6roodpg6bfpp1irdscp8d5e4dc1i9jp', '192.250.227.14', 1735556713, '__ci_last_regenerate|i:1735556713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i70hienuglm8bjdfskc3nqnojrtrhaqh', '192.250.227.14', 1735550772, '__ci_last_regenerate|i:1735550772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i73hn77b4188pcf2mtuf0ukttnbrt7pt', '192.250.227.14', 1735590072, '__ci_last_regenerate|i:1735590072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i954bfv6mj1hg01fru5qlm0mj81mnemq', '192.250.227.14', 1735576873, '__ci_last_regenerate|i:1735576873;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i9dstqbv5c1pfeen443nmmtmargkvcn2', '192.250.227.14', 1735593552, '__ci_last_regenerate|i:1735593552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iajtvjhklqt8p14kevnbc098b9qtuib9', '192.250.227.14', 1735586472, '__ci_last_regenerate|i:1735586472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ib6ksg3i5pgstvht16a4v9ikollbuh32', '192.250.227.14', 1735579032, '__ci_last_regenerate|i:1735579032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ib9ln9fm3k9vhbe5hpdoul6kkm3973n7', '192.250.227.14', 1735557613, '__ci_last_regenerate|i:1735557613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ic105evqftir5bm77lkqp7gpqhovovlf', '192.250.227.14', 1735556233, '__ci_last_regenerate|i:1735556233;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('icmqoipk9rcl4o6i5qss3subp5oo1i6d', '192.250.227.14', 1735585573, '__ci_last_regenerate|i:1735585573;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('icu8aqkhmakhktjbr792j3q9ujr51t83', '192.250.227.14', 1735574352, '__ci_last_regenerate|i:1735574352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('id244dgdnkhti2gbc1l659b47r37f86r', '192.250.227.14', 1735595652, '__ci_last_regenerate|i:1735595652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('id6qi4cpm68pba7ce30f0hn3q3b57tf6', '192.250.227.14', 1735552632, '__ci_last_regenerate|i:1735552632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ifo3gtj045fhd7c0hvtp97eiggvbogdq', '192.250.227.14', 1735569792, '__ci_last_regenerate|i:1735569792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ik586kr2bkcejkqtaj9voht173ivu3me', '192.250.227.14', 1735554614, '__ci_last_regenerate|i:1735554613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ikm3pq0fgphbm2st4l2g8f0p2iu48c1v', '192.250.227.14', 1735571532, '__ci_last_regenerate|i:1735571532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('imdtb1jt6hbv15l5mg13t0la2dmp6kaf', '192.250.227.14', 1735557853, '__ci_last_regenerate|i:1735557852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('in00kvpdqq2hd318oajd4o28vt0tfinm', '192.250.227.14', 1735564872, '__ci_last_regenerate|i:1735564872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('inbr3p7duoqlfn9ha9mr5h8nr289291d', '192.250.227.14', 1735594392, '__ci_last_regenerate|i:1735594392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iop3962g1v8ag67ndcphn1lfdffa8h8t', '192.250.227.14', 1735549692, '__ci_last_regenerate|i:1735549691;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ip3chgug9qs9teca4na396itq80ccobf', '192.250.227.14', 1735590792, '__ci_last_regenerate|i:1735590792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ipjj48ju86df0fua3k1di6oth9ub2pae', '192.250.227.14', 1735598173, '__ci_last_regenerate|i:1735598173;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iqsnbofogr4i2p6qk2vje1fqvk1npks4', '192.250.227.14', 1735597513, '__ci_last_regenerate|i:1735597513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('irgujla20ter27179g3nkn6mrh6l8iin', '192.250.227.14', 1735581013, '__ci_last_regenerate|i:1735581013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('irjqgg16bgqsd6448c5s3qsukk498s0j', '192.250.227.14', 1735596373, '__ci_last_regenerate|i:1735596373;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('itdlo75gndh44l8ngemouoih5lad9l86', '192.250.227.14', 1735577832, '__ci_last_regenerate|i:1735577832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j2c055mgdmlnr6brlc5m3qkcv954kjso', '192.250.227.14', 1735589472, '__ci_last_regenerate|i:1735589472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j2jk5da9ukcvekp470q51el1ncincn9c', '192.250.227.14', 1735545792, '__ci_last_regenerate|i:1735545792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j3ar6djgfjic2j5j7u1tgef9862bn8bu', '192.250.227.14', 1735544773, '__ci_last_regenerate|i:1735544773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jbv54ie201gatclsmn0outeik11s5p7t', '192.250.227.14', 1735588573, '__ci_last_regenerate|i:1735588572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jd80e91jm3uejegkr69nb2v7mg7cu84j', '192.250.227.14', 1735580113, '__ci_last_regenerate|i:1735580113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jfdd2l2oskr7k7soit3791jodl3rs659', '192.250.227.14', 1735542492, '__ci_last_regenerate|i:1735542492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jgjp0beceis10fu6k6qnok6vr14ajucu', '192.250.227.14', 1735583892, '__ci_last_regenerate|i:1735583892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jjhob0goh7692mt3jsm02mi6931t621k', '192.250.227.14', 1735594092, '__ci_last_regenerate|i:1735594092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jke3nq7pu9c896dnitaaflq56dimg9gv', '192.250.227.14', 1735551132, '__ci_last_regenerate|i:1735551132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jl1s9houqn2o3c8583vjpdocopk3hr2d', '192.250.227.14', 1735564032, '__ci_last_regenerate|i:1735564032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jm2pn2kisuu2g7hu5jpk7g5k675unco2', '192.250.227.14', 1735592414, '__ci_last_regenerate|i:1735592414;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jot6tvlhathpf2sgkqgh4um80ovh9psb', '192.250.227.14', 1735574232, '__ci_last_regenerate|i:1735574232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jq7oppnk923ppja7nsugv710jkibmkha', '192.250.227.14', 1735585332, '__ci_last_regenerate|i:1735585332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('js17bq63h0ec8obk4ta8f2umekibr3m0', '192.250.227.14', 1735598832, '__ci_last_regenerate|i:1735598832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k280mtfc715umkmv6vq0utb4qfj0edq2', '192.250.227.14', 1735546813, '__ci_last_regenerate|i:1735546813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k43v1kfsqo5t1qc897l0ku907r4nssri', '192.250.227.14', 1735551013, '__ci_last_regenerate|i:1735551013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k50o23s1jbm235r1490usef8nlakf9qg', '192.250.227.14', 1735548013, '__ci_last_regenerate|i:1735548013;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k6meej66orsdhin6calnbk9t8ipoov72', '192.250.227.14', 1735562893, '__ci_last_regenerate|i:1735562892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k8muchpbbp8q3adekojcl46s4o9ed6c8', '192.250.227.14', 1735556953, '__ci_last_regenerate|i:1735556953;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k8rhcljiv8mrp2aksnajjp7na325jcrp', '192.250.227.14', 1735561273, '__ci_last_regenerate|i:1735561273;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kal1k8r7dlril55oaqu93aehlducdmt1', '192.250.227.14', 1735584132, '__ci_last_regenerate|i:1735584132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kb06d4ehl5let3kob5erv9j4ndsa29ck', '192.250.227.14', 1735554192, '__ci_last_regenerate|i:1735554192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kbb5of5t788s5i561cm94kg9pilohqpm', '192.250.227.14', 1735542732, '__ci_last_regenerate|i:1735542732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kbfsn7j9kjjsru8qrk89m1emeb7q890b', '192.250.227.14', 1735592292, '__ci_last_regenerate|i:1735592292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kc1k4d7vsmk9t2gkoodbhch1fe4os4hr', '192.250.227.14', 1735593314, '__ci_last_regenerate|i:1735593314;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kcfhk5mu0nthkagqdpkkueh8lfpo4vac', '192.250.227.14', 1735574532, '__ci_last_regenerate|i:1735574532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('keukncu9tfqur4bpm3hatoocoh6cid6i', '192.250.227.14', 1735572733, '__ci_last_regenerate|i:1735572733;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kfhg6kkeu76qqpltssq3j2e6d1f9c4gg', '192.250.227.14', 1735572252, '__ci_last_regenerate|i:1735572252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kfq7087r74jvag282ea1spa8rimb9vi8', '192.250.227.14', 1735587072, '__ci_last_regenerate|i:1735587072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kgig9lsrq5mi10tr1o8ojqfvj9i98am4', '192.250.227.14', 1735584432, '__ci_last_regenerate|i:1735584432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ki0njd4jqbreqqmaenoppe7m3olp7bsj', '192.250.227.14', 1735578313, '__ci_last_regenerate|i:1735578313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kjengui2ak11ddd233lbujk079df2oco', '192.250.227.14', 1735598952, '__ci_last_regenerate|i:1735598952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kjng59j30grr0mhvgdi3lpp0tqdho20v', '192.250.227.14', 1735577472, '__ci_last_regenerate|i:1735577472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kjpsqj6uuvk3stb71lfvd660lnv1tgqa', '192.250.227.14', 1735559052, '__ci_last_regenerate|i:1735559052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kjuhk82pfkuh7k9fddbdp3uvtancekj4', '192.250.227.14', 1735599014, '__ci_last_regenerate|i:1735599014;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kkmb622b53jaqjnp46u6jnl4jf5tjvbn', '192.250.227.14', 1735552512, '__ci_last_regenerate|i:1735552512;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('km6q6s477t4ge7hv8hvf7rki40lt21n4', '192.250.227.14', 1735548673, '__ci_last_regenerate|i:1735548673;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kphb22g2g5ij41k97ueg1v52rp2brmj8', '192.250.227.14', 1735577892, '__ci_last_regenerate|i:1735577892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kqlu75sn475mt60dr5osadqcptjev5ta', '192.250.227.14', 1735547772, '__ci_last_regenerate|i:1735547772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ktkfvavcl4uac9h3925ui486o1amr7qj', '192.250.227.14', 1735554972, '__ci_last_regenerate|i:1735554972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l1asuam9ct3pl5gurqv7c88u1tcjnjam', '192.250.227.14', 1735583113, '__ci_last_regenerate|i:1735583113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l3b29igfh84qj27jed9l41i5qsoqonap', '192.250.227.14', 1735595232, '__ci_last_regenerate|i:1735595232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l46fgr707m5d9rggus4fe58aqhgpl3i5', '192.250.227.14', 1735549752, '__ci_last_regenerate|i:1735549752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5cscvsn40pf9q28p7mqmthibbrrvt0f', '192.250.227.14', 1735567753, '__ci_last_regenerate|i:1735567752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5q849ffnjsb16b8f92l15o7lkj8pppq', '192.250.227.14', 1735551552, '__ci_last_regenerate|i:1735551552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l6bh60q450mn2uphnlt5fpqggi8bs6qm', '192.250.227.14', 1735595832, '__ci_last_regenerate|i:1735595832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lcrch84ulf3skh2dkhsnon68v527spov', '192.250.227.14', 1735586413, '__ci_last_regenerate|i:1735586412;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lctma9ekbh1i81i3j2q09ums34hilh2q', '192.250.227.14', 1735586293, '__ci_last_regenerate|i:1735586293;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('leh07slr8gub3lcugfm10ischlmbka33', '192.250.227.14', 1735545072, '__ci_last_regenerate|i:1735545072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lf3a5ls5gfvi1jm7dvbtjmjtveln7pba', '192.250.227.14', 1735569492, '__ci_last_regenerate|i:1735569492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lfafk9n1hd5ft03hi48c82tm8q8icfjd', '192.250.227.14', 1735565293, '__ci_last_regenerate|i:1735565293;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lhslej5or78u4mr45hpvgl3r6q5c8sc1', '192.250.227.14', 1735567512, '__ci_last_regenerate|i:1735567512;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lip56k309p6jicieboals9v5rq15pvad', '192.250.227.14', 1735566973, '__ci_last_regenerate|i:1735566972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lj9jaf6kb77hb8v43gmb2b64e29h7ua5', '192.250.227.14', 1735553894, '__ci_last_regenerate|i:1735553893;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lk5bamll6sapeps8uaik4bqhh80obsle', '192.250.227.14', 1735549092, '__ci_last_regenerate|i:1735549092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ll4nfo1rhbl7k0olc619a9ojivq6ra6t', '192.250.227.14', 1735556833, '__ci_last_regenerate|i:1735556833;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ln3ktk1rjpjvjrdnksug1gk6nhbq7kdr', '192.250.227.14', 1735550053, '__ci_last_regenerate|i:1735550053;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lpkbt78bhod41bc4uhug9to5vni89t9r', '192.250.227.14', 1735549272, '__ci_last_regenerate|i:1735549272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lppqfcaedvina1n2pu2lvqbdt12ecmic', '192.250.227.14', 1735578913, '__ci_last_regenerate|i:1735578913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ls4nguv34b788m83dktkso4dsj8ue1el', '192.250.227.14', 1735587972, '__ci_last_regenerate|i:1735587972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lsao8b5oh3mru1nsg1jumn8hhc9j3k09', '192.250.227.14', 1735592052, '__ci_last_regenerate|i:1735592052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lsinhhelekqk6hdcnrmgl2ahgjujnand', '192.250.227.14', 1735591572, '__ci_last_regenerate|i:1735591572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m1pehktalkpdsdnroiod2era2e2fmb3r', '192.250.227.14', 1735549633, '__ci_last_regenerate|i:1735549633;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m28ratpdsbaikst3doebj595rcskt7ke', '192.250.227.14', 1735570693, '__ci_last_regenerate|i:1735570693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m2h5i3odulcklvo1njj42oet7jor9hbj', '192.250.227.14', 1735566792, '__ci_last_regenerate|i:1735566792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m2itm8e5r6tovgavk3af1h1k7475am5m', '192.250.227.14', 1735581672, '__ci_last_regenerate|i:1735581672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m4r0khs2agln4gio26s22fcam8j2vv4d', '192.250.227.14', 1735574892, '__ci_last_regenerate|i:1735574892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m72oprti2b39ehc2hourkfjpjlibbnp8', '192.250.227.14', 1735586532, '__ci_last_regenerate|i:1735586532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m7k46bot8e64p2ishjll80tijktpgqes', '192.250.227.14', 1735584672, '__ci_last_regenerate|i:1735584672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m92go1ghf1ph1avaads51ukdlprp1alq', '192.250.227.14', 1735596613, '__ci_last_regenerate|i:1735596613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m980vh24ekipq5hd509tmmghjtl6vklq', '192.250.227.14', 1735573992, '__ci_last_regenerate|i:1735573992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('makm0th0fbof54d63ebmm6mdl6tbuf08', '192.250.227.14', 1735564933, '__ci_last_regenerate|i:1735564932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mbc8lcqmoq56jus9suvgokrcil1ueb5h', '192.250.227.14', 1735553172, '__ci_last_regenerate|i:1735553172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mdn1nsptm3ncnf3d09cdbd43f48djr9k', '192.250.227.14', 1735573813, '__ci_last_regenerate|i:1735573813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mf1g01r6uiu2e98b0hcnjsuqajal476b', '192.250.227.14', 1735566432, '__ci_last_regenerate|i:1735566432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mfp8r64ehu898h8jo6a2rcpggjnqvb71', '192.250.227.14', 1735570333, '__ci_last_regenerate|i:1735570332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mfu8em9e7n5k76odl3dkja02fknkemqi', '192.250.227.14', 1735554372, '__ci_last_regenerate|i:1735554372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mgbmpslf9m70m77bafhgf8umem3tfdf4', '192.250.227.14', 1735548792, '__ci_last_regenerate|i:1735548792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mgdkrgouecvfnardrtcj3otvrhfvqjku', '192.250.227.14', 1735554852, '__ci_last_regenerate|i:1735554851;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mj6kdau7gf9f55ru147qqbp1o7k29rnf', '192.250.227.14', 1735563192, '__ci_last_regenerate|i:1735563192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ml8u4ukiqk1ejc0lkutega03un70qpl6', '192.250.227.14', 1735597033, '__ci_last_regenerate|i:1735597032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mmt37i129ifm36dad8089esaehkscsj6', '192.250.227.14', 1735554252, '__ci_last_regenerate|i:1735554252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mppsve8uhbsevd4729ircgfvn6hek8r8', '192.250.227.14', 1735584732, '__ci_last_regenerate|i:1735584732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mq62dh90s428qkr135usci2j5b7ub9lb', '192.250.227.14', 1735558152, '__ci_last_regenerate|i:1735558152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mqt24f9v4c16pmv5cki42qaiolk6ird0', '192.250.227.14', 1735596314, '__ci_last_regenerate|i:1735596313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ms0fppgofqbvkife7a6b79qs0kke9ge6', '192.250.227.14', 1735590672, '__ci_last_regenerate|i:1735590672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('msso06d3ib54v51tkm9612i8ch1p72mi', '192.250.227.14', 1735566853, '__ci_last_regenerate|i:1735566853;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('muckusnrq41viqn01ui0e5rq56au80us', '192.250.227.14', 1735545972, '__ci_last_regenerate|i:1735545972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n0ata71rg9mvjrac3qudvp127646k5em', '192.250.227.14', 1735577772, '__ci_last_regenerate|i:1735577772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n0fhv2539vebfsagjcs8kbn11qgdi1ne', '192.250.227.14', 1735575373, '__ci_last_regenerate|i:1735575372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n2sv8ql572cqs4cmpvlk7hh8cb8la1an', '192.250.227.14', 1735583172, '__ci_last_regenerate|i:1735583172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n5vc1fdvf9f7uc78tmi0m9tdijbe4dug', '192.250.227.14', 1735561633, '__ci_last_regenerate|i:1735561632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n6l04qvsi9sije1870v6pnrlj03kftit', '192.250.227.14', 1735555513, '__ci_last_regenerate|i:1735555513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n72un0iutd3o8a3bsiacdf8ehhm09010', '192.250.227.14', 1735576752, '__ci_last_regenerate|i:1735576751;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n782n9jevv2p6tei64ueag3j6on99j0a', '192.250.227.14', 1735569852, '__ci_last_regenerate|i:1735569852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n85r3b27r975h6h2bh993nrsdjrg0j86', '192.250.227.14', 1735576332, '__ci_last_regenerate|i:1735576332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n8r59tmic736c88nh2hudpjfej2h50fi', '192.250.227.14', 1735595713, '__ci_last_regenerate|i:1735595713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('naj29df7he7rcj2ikcf8bclb1p6mrn8f', '192.250.227.14', 1735592713, '__ci_last_regenerate|i:1735592713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('napgu20tg7k5hrr9c5lp2heki250odf7', '192.250.227.14', 1735592172, '__ci_last_regenerate|i:1735592172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('naubgjlgh1u7g2vm0j7j26n3fq8rr0ln', '192.250.227.14', 1735561872, '__ci_last_regenerate|i:1735561872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nb63vrotho113aqhvlfqh704urtu5k4e', '192.250.227.14', 1735561513, '__ci_last_regenerate|i:1735561513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nb98cl64qn4nmo5lmavoj6vo0q0fdho5', '192.250.227.14', 1735545252, '__ci_last_regenerate|i:1735545252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nbh76a9ekn9dko3j5iga2mbgu8kre859', '192.250.227.14', 1735593132, '__ci_last_regenerate|i:1735593132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ncfvm2dfkpk849mnlpcvo0f5tb3ts7eg', '192.250.227.14', 1735573152, '__ci_last_regenerate|i:1735573152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ncte6kchl3phht7a31j4uoi3pc06qpee', '192.250.227.14', 1735577414, '__ci_last_regenerate|i:1735577414;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nefam7livp3r37s0i5ls84nsr3lps3je', '192.250.227.14', 1735552273, '__ci_last_regenerate|i:1735552273;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('negmtgbpedlchd5hrbbabaf92o8asuci', '192.250.227.14', 1735543152, '__ci_last_regenerate|i:1735543152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nf0iios2ekpfk875t8pjkak0hr4ssag1', '192.250.227.14', 1735568113, '__ci_last_regenerate|i:1735568113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ngoammvf8fk9aqfobvmoka2vva14nu2k', '192.250.227.14', 1735576273, '__ci_last_regenerate|i:1735576272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ni2b3u2jiv49u6rbvsosapbi5ffr7obb', '192.250.227.14', 1735561032, '__ci_last_regenerate|i:1735561032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('niu4bfg66k9gebcf2rqeopuv55koppoh', '192.250.227.14', 1735591213, '__ci_last_regenerate|i:1735591213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nkamjmsc3vjufcqadsl0amfp59527m3e', '192.250.227.14', 1735567693, '__ci_last_regenerate|i:1735567693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nkeqfgmg0io991s0k2tqdjacf7ujg4ne', '192.250.227.14', 1735558213, '__ci_last_regenerate|i:1735558213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nkllorsu5s72ese7val6r9qnevhhgfm2', '192.250.227.14', 1735558033, '__ci_last_regenerate|i:1735558032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nkuplj83opq7ads516661e6dh2lvt5fm', '192.250.227.14', 1735554732, '__ci_last_regenerate|i:1735554732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nm2e98ll93a4hhpv9ac0dig4nd7rfm89', '192.250.227.14', 1735554492, '__ci_last_regenerate|i:1735554492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nra4vae2j58g60afpgk3rm028ioljn6g', '192.250.227.14', 1735573214, '__ci_last_regenerate|i:1735573213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nsipf8h293q4v05qfueriq2dtsau047c', '192.250.227.14', 1735590193, '__ci_last_regenerate|i:1735590192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nui5olaoepeiq1q6g0vgl2c1pfeb976r', '192.250.227.14', 1735567452, '__ci_last_regenerate|i:1735567452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nujp40r3gvg137mii1hmv7jn2vbfmc8v', '192.250.227.14', 1735570274, '__ci_last_regenerate|i:1735570274;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nv3fhsbhhrgarqh0vb116rvlhsmhshvj', '192.250.227.14', 1735558693, '__ci_last_regenerate|i:1735558693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nv5b08uo3m8mb455apcamin3taaqudhq', '192.250.227.14', 1735570573, '__ci_last_regenerate|i:1735570573;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o2bqgj2a4gjhcmj4teoc19f9ee3pbotv', '192.250.227.14', 1735552932, '__ci_last_regenerate|i:1735552932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o2dkd7v32q7sa3qp46asu8pn677a4lkf', '192.250.227.14', 1735580533, '__ci_last_regenerate|i:1735580533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o3t7ints5slu8j9ocfq1hqqedmoh6656', '192.250.227.14', 1735546332, '__ci_last_regenerate|i:1735546332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o4jbv7cgjcjs00qndbugd7br0tfapsk9', '192.250.227.14', 1735562293, '__ci_last_regenerate|i:1735562293;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o62oe45c5iv3lcj15ev2ah2hdap3d2hr', '192.250.227.14', 1735582814, '__ci_last_regenerate|i:1735582813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o6vvuu9kopbtf62fu220p2vir3me9o8g', '192.250.227.14', 1735554313, '__ci_last_regenerate|i:1735554313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o7b8qi4nunajh1gf3id1ajv0minadjft', '192.250.227.14', 1735544713, '__ci_last_regenerate|i:1735544713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o7slq2hfbjds0cuuvn1a222ofv0478vg', '192.250.227.14', 1735550653, '__ci_last_regenerate|i:1735550653;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o8052bah33us0auah3sibm37vmp0puci', '192.250.227.14', 1735553052, '__ci_last_regenerate|i:1735553052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o9aokd98edf6s9up9vef1on21cukp6u0', '192.250.227.14', 1735577652, '__ci_last_regenerate|i:1735577652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obeko57tsrf7gin5s3kicueqosolurr7', '192.250.227.14', 1735598714, '__ci_last_regenerate|i:1735598714;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('od9m9vjl39dv58g5f2v6ksm2appeh2tj', '192.250.227.14', 1735562472, '__ci_last_regenerate|i:1735562472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oegmnp1879jl4fu4tgf7ap89v4simppj', '192.250.227.14', 1735584913, '__ci_last_regenerate|i:1735584912;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ogioo391vicffnspnktjia9fe99kedhb', '192.250.227.14', 1735556592, '__ci_last_regenerate|i:1735556592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oigi2a4u7e4oerqutnnquuipj2h2mtqp', '192.250.227.14', 1735585632, '__ci_last_regenerate|i:1735585632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oilvtejdp4vupv58ebda7dq7jlji3ift', '192.250.227.14', 1735585452, '__ci_last_regenerate|i:1735585452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oiqmlu113kl8j3cj2blkaeohaq1h8v58', '192.250.227.14', 1735559352, '__ci_last_regenerate|i:1735559352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oiubb7tcish19p4vf8d5bfe5pciicske', '192.250.227.14', 1735564514, '__ci_last_regenerate|i:1735564514;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oju6nnn1b1gtbhn540fvvqcn99astan8', '192.250.227.14', 1735548372, '__ci_last_regenerate|i:1735548372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oljmqdofoldnjrq4rcvreco7et8o521r', '192.250.227.14', 1735585032, '__ci_last_regenerate|i:1735585032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oqtlqa0fukq00f7gid7kmensbrqm6gmr', '192.250.227.14', 1735556415, '__ci_last_regenerate|i:1735556415;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('orbdt790o9s98jq3psd79elj0dh24qrb', '192.250.227.14', 1735547833, '__ci_last_regenerate|i:1735547833;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('orc6g4omeo7hstrjbhq93ig0il3ftohr', '192.250.227.14', 1735595772, '__ci_last_regenerate|i:1735595772;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('otbk455i6iajf716e9fiuqefrp2dtqsu', '192.250.227.14', 1735594814, '__ci_last_regenerate|i:1735594814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('otr98smaas3ref8j2tn5qhbr43ir8ppj', '192.250.227.14', 1735595293, '__ci_last_regenerate|i:1735595292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('otv60kjq7mog0fgl9lj791dnen70n9ug', '192.250.227.14', 1735563732, '__ci_last_regenerate|i:1735563732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ov7hetj3snlf52valvaed6uns12e55id', '192.250.227.14', 1735594574, '__ci_last_regenerate|i:1735594574;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ovmjjnvltopj6n30ud3fq96o5l83aris', '192.250.227.14', 1735596192, '__ci_last_regenerate|i:1735596192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p1h35f3h0b32cjth7jromnhkohhos73n', '192.250.227.14', 1735565832, '__ci_last_regenerate|i:1735565832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p2jpd5p7f4t55lhqjqqb46dtgqdeium4', '192.250.227.14', 1735580713, '__ci_last_regenerate|i:1735580713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p31909gfaif2e48c2bh8811t9tuqju00', '192.250.227.14', 1735547473, '__ci_last_regenerate|i:1735547473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p35v7u942h5cmqtda9r9buu18862rusc', '192.250.227.14', 1735550114, '__ci_last_regenerate|i:1735550114;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p4bdmhk131h6899t5l1vv6ev39cnls8a', '192.250.227.14', 1735572853, '__ci_last_regenerate|i:1735572853;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p4gv1v48pgn16o01jbvqon5oqavp0n1k', '192.250.227.14', 1735562714, '__ci_last_regenerate|i:1735562713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p572erg2l6cademi9sukf000qcm8gefd', '192.250.227.14', 1735549214, '__ci_last_regenerate|i:1735549214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p6g9m1l8t2ufpgoh25ti65b84c90rdnl', '192.250.227.14', 1735555872, '__ci_last_regenerate|i:1735555872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p76ot6nfdqurtulhl3qmp8ibchfj4jft', '192.250.227.14', 1735592653, '__ci_last_regenerate|i:1735592653;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p7sbr28onau2pakemhd1luqlkn9ngn02', '192.250.227.14', 1735584193, '__ci_last_regenerate|i:1735584193;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p88eq0kve8qr3u0bndemnrcfsmbtglv4', '192.250.227.14', 1735563913, '__ci_last_regenerate|i:1735563913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p8htjgi22meu8fujg4qal7qkcql5cdbc', '192.250.227.14', 1735578432, '__ci_last_regenerate|i:1735578432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9heua3t65k3e7v1cgurtndto82dc63l', '192.250.227.14', 1735550952, '__ci_last_regenerate|i:1735550952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9joarp66ghieuu77qmnjpgqm8r7g2im', '192.250.227.14', 1735553234, '__ci_last_regenerate|i:1735553234;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pbr113kknrn26mq66t4jaqe7r8a35hlk', '192.250.227.14', 1735568473, '__ci_last_regenerate|i:1735568473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pd57mlnnck6scvbqe0e1ut50eli8bqd9', '192.250.227.14', 1735572073, '__ci_last_regenerate|i:1735572073;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pe4klab2fji5q98ip0luv8lkdkoniarh', '192.250.227.14', 1735558933, '__ci_last_regenerate|i:1735558932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pf0pg5br9noo4rr0iejv1bmvc4dujtlk', '192.250.227.14', 1735589533, '__ci_last_regenerate|i:1735589532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pfao3t3dm2boa430ni6d0k8qgojeqds1', '192.250.227.14', 1735588815, '__ci_last_regenerate|i:1735588815;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pgpfpn51fn3f7rgufarrj68uoqha923g', '192.250.227.14', 1735591273, '__ci_last_regenerate|i:1735591273;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('phjk37h5o0rqp3ou8hfvs6j3aa0ke5hc', '192.250.227.14', 1735543212, '__ci_last_regenerate|i:1735543212;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pi3moapc6b3bum1l7q4ui1sdoi9uqrfs', '192.250.227.14', 1735578373, '__ci_last_regenerate|i:1735578372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pj89mrjptdks24g0gbc0d5dg0ou4vds3', '192.250.227.14', 1735575253, '__ci_last_regenerate|i:1735575253;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pjr2lsslek4k1sh0ib6sfv2k4imcg3tr', '192.250.227.14', 1735579332, '__ci_last_regenerate|i:1735579332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pk36j534lds9tvv3uvl2pld25b4gcjhd', '192.250.227.14', 1735574833, '__ci_last_regenerate|i:1735574833;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pkqvb5fp8stpu02gjgs9gjivanchgv26', '192.250.227.14', 1735570092, '__ci_last_regenerate|i:1735570092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pmvaor9kdmsluar5f0fq5cb0m740nar6', '192.250.227.14', 1735591332, '__ci_last_regenerate|i:1735591332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pn5nq2kblpabd6slsv702fsham1jeckh', '192.250.227.14', 1735584252, '__ci_last_regenerate|i:1735584252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pnisjbib42helrs6o4au0voaau6o6ns4', '192.250.227.14', 1735547293, '__ci_last_regenerate|i:1735547292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('po43rhm2oc54g70s3n59i1u4cqrbh9hm', '192.250.227.14', 1735554072, '__ci_last_regenerate|i:1735554072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('poffs3bc5adn5l1s2mafps37j1k9bhf5', '192.250.227.14', 1735544232, '__ci_last_regenerate|i:1735544232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pppb9iqcn1r6t4amhmqip7ogin531ln0', '192.250.227.14', 1735584372, '__ci_last_regenerate|i:1735584372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pptijpuvntv7pfd2g66rftjdhoo3ei6p', '192.250.227.14', 1735569372, '__ci_last_regenerate|i:1735569372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('puhcqigml4ot7n5m2cr5llfkclndb72e', '192.250.227.14', 1735596253, '__ci_last_regenerate|i:1735596253;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pvfvl7re9oe2hj4cti04mhmqf7e43her', '192.250.227.14', 1735542613, '__ci_last_regenerate|i:1735542613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q0gu1etaaluevomv9tq7o4t4tt3j08b9', '192.250.227.14', 1735592113, '__ci_last_regenerate|i:1735592113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q0l78k6m4li3cm2e39cnfs8rmr6aor3s', '192.250.227.14', 1735575314, '__ci_last_regenerate|i:1735575314;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q0rt6kskij5h92ir60n16o0rcdbgt5ac', '192.250.227.14', 1735594214, '__ci_last_regenerate|i:1735594214;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q0u8hqfo7vun06b7garncefr8pvkb87a', '192.250.227.14', 1735563372, '__ci_last_regenerate|i:1735563372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q1b334it5gjbimvnlkrhdjhqe3fg4235', '192.250.227.14', 1735593493, '__ci_last_regenerate|i:1735593492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q386rahkd0thnc67bqa6emu4mcuj7bse', '192.250.227.14', 1735592833, '__ci_last_regenerate|i:1735592833;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q5lkuvqj9rvhesis04o72e52p8ntfl13', '192.250.227.14', 1735555573, '__ci_last_regenerate|i:1735555573;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q6mq86c665eepc7od1p1ospi3ncvppa0', '192.250.227.14', 1735561993, '__ci_last_regenerate|i:1735561992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q72jtvouoipintmah822kac5i36f399b', '192.250.227.14', 1735546873, '__ci_last_regenerate|i:1735546872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q8jd1t94bi5s3edk22fuu9uoq0ihpall', '192.250.227.14', 1735590133, '__ci_last_regenerate|i:1735590133;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q9d3ev195c4sdo0u7r9od5k9imogvmeu', '192.250.227.14', 1735573872, '__ci_last_regenerate|i:1735573872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qb5m065877uk7pnvs85g7v42uaqoqnbb', '192.250.227.14', 1735567333, '__ci_last_regenerate|i:1735567333;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qb5map2gj0846tn08s3kq0atn62b6v5o', '192.250.227.14', 1735563852, '__ci_last_regenerate|i:1735563852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qba3u9n16ltneq3tfeo3dres6aeislgl', '192.250.227.14', 1735582752, '__ci_last_regenerate|i:1735582752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qdq8ku8msk9kgs304gcbmcnshp0h4p47', '192.250.227.14', 1735568173, '__ci_last_regenerate|i:1735568173;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qdvpa9902khvnvvvkti8cnqleiccsg2j', '192.250.227.14', 1735576932, '__ci_last_regenerate|i:1735576932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qe29i2cg64ldmsf9tm1gekr12gk4makl', '192.250.227.14', 1735598232, '__ci_last_regenerate|i:1735598231;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qe73h2dnaian41v51kmcbm0h089qiltm', '192.250.227.14', 1735562052, '__ci_last_regenerate|i:1735562052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qgp5bffbpgjo6ovlk1v5kma4cumu27cr', '192.250.227.14', 1735566314, '__ci_last_regenerate|i:1735566314;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qht3hba65asmp9ergq4604vulr27nl1k', '192.250.227.14', 1735558272, '__ci_last_regenerate|i:1735558272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qi3hq382haup6jd0q8tkvqqq1n0bhfim', '192.250.227.14', 1735565472, '__ci_last_regenerate|i:1735565472;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qi4gd7omftpcp6fh40niiqa88mf4jijr', '192.250.227.14', 1735577232, '__ci_last_regenerate|i:1735577232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qimdpqdv1mrdtih2rldfv131tvgf441v', '192.250.227.14', 1735582572, '__ci_last_regenerate|i:1735582572;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qiq86c66242el58cm3plf6krsibkt7bl', '192.250.227.14', 1735591033, '__ci_last_regenerate|i:1735591033;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qk9ang8n6d5mhdp2oivavfg6ahr3n6a9', '192.250.227.14', 1735555272, '__ci_last_regenerate|i:1735555272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qlda8ouo4r8thmgremuvggjbhf5fk7ka', '192.250.227.14', 1735550832, '__ci_last_regenerate|i:1735550832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qmqav29ul61ujln6030ftcrkj8eglajd', '192.250.227.14', 1735546933, '__ci_last_regenerate|i:1735546933;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qn06nl5l1bh347lahdj2vk05mtketq7b', '192.250.227.14', 1735552992, '__ci_last_regenerate|i:1735552992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qnuvt45vip0fcvk9rtp4ikk6bjano162', '192.250.227.14', 1735563073, '__ci_last_regenerate|i:1735563073;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpd2lljuv4tlgigdsep0bkn90jl6b155', '192.250.227.14', 1735575852, '__ci_last_regenerate|i:1735575852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpdpts28r3lvp3e55uo6bgjerp767n50', '192.250.227.14', 1735559114, '__ci_last_regenerate|i:1735559114;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpdrfhm85bs244urud87kem8lvnt0llv', '192.250.227.14', 1735588752, '__ci_last_regenerate|i:1735588752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpmst3gem3p9ieug8bg3dlvl2mb7nski', '192.250.227.14', 1735582152, '__ci_last_regenerate|i:1735582152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qqtkr6he3rpkkqqrdmagq6kmto6otalp', '192.250.227.14', 1735544533, '__ci_last_regenerate|i:1735544533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qr427vuvqjklnoj38k4ag7m4m7b485hd', '192.250.227.14', 1735572492, '__ci_last_regenerate|i:1735572492;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qsibrvckfi57kp4hua3ge53dlfi7ohrh', '192.250.227.14', 1735589352, '__ci_last_regenerate|i:1735589352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qtmktovinr7dksde2318i0msken7virq', '192.250.227.14', 1735598653, '__ci_last_regenerate|i:1735598653;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qupdmprasj4vmkcr1bven6o3sr7eodq7', '192.250.227.14', 1735567814, '__ci_last_regenerate|i:1735567814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qur43kejuu80fun4ki65ddsts71dsad5', '192.250.227.14', 1735545133, '__ci_last_regenerate|i:1735545133;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r08vkk1loojirrb8qug97lonh2955n8r', '192.250.227.14', 1735571413, '__ci_last_regenerate|i:1735571413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r1qdf5ojmtl46e25ndibd2rcbc1t06dh', '192.250.227.14', 1735559293, '__ci_last_regenerate|i:1735559292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r276kq05t793tbgdqfcertd1nal3cj8c', '192.250.227.14', 1735582213, '__ci_last_regenerate|i:1735582213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r27u8dik2074sfac0dtian4ldbfi13i9', '192.250.227.14', 1735546992, '__ci_last_regenerate|i:1735546992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r2hoslcvjq97l2vfskes1gka2ugatpfe', '192.250.227.14', 1735597092, '__ci_last_regenerate|i:1735597092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r37u0kq6cfmbrqba2212esju0b2fif0e', '192.250.227.14', 1735581792, '__ci_last_regenerate|i:1735581792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r4gb2jevaolhnhmthdnmnkmg3iihkbfb', '192.250.227.14', 1735582453, '__ci_last_regenerate|i:1735582452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r6csq9gphbqpjnms1770sism55c8qkct', '192.250.227.14', 1735549332, '__ci_last_regenerate|i:1735549332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r6jgce5d1qo40rfu4u8k5p2jd7qs77lj', '192.250.227.14', 1735543992, '__ci_last_regenerate|i:1735543992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r7or9lmn9vsg9i17q7ukku2q10v1p2oo', '192.250.227.14', 1735597392, '__ci_last_regenerate|i:1735597392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rajc9sjg0fav5oo615kvrkdfllnmvrvl', '192.250.227.14', 1735547592, '__ci_last_regenerate|i:1735547592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rblol3k2l5rsqsalj02s52c366d85tt8', '192.250.227.14', 1735546693, '__ci_last_regenerate|i:1735546693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rc38rd67l63c3s3k7ao725t803f2rfhj', '192.250.227.14', 1735548853, '__ci_last_regenerate|i:1735548853;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rd7dbl12sd7tlc3067e6btj2vh5s1tb8', '192.250.227.14', 1735553832, '__ci_last_regenerate|i:1735553832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rdoke4alfp463rjmohcj84t0cqvpb44i', '192.250.227.14', 1735555814, '__ci_last_regenerate|i:1735555814;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rek0f4u6rbbpq9108d088qdf2rt34ftg', '192.250.227.14', 1735551192, '__ci_last_regenerate|i:1735551192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rh34a202l9s4uc2e58ltpdt0f2akeqdr', '192.250.227.14', 1735588213, '__ci_last_regenerate|i:1735588213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rhdoue1q0bqulcit6ai3quu0asod8uch', '192.250.227.14', 1735593913, '__ci_last_regenerate|i:1735593913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rhuaddd7btrg3v0d69bokblcg22m24tn', '192.250.227.14', 1735594992, '__ci_last_regenerate|i:1735594992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('riijfm2lj9ajij67reo32817dfutqoft', '192.250.227.14', 1735575732, '__ci_last_regenerate|i:1735575732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ritg5a9janvbfj2ccurinbta2sdusio1', '192.250.227.14', 1735575072, '__ci_last_regenerate|i:1735575072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rk70062e6mrcedhevqron751qmsbofrv', '192.250.227.14', 1735559473, '__ci_last_regenerate|i:1735559473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rk8bim9c6eb6914d46rk4cfit0e5nr4s', '192.250.227.14', 1735546152, '__ci_last_regenerate|i:1735546152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rkgpb2nehnntkhehgko8lh2i3ema25th', '192.250.227.14', 1735554133, '__ci_last_regenerate|i:1735554133;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rkj5ig71hc3j3oqahs5b0iducobsfpu8', '192.250.227.14', 1735547953, '__ci_last_regenerate|i:1735547952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rmt0uhdplt54n1janh3hr0fm9u9dn895', '192.250.227.14', 1735542373, '__ci_last_regenerate|i:1735542372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rn1l2rv4nedp7nttbbm7vm3qoh9su14k', '192.250.227.14', 1735591692, '__ci_last_regenerate|i:1735591692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('roq1ci1ve8tdnim1sllko1r07fnrhrju', '192.250.227.14', 1735564333, '__ci_last_regenerate|i:1735564332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rqefp2f4f7gulodgudkat4icbmhupvps', '192.250.227.14', 1735552392, '__ci_last_regenerate|i:1735552392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rqvsu8ng8cb2hrlti11c0cs5ftlhdd0e', '192.250.227.14', 1735548072, '__ci_last_regenerate|i:1735548072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rr7334tos6cfv7ireaig04pc3aak01rs', '192.250.227.14', 1735566372, '__ci_last_regenerate|i:1735566372;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rrrcvi3hafvqbglocpuklpup7o07mp37', '192.250.227.14', 1735571052, '__ci_last_regenerate|i:1735571052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rs33rg64hs1faceehab08ccb0sg0u6e1', '192.250.227.14', 1735590613, '__ci_last_regenerate|i:1735590613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rtatbm80hljrs891i5f8jd5cunb50oad', '192.250.227.14', 1735562113, '__ci_last_regenerate|i:1735562113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rvbd4vv4qtm9m943jbj1mrqacb11tvks', '192.250.227.14', 1735598533, '__ci_last_regenerate|i:1735598533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s0o8qt4ma6e4muec07s104saqp0c9c12', '192.250.227.14', 1735586892, '__ci_last_regenerate|i:1735586892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s472vf9pcfmvp948nle17uiqrquqrlsc', '192.250.227.14', 1735587192, '__ci_last_regenerate|i:1735587192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s59jefs4r29uimfoslnlii6bk93fuvtk', '192.250.227.14', 1735595413, '__ci_last_regenerate|i:1735595413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s5khi671jods1fbrspvfvftsd4b04q6m', '192.250.227.14', 1735581732, '__ci_last_regenerate|i:1735581732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s6396gvjvd0om9mcnm87bsbg3m5f4fdv', '192.250.227.14', 1735596552, '__ci_last_regenerate|i:1735596552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s6cdr7fq1o6l56mqmeh51p5qe7ls529a', '192.250.227.14', 1735580471, '__ci_last_regenerate|i:1735580471;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s6mc3214rp22m2k2q9p82jt2m8pp685v', '192.250.227.14', 1735587733, '__ci_last_regenerate|i:1735587733;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s8i59nv5fpjk9ppj7kjtm272hu1oc9c8', '192.250.227.14', 1735591392, '__ci_last_regenerate|i:1735591392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s8jmsnqpqjipu1h15gnahg7e87vkarra', '192.250.227.14', 1735559893, '__ci_last_regenerate|i:1735559893;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s9ktjj7tgt393appllba8g491meltfm9', '192.250.227.14', 1735589953, '__ci_last_regenerate|i:1735589953;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s9utc39vk01elcon0bmrc3j72kmj8c5q', '192.250.227.14', 1735585692, '__ci_last_regenerate|i:1735585692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sao6ibuddptqd6fspckfoveigdf9c036', '192.250.227.14', 1735580832, '__ci_last_regenerate|i:1735580832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('saujo803j3n30bup2c8n0aqmmt4igv30', '192.250.227.14', 1735568352, '__ci_last_regenerate|i:1735568352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sddfknq80q0dcl2crssmmcbqcdcr6uvj', '192.250.227.14', 1735578613, '__ci_last_regenerate|i:1735578613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sdm90ljjnupaprum08gl9ap22ep21ura', '192.250.227.14', 1735564752, '__ci_last_regenerate|i:1735564752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sdtbj24cjj10e0si7k61ldbe0t7295ok', '192.250.227.14', 1735561752, '__ci_last_regenerate|i:1735561752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sefp0ai8la0ocg7d8tka44dnsqkerub2', '192.250.227.14', 1735576213, '__ci_last_regenerate|i:1735576213;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sgjulbhopnoioq40nr1k0c4p16mjpkbs', '192.250.227.14', 1735547652, '__ci_last_regenerate|i:1735547652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sgk20ge8khaanj5tpkvnf36pt3hs5tdg', '192.250.227.14', 1735580652, '__ci_last_regenerate|i:1735580652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sibi4n3hdtu4ktmf3covpp17ngsk8ov9', '192.250.227.14', 1735588513, '__ci_last_regenerate|i:1735588513;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('siocbbgfmca82t13p21lgf75brsdmv7n', '192.250.227.14', 1735576813, '__ci_last_regenerate|i:1735576813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('siqv36ofhah6mdl8uhsmmqcb5vqkfnm8', '192.250.227.14', 1735598892, '__ci_last_regenerate|i:1735598892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sirpdb6i4uu0uul4i73s7o56paa7o26c', '192.250.227.14', 1735575972, '__ci_last_regenerate|i:1735575972;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sjidcoru6ttp9ihmkqbdvvedr8qig53a', '192.250.227.14', 1735560853, '__ci_last_regenerate|i:1735560853;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sk7kpfcik8ljt85u0ai00r4s3bv4j61d', '192.250.227.14', 1735595532, '__ci_last_regenerate|i:1735595532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('skogg0b9c4hh271ulb1kp6onoqvs7kb0', '192.250.227.14', 1735578072, '__ci_last_regenerate|i:1735578072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sln2g148gq1jqcura6rk7ttncn5ej63c', '192.250.227.14', 1735580892, '__ci_last_regenerate|i:1735580892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('snnttrsc7aatcmtlf0r1tr29mq71mq9c', '192.250.227.14', 1735559653, '__ci_last_regenerate|i:1735559653;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sohgnhglid9trblhg5qc0dqo6pvrbbga', '192.250.227.14', 1735579152, '__ci_last_regenerate|i:1735579152;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sqli04gda7c0hqlckarjusvtn2ar8k1q', '192.250.227.14', 1735559592, '__ci_last_regenerate|i:1735559592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('srl4vafghuqfk8utludf6l7e8qip3e48', '192.250.227.14', 1735574293, '__ci_last_regenerate|i:1735574293;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ss8urb4cbku3mf7m5oq20qogadn8eb8i', '192.250.227.14', 1735589232, '__ci_last_regenerate|i:1735589232;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('st052pfc513rk956ak659l5chil6qn6m', '192.250.227.14', 1735579992, '__ci_last_regenerate|i:1735579992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('std141n659fedlk2t54rrl2nbsc7bvvl', '192.250.227.14', 1735576032, '__ci_last_regenerate|i:1735576032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('stn2790sg2i0nlpmjt15687e059d0j6d', '192.250.227.14', 1735546273, '__ci_last_regenerate|i:1735546273;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('suugq2eact6u8kacc0rm8ar50sks8ms5', '192.250.227.14', 1735554792, '__ci_last_regenerate|i:1735554792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sv1joctpkebd6ng9b5r63adud71aiclp', '192.250.227.14', 1735587913, '__ci_last_regenerate|i:1735587913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('svrm0n1agbosf8228vehmt1k2t9jgi23', '192.250.227.14', 1735592953, '__ci_last_regenerate|i:1735592952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('svt3b456blre5jdb4li8lh9j5ca8ggfm', '192.250.227.14', 1735597873, '__ci_last_regenerate|i:1735597873;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t16qfel4ollm9vj9lgb0csko5fhungpm', '192.250.227.14', 1735597992, '__ci_last_regenerate|i:1735597992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t3rrv44a9k5j2781bhl2oho1pcehsh6o', '192.250.227.14', 1735586592, '__ci_last_regenerate|i:1735586592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t5dr4jssgs0qlfbudg7t643esmuoc3sj', '192.250.227.14', 1735572913, '__ci_last_regenerate|i:1735572913;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t5kmgm19rvulsju2d3vj7n4khrvgmmdq', '192.250.227.14', 1735571173, '__ci_last_regenerate|i:1735571173;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t6nlmlj9spi4lcejlebal0n94hq88vb3', '192.250.227.14', 1735591632, '__ci_last_regenerate|i:1735591632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t9daj77ug262fmmnp8rrkgf68pi0fn06', '192.250.227.14', 1735593373, '__ci_last_regenerate|i:1735593373;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t9kv1uukjcgm0s26uosdg3u9fqq4p0mq', '192.250.227.14', 1735565652, '__ci_last_regenerate|i:1735565652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tb20d7atqrs8jol2ic8rdgd72uifmvl8', '192.250.227.14', 1735570816, '__ci_last_regenerate|i:1735570816;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tbo7hprfssd95m2jggicddgg7933s5sd', '192.250.227.14', 1735553352, '__ci_last_regenerate|i:1735553352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tdaig0hhs1peujucufojvdt9o609keh8', '192.250.227.14', 1735586172, '__ci_last_regenerate|i:1735586172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ten8dnr7osrpsr8doh9jvgc1daub5da3', '192.250.227.14', 1735551732, '__ci_last_regenerate|i:1735551732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tfoadmu0sltt2n0nndhm13l8f32b257i', '192.250.227.14', 1735564272, '__ci_last_regenerate|i:1735564272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tfsik2nnqrcslitlk42ar4qsg78k9fiq', '192.250.227.14', 1735560017, '__ci_last_regenerate|i:1735560016;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tggfknrkkrc02reqi4md1qpdgg0ec8kf', '192.250.227.14', 1735545433, '__ci_last_regenerate|i:1735545432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('therfi6c2lqg70s53ab483h7qa90e3ou', '192.250.227.14', 1735568833, '__ci_last_regenerate|i:1735568832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tj5ga6jfgrklbaf40emngjleq8t1dou8', '192.250.227.14', 1735592532, '__ci_last_regenerate|i:1735592532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tkkufnp7dnb9o4mj5j97vapq9daoi1js', '192.250.227.14', 1735559773, '__ci_last_regenerate|i:1735559773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tkpkpd5ftmbefj4vht3u73sk6ss07d81', '192.250.227.14', 1735554432, '__ci_last_regenerate|i:1735554432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tkt2r4q4nelooch0gq3235nrmj0gqou1', '192.250.227.14', 1735582693, '__ci_last_regenerate|i:1735582693;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tkuvh3d5vm44a75o54381g79mn9loai2', '192.250.227.14', 1735577293, '__ci_last_regenerate|i:1735577293;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tl7kq749fdatk6pp04lket4dcdjqqsee', '192.250.227.14', 1735555932, '__ci_last_regenerate|i:1735555932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tmg2nafihpd8khoedbmug223qbdri95s', '192.250.227.14', 1735546092, '__ci_last_regenerate|i:1735546092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tove0hk08bvkf1786ho8g1spocf2a71l', '192.250.227.14', 1735567632, '__ci_last_regenerate|i:1735567632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ttk5bj6ligl1op2lie3c8mfk6a294j4u', '192.250.227.14', 1735562952, '__ci_last_regenerate|i:1735562952;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ttnm6ln5os5rj081lgesn6t88f41c5bl', '192.250.227.14', 1735572552, '__ci_last_regenerate|i:1735572552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u08tffa1h277e516fis4rk57uk7nstlp', '192.250.227.14', 1735566132, '__ci_last_regenerate|i:1735566132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u1cgdj5bg4jq2bi4lbt9kd73ifc75fvv', '192.250.227.14', 1735594032, '__ci_last_regenerate|i:1735594032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u3sfpt5201480ektp8kc5042qtgfmppm', '192.250.227.14', 1735570753, '__ci_last_regenerate|i:1735570752;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u3vrc6vobl8qio6pmaaoqsornbfb2uid', '192.250.227.14', 1735543272, '__ci_last_regenerate|i:1735543272;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4762cr8b5jsra3qulmcmdsc8sjuj78j', '192.250.227.14', 1735548552, '__ci_last_regenerate|i:1735548552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u4lgpnmpba71lfjopb1i4npa0npsutgj', '192.250.227.14', 1735575552, '__ci_last_regenerate|i:1735575552;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u5pq4gqhkadropc1hv7q686bdqm3bsvm', '192.250.227.14', 1735587672, '__ci_last_regenerate|i:1735587672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u728f04lf25nv7t7fbj35qu3jhoho76r', '192.250.227.14', 1735562832, '__ci_last_regenerate|i:1735562832;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ua6m1bogrehin9l1aqraptrnjga89elo', '192.250.227.14', 1735578192, '__ci_last_regenerate|i:1735578192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uain4s3l73lgm62hfhcitm44ffbh03lv', '192.250.227.14', 1735586114, '__ci_last_regenerate|i:1735586114;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uaol1slk6qrka6p4pssactjaj4gpmok9', '192.250.227.14', 1735579692, '__ci_last_regenerate|i:1735579692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uath8b0mhqkscshnbqht1iindap60b7k', '192.250.227.14', 1735593613, '__ci_last_regenerate|i:1735593613;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uchfg8c9ok3v876vp0hub1d1i3cs3rbc', '192.250.227.14', 1735578792, '__ci_last_regenerate|i:1735578792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ud0ocaqevlt5gv9u2t1p2bnvu44kn9su', '192.250.227.14', 1735567092, '__ci_last_regenerate|i:1735567092;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ufg5j1a1lffc7gb82kh3t21jbfu4d86n', '192.250.227.14', 1735550892, '__ci_last_regenerate|i:1735550892;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uh0av67bgec8uohs74rq28g1t53t6tpn', '192.250.227.14', 1735555692, '__ci_last_regenerate|i:1735555692;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uhq0q74boct43jtvq8vfm8a1gpgg258e', '192.250.227.14', 1735595352, '__ci_last_regenerate|i:1735595352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ui1od9auua3e1k01ltf3a1ktubm11f55', '192.250.227.14', 1735543332, '__ci_last_regenerate|i:1735543332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ujb3abovdefdiqt0j4g3d2p5sfav80g0', '192.250.227.14', 1735580292, '__ci_last_regenerate|i:1735580292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ujiot4vea22adnsvra0ql2i32t1a28qi', '192.250.227.14', 1735565713, '__ci_last_regenerate|i:1735565713;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ulku4d1qe1mfeeffsb584nh8q3nonqhj', '192.250.227.14', 1735574113, '__ci_last_regenerate|i:1735574113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('umgr3h5sopr7bie8is5hd0pkon60ddfp', '192.250.227.14', 1735560132, '__ci_last_regenerate|i:1735560132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('umok8r338el06369qp107bvj71eh9hnb', '192.250.227.14', 1735556292, '__ci_last_regenerate|i:1735556292;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uo0sd5rcskg7eos0b8eru0mh71mu72rf', '192.250.227.14', 1735552032, '__ci_last_regenerate|i:1735552032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('up0g71ocv33qo9jc9o3o5rl0tvp33vtr', '192.250.227.14', 1735583592, '__ci_last_regenerate|i:1735583592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('up3r3mf0mgl5gdaiibufuc1qn1uijtkv', '192.250.227.14', 1735590313, '__ci_last_regenerate|i:1735590313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ur3k15s8h0sdd3grbg1c36g03n941p8g', '192.250.227.14', 1735558392, '__ci_last_regenerate|i:1735558392;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uripst2bd7dveiq5pn5aol7sb1etht3o', '192.250.227.14', 1735545615, '__ci_last_regenerate|i:1735545614;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('urup3kekv5aicu95amlhsg8ur55m3r77', '192.250.227.14', 1735582272, '__ci_last_regenerate|i:1735582271;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('utgff4tmkkccqmpl68gef37e0qrocqb3', '192.250.227.14', 1735571652, '__ci_last_regenerate|i:1735571652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('utseunin4pn2s80u8avhlgusq3k0a2p5', '192.250.227.14', 1735593732, '__ci_last_regenerate|i:1735593732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uu9205s679v05vkisro3ofnbk5tkb19b', '192.250.227.14', 1735596672, '__ci_last_regenerate|i:1735596672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uv40p0gm7r7c9ilu9rqpdpojrbb3992r', '192.250.227.14', 1735565532, '__ci_last_regenerate|i:1735565532;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v0cnro1cjqeieb2tsbucgi875mogrf43', '192.250.227.14', 1735544413, '__ci_last_regenerate|i:1735544413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v0v0nujs953ups2kpks2to4met77k3s5', '192.250.227.14', 1735596852, '__ci_last_regenerate|i:1735596852;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v20c6m8ok5muer2kvfdib9vt8qrr6f4g', '192.250.227.14', 1735585872, '__ci_last_regenerate|i:1735585872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v3hhuduonldervd84uuult1ap4nb84an', '192.250.227.14', 1735582632, '__ci_last_regenerate|i:1735582632;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v46ea8p2aduqfq1oqctv4g1k59mp5jql', '192.250.227.14', 1735580592, '__ci_last_regenerate|i:1735580592;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v4id1a0f5iep5ehd619vs224jilk81fq', '192.250.227.14', 1735574593, '__ci_last_regenerate|i:1735574593;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7t4hnvq8bsqg949p0pvcuflb2gs7ult', '192.250.227.14', 1735594332, '__ci_last_regenerate|i:1735594332;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v8vs0fv4klkmq5f436gbbk526rme7sna', '192.250.227.14', 1735542313, '__ci_last_regenerate|i:1735542313;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v95odj9glcikdfah56g9qj9c0mb47l1c', '192.250.227.14', 1735579933, '__ci_last_regenerate|i:1735579932;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v9etu0amlbu4v6p30hk8d79sjnjhaom2', '192.250.227.14', 1735583352, '__ci_last_regenerate|i:1735583352;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('va0plap3fa6a25cpea344t5tjhsl87ad', '192.250.227.14', 1735557252, '__ci_last_regenerate|i:1735557252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vafgr86dl6h3q67hlblmsedltrc76vfk', '192.250.227.14', 1735596914, '__ci_last_regenerate|i:1735596914;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vb260jntev7ru7nd192h3op072lof895', '192.250.227.14', 1735569072, '__ci_last_regenerate|i:1735569072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vca169nletog941k1s4ic0eo4mv6gqop', '192.250.227.14', 1735574052, '__ci_last_regenerate|i:1735574052;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vcbmk1vco9kuk6c4jllpk661a5jt9dbt', '192.250.227.14', 1735586053, '__ci_last_regenerate|i:1735586053;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vctpmhgb42ak9n43gkhppo9s79or8bc8', '192.250.227.14', 1735544953, '__ci_last_regenerate|i:1735544953;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vdh9gehnsrdaa281uqjh91cv5fecqosg', '192.250.227.14', 1735546452, '__ci_last_regenerate|i:1735546452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vdnc5jtcsjjr9ddgdov4o88eo1j0dhcn', '192.250.227.14', 1735557792, '__ci_last_regenerate|i:1735557792;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vdptb8m07klshu7fmvgti9v948jt7ph0', '192.250.227.14', 1735577113, '__ci_last_regenerate|i:1735577113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ved1di3dbg553586b9ckg6uhrmutvk6j', '192.250.227.14', 1735578016, '__ci_last_regenerate|i:1735578015;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vfarppidksfublh337fnr7jsd0o3pg76', '192.250.227.14', 1735566072, '__ci_last_regenerate|i:1735566072;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vfr7t3kitmp4h0r7nugb5pcrom3c9usf', '192.250.227.14', 1735572132, '__ci_last_regenerate|i:1735572132;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vfutrn1eq3us81ud2h140lbek1a3mqbu', '192.250.227.14', 1735550414, '__ci_last_regenerate|i:1735550413;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vg3olln1rvgqgrunji52j33hji8ppmq2', '192.250.227.14', 1735556652, '__ci_last_regenerate|i:1735556652;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vgk8l834aua12kkur8b0trkt9c85p12p', '192.250.227.14', 1735545192, '__ci_last_regenerate|i:1735545192;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vh0b38obf3mmjdhohquik25hbu1g93k3', '192.250.227.14', 1735581252, '__ci_last_regenerate|i:1735581252;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vh1e72peqtnpm4bpe5ci8f4qr095ag0f', '192.250.227.14', 1735591813, '__ci_last_regenerate|i:1735591813;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vhdh6djtnrqn0sslonqtmgh6ncgc503l', '192.250.227.14', 1735582393, '__ci_last_regenerate|i:1735582393;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vi5fnn4kfkeh0ldl3nl9k8b75h5v0imk', '192.250.227.14', 1735583473, '__ci_last_regenerate|i:1735583473;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vi5r48vn408mntstv9jkh1nl03papk1g', '192.250.227.14', 1735547533, '__ci_last_regenerate|i:1735547533;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vj180hcajecuildsl0pjapi54ggv6e5q', '192.250.227.14', 1735556172, '__ci_last_regenerate|i:1735556172;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vjbulme1njterpof1jsva3cj2jookfji', '192.250.227.14', 1735560732, '__ci_last_regenerate|i:1735560732;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vju9ondt4lh7bsc1uu01c6nkjggddp1e', '192.250.227.14', 1735579452, '__ci_last_regenerate|i:1735579452;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vk7vv8ji87uagg9uq8rtdnc4o399kjmj', '192.250.227.14', 1735575433, '__ci_last_regenerate|i:1735575433;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vlue9vboh6ifdf7a4mg2f4p3inmmusfl', '192.250.227.14', 1735573032, '__ci_last_regenerate|i:1735573032;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vmdfkj2b74qrr2n1g8c031end0hub3hg', '192.250.227.14', 1735557733, '__ci_last_regenerate|i:1735557733;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vmomi1jmnlcq85dkogbl1absoudga6pv', '192.250.227.14', 1735587432, '__ci_last_regenerate|i:1735587432;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vmr232e2qu78l07fp0hmbich7nei3bqk', '192.250.227.14', 1735553113, '__ci_last_regenerate|i:1735553113;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vp0qf0qp3j7st5g57nvnd075gbflo60f', '192.250.227.14', 1735578673, '__ci_last_regenerate|i:1735578672;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vp8gvtm094c2vqn31rj1c8tio6i2hjg2', '192.250.227.14', 1735570872, '__ci_last_regenerate|i:1735570872;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vqab1aprr9n2e0d26mik6ckpfcap710e', '192.250.227.14', 1735571773, '__ci_last_regenerate|i:1735571773;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vqp117s0dj4lp0rd7leeadrtu8lln9kq', '192.250.227.14', 1735549993, '__ci_last_regenerate|i:1735549993;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vsu0q0gau2gqu7tmorhv5qs9vj2u4n7e', '192.250.227.14', 1735564993, '__ci_last_regenerate|i:1735564992;db_name|N;_prev_url|s:42:\"https://smarterp.smartnetgt.com/cron/index\";');


#
# TABLE STRUCTURE FOR: tblsetting_asset_allocation
#

DROP TABLE IF EXISTS `tblsetting_asset_allocation`;

CREATE TABLE `tblsetting_asset_allocation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblsetting_training
#

DROP TABLE IF EXISTS `tblsetting_training`;

CREATE TABLE `tblsetting_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_type` int(11) NOT NULL,
  `position_training` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblsetting_transfer_records
#

DROP TABLE IF EXISTS `tblsetting_transfer_records`;

CREATE TABLE `tblsetting_transfer_records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblshared_customer_files
#

DROP TABLE IF EXISTS `tblshared_customer_files`;

CREATE TABLE `tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblshift_type
#

DROP TABLE IF EXISTS `tblshift_type`;

CREATE TABLE `tblshift_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_type_name` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `time_start` date DEFAULT NULL,
  `time_end` date DEFAULT NULL,
  `time_start_work` varchar(50) DEFAULT NULL,
  `time_end_work` varchar(50) DEFAULT NULL,
  `start_lunch_break_time` varchar(50) DEFAULT NULL,
  `end_lunch_break_time` varchar(50) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblsi_timesheet_filter
#

DROP TABLE IF EXISTS `tblsi_timesheet_filter`;

CREATE TABLE `tblsi_timesheet_filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filter_name` varchar(200) NOT NULL,
  `filter_parameters` text NOT NULL,
  `filter_type` int(11) NOT NULL DEFAULT 1,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `created_dt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblspam_filters
#

DROP TABLE IF EXISTS `tblspam_filters`;

CREATE TABLE `tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` longtext DEFAULT NULL,
  `linkedin` longtext DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` mediumtext DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `sex` varchar(15) DEFAULT NULL,
  `marital_status` varchar(25) DEFAULT NULL,
  `nation` varchar(25) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  `days_for_identity` date DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_address` varchar(200) DEFAULT NULL,
  `literacy` varchar(50) DEFAULT NULL,
  `orther_infor` text DEFAULT NULL,
  `job_position` int(11) DEFAULT NULL,
  `workplace` int(11) DEFAULT NULL,
  `place_of_issue` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `name_account` varchar(50) DEFAULT NULL,
  `issue_bank` varchar(200) DEFAULT NULL,
  `records_received` longtext DEFAULT NULL,
  `Personal_tax_code` varchar(50) DEFAULT NULL,
  `google_auth_secret` mediumtext DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `team_manage` int(11) DEFAULT 0,
  `staff_identifi` varchar(200) DEFAULT NULL,
  `status_work` varchar(100) DEFAULT NULL,
  `date_update` date DEFAULT NULL,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `birthday`, `birthplace`, `sex`, `marital_status`, `nation`, `religion`, `identification`, `days_for_identity`, `home_town`, `resident`, `current_address`, `literacy`, `orther_infor`, `job_position`, `workplace`, `place_of_issue`, `account_number`, `name_account`, `issue_bank`, `records_received`, `Personal_tax_code`, `google_auth_secret`, `token`, `team_manage`, `staff_identifi`, `status_work`, `date_update`) VALUES (1, 'soporte@smartnetgt.com', 'Soporte', 'SmartNet', NULL, NULL, NULL, NULL, '$2a$08$tK3Kkw0F.8JF7YJl/HfLjOypQGmMIRPfYfnC7.kJiQPiV3bgkobBG', '2024-12-16 02:12:16', NULL, '181.174.105.63', '2024-12-30 16:48:48', '2024-12-30 16:50:44', NULL, NULL, NULL, 1, 4, 1, NULL, NULL, NULL, 0, '0.00', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblstaff_contract
#

DROP TABLE IF EXISTS `tblstaff_contract`;

CREATE TABLE `tblstaff_contract` (
  `id_contract` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `contract_code` varchar(15) NOT NULL,
  `name_contract` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `contract_form` varchar(191) DEFAULT NULL,
  `start_valid` date DEFAULT NULL,
  `end_valid` date DEFAULT NULL,
  `contract_status` varchar(100) DEFAULT NULL,
  `salary_form` int(11) DEFAULT NULL,
  `allowance_type` varchar(11) DEFAULT NULL,
  `sign_day` date DEFAULT NULL,
  `staff_delegate` int(11) DEFAULT NULL,
  `staff_role` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_contract`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblstaff_contract_detail
#

DROP TABLE IF EXISTS `tblstaff_contract_detail`;

CREATE TABLE `tblstaff_contract_detail` (
  `contract_detail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_contract_id` int(11) unsigned NOT NULL,
  `since_date` date DEFAULT NULL,
  `contract_note` varchar(100) DEFAULT NULL,
  `contract_salary_expense` longtext DEFAULT NULL,
  `contract_allowance_expense` longtext DEFAULT NULL,
  PRIMARY KEY (`contract_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblstaff_contracttype
#

DROP TABLE IF EXISTS `tblstaff_contracttype`;

CREATE TABLE `tblstaff_contracttype` (
  `id_contracttype` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_contracttype` varchar(200) NOT NULL,
  `contracttype` varchar(200) NOT NULL,
  `duration` int(11) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `insurance` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_contracttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblstaff_departments
#

DROP TABLE IF EXISTS `tblstaff_departments`;

CREATE TABLE `tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblstaff_insurance
#

DROP TABLE IF EXISTS `tblstaff_insurance`;

CREATE TABLE `tblstaff_insurance` (
  `insurance_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `insurance_book_num` varchar(100) DEFAULT NULL,
  `health_insurance_num` varchar(100) DEFAULT NULL,
  `city_code` varchar(100) DEFAULT NULL,
  `registration_medical` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`insurance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblstaff_insurance_history
#

DROP TABLE IF EXISTS `tblstaff_insurance_history`;

CREATE TABLE `tblstaff_insurance_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `insurance_id` int(11) unsigned NOT NULL,
  `staff_id` int(11) unsigned DEFAULT NULL,
  `from_month` date DEFAULT NULL,
  `formality` varchar(50) DEFAULT NULL,
  `reason` varchar(50) DEFAULT NULL,
  `premium_rates` varchar(100) DEFAULT NULL,
  `payment_company` varchar(100) DEFAULT NULL,
  `payment_worker` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`,`insurance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblstaff_permissions
#

DROP TABLE IF EXISTS `tblstaff_permissions`;

CREATE TABLE `tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblstock_take
#

DROP TABLE IF EXISTS `tblstock_take`;

CREATE TABLE `tblstock_take` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL COMMENT 'the reason stock take',
  `warehouse_id` int(11) DEFAULT NULL,
  `date_stock_take` date DEFAULT NULL,
  `stock_take_code` varchar(100) DEFAULT NULL COMMENT 'số kiểm kê kho',
  `date_add` date DEFAULT NULL,
  `hour_add` date DEFAULT NULL,
  `staff_id` varchar(100) DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  `addedfrom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblstock_take_detail
#

DROP TABLE IF EXISTS `tblstock_take_detail`;

CREATE TABLE `tblstock_take_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `stock_take_id` int(11) NOT NULL,
  `commodity_code` varchar(100) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `unit_id` text DEFAULT NULL,
  `unit_price` varchar(100) DEFAULT NULL,
  `quantity_stock_take` varchar(100) DEFAULT NULL,
  `quantity_accounting_book` varchar(100) DEFAULT NULL,
  `quantity_change` varchar(100) DEFAULT NULL,
  `handling` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0 COMMENT 'status approval ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblsubscriptions
#

DROP TABLE IF EXISTS `tblsubscriptions`;

CREATE TABLE `tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` mediumtext DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` mediumtext DEFAULT NULL,
  `stripe_subscription_id` mediumtext NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltaggables
#

DROP TABLE IF EXISTS `tbltaggables`;

CREATE TABLE `tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_assigned
#

DROP TABLE IF EXISTS `tbltask_assigned`;

CREATE TABLE `tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_bookmarks
#

DROP TABLE IF EXISTS `tbltask_bookmarks`;

CREATE TABLE `tbltask_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `creator` int(11) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltask_bookmarks_detail
#

DROP TABLE IF EXISTS `tbltask_bookmarks_detail`;

CREATE TABLE `tbltask_bookmarks_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_bookmarks_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltask_checklist_items
#

DROP TABLE IF EXISTS `tbltask_checklist_items`;

CREATE TABLE `tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_comments
#

DROP TABLE IF EXISTS `tbltask_comments`;

CREATE TABLE `tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_followers
#

DROP TABLE IF EXISTS `tbltask_followers`;

CREATE TABLE `tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_status_can_change
#

DROP TABLE IF EXISTS `tbltask_status_can_change`;

CREATE TABLE `tbltask_status_can_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_status_id` int(11) NOT NULL,
  `task_status_id_can_change_to` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `task_status_can_change_task_status_id` (`task_status_id`),
  KEY `task_status_can_change_task_status_id_2` (`task_status_id_can_change_to`),
  CONSTRAINT `task_status_can_change_task_status_id` FOREIGN KEY (`task_status_id`) REFERENCES `tbltask_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_status_can_change_task_status_id_2` FOREIGN KEY (`task_status_id_can_change_to`) REFERENCES `tbltask_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_status_dont_have_staff
#

DROP TABLE IF EXISTS `tbltask_status_dont_have_staff`;

CREATE TABLE `tbltask_status_dont_have_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_status_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `task_status_dont_have_staff_task_status_id` (`task_status_id`),
  KEY `task_status_dont_have_staff_staff_id` (`staff_id`),
  CONSTRAINT `task_status_dont_have_staff_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `tblstaff` (`staffid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_status_dont_have_staff_task_status_id` FOREIGN KEY (`task_status_id`) REFERENCES `tbltask_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltask_statuses
#

DROP TABLE IF EXISTS `tbltask_statuses`;

CREATE TABLE `tbltask_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) NOT NULL,
  `name` text NOT NULL,
  `color` text NOT NULL,
  `filter_default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbltask_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (1, 1, 'Por iniciar', '#64748b', 1);
INSERT INTO `tbltask_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (2, 4, 'Espera de respuesta', '#84cc16', 1);
INSERT INTO `tbltask_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (3, 3, 'Testear', '#0284c7', 1);
INSERT INTO `tbltask_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (4, 2, 'En progreso', '#3b82f6', 1);
INSERT INTO `tbltask_statuses` (`id`, `order`, `name`, `color`, `filter_default`) VALUES (5, 5, 'Completo', '#22c55e', 0);


#
# TABLE STRUCTURE FOR: tbltasks
#

DROP TABLE IF EXISTS `tbltasks`;

CREATE TABLE `tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) DEFAULT 1,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltasks_checklist_templates
#

DROP TABLE IF EXISTS `tbltasks_checklist_templates`;

CREATE TABLE `tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltaskstimers
#

DROP TABLE IF EXISTS `tbltaskstimers`;

CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltemplates
#

DROP TABLE IF EXISTS `tbltemplates`;

CREATE TABLE `tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblticket_attachments
#

DROP TABLE IF EXISTS `tblticket_attachments`;

CREATE TABLE `tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblticket_replies
#

DROP TABLE IF EXISTS `tblticket_replies`;

CREATE TABLE `tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets
#

DROP TABLE IF EXISTS `tbltickets`;

CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `merged_ticket_id` int(11) DEFAULT NULL,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `staff_id_replying` int(11) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets_pipe_log
#

DROP TABLE IF EXISTS `tbltickets_pipe_log`;

CREATE TABLE `tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` longtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets_predefined_replies
#

DROP TABLE IF EXISTS `tbltickets_predefined_replies`;

CREATE TABLE `tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltickets_priorities
#

DROP TABLE IF EXISTS `tbltickets_priorities`;

CREATE TABLE `tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (1, 'Low');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (2, 'Medium');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (3, 'High');


#
# TABLE STRUCTURE FOR: tbltickets_status
#

DROP TABLE IF EXISTS `tbltickets_status`;

CREATE TABLE `tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (1, 'Open', 1, '#ff2d42', 1);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (2, 'In progress', 1, '#22c55e', 2);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (3, 'Answered', 1, '#2563eb', 3);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (4, 'On Hold', 1, '#64748b', 4);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (5, 'Closed', 1, '#03a9f4', 5);


#
# TABLE STRUCTURE FOR: tbltimesheets_additional_timesheet
#

DROP TABLE IF EXISTS `tbltimesheets_additional_timesheet`;

CREATE TABLE `tbltimesheets_additional_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `additional_day` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `timekeeping_type` varchar(50) DEFAULT NULL,
  `timekeeping_value` varchar(45) NOT NULL,
  `approver` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `old_timekeeping` varchar(50) DEFAULT NULL,
  `time_in` varchar(45) DEFAULT NULL,
  `time_out` varchar(45) DEFAULT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_approval_details
#

DROP TABLE IF EXISTS `tbltimesheets_approval_details`;

CREATE TABLE `tbltimesheets_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  `notification_recipient` longtext DEFAULT NULL,
  `approval_deadline` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_approval_setting
#

DROP TABLE IF EXISTS `tbltimesheets_approval_setting`;

CREATE TABLE `tbltimesheets_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  `choose_when_approving` int(11) NOT NULL DEFAULT 0,
  `notification_recipient` longtext DEFAULT NULL,
  `number_day_approval` int(11) DEFAULT NULL,
  `departments` text DEFAULT NULL,
  `job_positions` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_day_off
#

DROP TABLE IF EXISTS `tbltimesheets_day_off`;

CREATE TABLE `tbltimesheets_day_off` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `year` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `remain` varchar(45) DEFAULT NULL,
  `accumulated` varchar(45) DEFAULT NULL,
  `days_off` float DEFAULT 0,
  `type_of_leave` varchar(200) NOT NULL DEFAULT '8',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_go_bussiness_advance_payment
#

DROP TABLE IF EXISTS `tbltimesheets_go_bussiness_advance_payment`;

CREATE TABLE `tbltimesheets_go_bussiness_advance_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_leave` int(11) NOT NULL,
  `used_to` varchar(200) DEFAULT NULL,
  `amoun_of_money` varchar(200) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `advance_payment_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_latch_timesheet
#

DROP TABLE IF EXISTS `tbltimesheets_latch_timesheet`;

CREATE TABLE `tbltimesheets_latch_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_latch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_leave
#

DROP TABLE IF EXISTS `tbltimesheets_leave`;

CREATE TABLE `tbltimesheets_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_log_send_notify
#

DROP TABLE IF EXISTS `tbltimesheets_log_send_notify`;

CREATE TABLE `tbltimesheets_log_send_notify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) NOT NULL DEFAULT 0,
  `staffid` int(11) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (1, 1, 0, '2024-12-15 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (2, 1, 0, '2024-12-16 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (3, 1, 0, '2024-12-17 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (4, 1, 0, '2024-12-18 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (5, 1, 0, '2024-12-19 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (6, 1, 0, '2024-12-20 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (7, 1, 0, '2024-12-21 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (8, 1, 0, '2024-12-22 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (9, 1, 0, '2024-12-23 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (10, 1, 0, '2024-12-24 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (11, 1, 0, '2024-12-25 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (12, 1, 0, '2024-12-26 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (13, 1, 0, '2024-12-27 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (14, 1, 0, '2024-12-28 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (15, 1, 0, '2024-12-29 00:00:00', 'approval_expiration');
INSERT INTO `tbltimesheets_log_send_notify` (`id`, `sent`, `staffid`, `date`, `type`) VALUES (16, 1, 0, '2024-12-30 00:00:00', 'approval_expiration');


#
# TABLE STRUCTURE FOR: tbltimesheets_option
#

DROP TABLE IF EXISTS `tbltimesheets_option`;

CREATE TABLE `tbltimesheets_option` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(200) NOT NULL,
  `option_val` longtext DEFAULT NULL,
  `auto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (1, 'shift_applicable_object', '', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (2, 'timekeeping_form', 'timekeeping_manually', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (3, 'timekeeping_manually_role', '', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (4, 'timekeeping_task_role', '', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (5, 'csv_clsx_role', '', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (6, 'attendance_notice_recipient', '', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (7, 'allows_updating_check_in_time', '1', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (8, 'allows_to_choose_an_older_date', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (9, 'allow_attendance_by_coordinates', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (10, 'googlemap_api_key', '', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (11, 'allow_attendance_by_route', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (12, 'auto_checkout', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (13, 'auto_checkout_type', '1', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (14, 'auto_checkout_value', '1', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (15, 'send_notification_if_check_in_forgotten', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (16, 'send_notification_if_check_in_forgotten_value', '30', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (17, 'start_month_for_annual_leave_cycle', '1', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (18, 'start_year_for_annual_leave_cycle', '2024', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (19, 'hour_notification_approval_exp', '3', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (20, 'timekeeping_enable_valid_ip', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (21, 'send_email_check_in_out_customer_location', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (22, 'allow_employees_to_create_work_points', '0', 1);
INSERT INTO `tbltimesheets_option` (`option_id`, `option_name`, `option_val`, `auto`) VALUES (23, 'type_of_leave_selected', '8', 1);


#
# TABLE STRUCTURE FOR: tbltimesheets_requisition_leave
#

DROP TABLE IF EXISTS `tbltimesheets_requisition_leave`;

CREATE TABLE `tbltimesheets_requisition_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount_received` text DEFAULT NULL,
  `approver_id` int(11) NOT NULL,
  `followers_id` int(11) DEFAULT NULL,
  `rel_type` int(11) NOT NULL COMMENT '1:Leave 2:Late_early 3:Go_out 4:Go_on_bussiness',
  `status` int(11) DEFAULT 0 COMMENT '0:Create 1:Approver 2:Reject',
  `place_of_business` longtext DEFAULT NULL,
  `type_of_leave` int(11) DEFAULT 0,
  `according_to_the_plan` int(11) DEFAULT 0,
  `handover_recipients` longtext DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `number_of_days` float DEFAULT NULL,
  `number_of_leaving_day` varchar(45) DEFAULT NULL,
  `type_of_leave_text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_route
#

DROP TABLE IF EXISTS `tbltimesheets_route`;

CREATE TABLE `tbltimesheets_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `route_point_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_route_point
#

DROP TABLE IF EXISTS `tbltimesheets_route_point`;

CREATE TABLE `tbltimesheets_route_point` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `route_point_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `related_to` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_shift_sc
#

DROP TABLE IF EXISTS `tbltimesheets_shift_sc`;

CREATE TABLE `tbltimesheets_shift_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_symbol` varchar(45) NOT NULL,
  `time_start_work` varchar(45) NOT NULL,
  `time_end_work` varchar(45) NOT NULL,
  `start_lunch_break_time` varchar(45) NOT NULL,
  `end_lunch_break_time` varchar(45) NOT NULL,
  `late_latency_allowed` varchar(45) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_shiftwork_sc
#

DROP TABLE IF EXISTS `tbltimesheets_shiftwork_sc`;

CREATE TABLE `tbltimesheets_shiftwork_sc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `shift` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_timekeeper_data
#

DROP TABLE IF EXISTS `tbltimesheets_timekeeper_data`;

CREATE TABLE `tbltimesheets_timekeeper_data` (
  `staff_identifi` varchar(25) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_identifi`,`time`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_timesheet
#

DROP TABLE IF EXISTS `tbltimesheets_timesheet`;

CREATE TABLE `tbltimesheets_timesheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `date_work` date NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `overtime_setting` int(11) DEFAULT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `relate_type` varchar(25) DEFAULT NULL,
  `latch` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_type_of_leave
#

DROP TABLE IF EXISTS `tbltimesheets_type_of_leave`;

CREATE TABLE `tbltimesheets_type_of_leave` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_valid_ip
#

DROP TABLE IF EXISTS `tbltimesheets_valid_ip`;

CREATE TABLE `tbltimesheets_valid_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `date_creator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_workplace
#

DROP TABLE IF EXISTS `tbltimesheets_workplace`;

CREATE TABLE `tbltimesheets_workplace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `workplace_address` varchar(400) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `default` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltimesheets_workplace_assign
#

DROP TABLE IF EXISTS `tbltimesheets_workplace_assign`;

CREATE TABLE `tbltimesheets_workplace_assign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `workplace_id` int(11) NOT NULL,
  `datecreator` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltodos
#

DROP TABLE IF EXISTS `tbltodos`;

CREATE TABLE `tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltracked_mails
#

DROP TABLE IF EXISTS `tbltracked_mails`;

CREATE TABLE `tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbltraining_allocation
#

DROP TABLE IF EXISTS `tbltraining_allocation`;

CREATE TABLE `tbltraining_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_process_id` varchar(100) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `training_type` int(11) DEFAULT NULL,
  `date_add` datetime NOT NULL DEFAULT current_timestamp(),
  `training_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tbltransfer_records_reception
#

DROP TABLE IF EXISTS `tbltransfer_records_reception`;

CREATE TABLE `tbltransfer_records_reception` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `meta` varchar(50) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tbltwocheckout_log
#

DROP TABLE IF EXISTS `tbltwocheckout_log`;

CREATE TABLE `tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `attempt_reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tbluser_auto_login
#

DROP TABLE IF EXISTS `tbluser_auto_login`;

CREATE TABLE `tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tbluser_auto_login` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`, `staff`) VALUES ('3b9656891e6c6ea164dea22724bf0f50', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', '181.174.105.161', '2024-12-16 02:12:46', 1);


#
# TABLE STRUCTURE FOR: tbluser_meta
#

DROP TABLE IF EXISTS `tbluser_meta`;

CREATE TABLE `tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblvault
#

DROP TABLE IF EXISTS `tblvault`;

CREATE TABLE `tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` mediumtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblviews_tracking
#

DROP TABLE IF EXISTS `tblviews_tracking`;

CREATE TABLE `tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblware_body_type
#

DROP TABLE IF EXISTS `tblware_body_type`;

CREATE TABLE `tblware_body_type` (
  `body_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `body_code` varchar(100) DEFAULT NULL,
  `body_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`body_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblware_color
#

DROP TABLE IF EXISTS `tblware_color`;

CREATE TABLE `tblware_color` (
  `color_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `color_code` varchar(100) DEFAULT NULL,
  `color_name` varchar(100) DEFAULT NULL,
  `color_hex` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblware_commodity_type
#

DROP TABLE IF EXISTS `tblware_commodity_type`;

CREATE TABLE `tblware_commodity_type` (
  `commodity_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `commondity_code` varchar(100) DEFAULT NULL,
  `commondity_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`commodity_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblware_size_type
#

DROP TABLE IF EXISTS `tblware_size_type`;

CREATE TABLE `tblware_size_type` (
  `size_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `size_code` varchar(100) DEFAULT NULL,
  `size_name` text DEFAULT NULL,
  `size_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`size_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblware_style_type
#

DROP TABLE IF EXISTS `tblware_style_type`;

CREATE TABLE `tblware_style_type` (
  `style_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `style_code` varchar(100) DEFAULT NULL,
  `style_barcode` text DEFAULT NULL,
  `style_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`style_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblware_unit_type
#

DROP TABLE IF EXISTS `tblware_unit_type`;

CREATE TABLE `tblware_unit_type` (
  `unit_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(100) DEFAULT NULL,
  `unit_name` text DEFAULT NULL,
  `unit_symbol` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`unit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwarehouse
#

DROP TABLE IF EXISTS `tblwarehouse`;

CREATE TABLE `tblwarehouse` (
  `warehouse_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(100) DEFAULT NULL,
  `warehouse_name` text DEFAULT NULL,
  `warehouse_address` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblweb_to_lead
#

DROP TABLE IF EXISTS `tblweb_to_lead`;

CREATE TABLE `tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` longtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` longtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` mediumtext DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `lead_name_prefix` varchar(255) DEFAULT NULL,
  `submit_redirect_url` longtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: tblweb_to_recruitment
#

DROP TABLE IF EXISTS `tblweb_to_recruitment`;

CREATE TABLE `tblweb_to_recruitment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_code` varchar(200) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `cp_proposal` text DEFAULT NULL,
  `cp_position` int(11) DEFAULT NULL,
  `cp_department` int(11) DEFAULT NULL,
  `cp_amount_recruiment` int(11) DEFAULT NULL,
  `cp_form_work` varchar(45) DEFAULT NULL,
  `cp_workplace` varchar(255) DEFAULT NULL,
  `cp_salary_from` decimal(15,0) DEFAULT NULL,
  `cp_salary_to` decimal(15,0) DEFAULT NULL,
  `cp_from_date` date DEFAULT NULL,
  `cp_to_date` date DEFAULT NULL,
  `cp_reason_recruitment` text DEFAULT NULL,
  `cp_job_description` text DEFAULT NULL,
  `cp_manager` text DEFAULT NULL,
  `cp_follower` text DEFAULT NULL,
  `cp_ages_from` int(11) DEFAULT NULL,
  `cp_ages_to` int(11) DEFAULT NULL,
  `cp_gender` varchar(10) DEFAULT NULL,
  `cp_height` float DEFAULT NULL,
  `cp_weight` float DEFAULT NULL,
  `cp_literacy` varchar(200) DEFAULT NULL,
  `cp_experience` varchar(200) DEFAULT NULL,
  `cp_add_from` int(11) DEFAULT NULL,
  `cp_date_add` date DEFAULT NULL,
  `cp_status` int(11) DEFAULT NULL,
  `nation` varchar(15) DEFAULT NULL,
  `nationality` varchar(15) DEFAULT NULL,
  `religion` varchar(15) DEFAULT NULL,
  `marital_status` varchar(15) DEFAULT NULL,
  `birthplace` varchar(200) DEFAULT NULL,
  `home_town` varchar(200) DEFAULT NULL,
  `resident` varchar(200) DEFAULT NULL,
  `current_accommodation` varchar(200) DEFAULT NULL,
  `cp_desired_salary` varchar(10) DEFAULT NULL,
  `specialized` varchar(100) DEFAULT NULL,
  `training_form` varchar(50) DEFAULT NULL,
  `training_places` varchar(50) DEFAULT NULL,
  `lead_source` varchar(10) DEFAULT NULL,
  `lead_status` varchar(10) DEFAULT NULL,
  `notify_ids_staff` text DEFAULT NULL,
  `notify_ids_roles` text DEFAULT NULL,
  `form_key` varchar(32) DEFAULT NULL,
  `notify_lead_imported` int(11) DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT 0,
  `name` varchar(191) DEFAULT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) DEFAULT 1,
  `mark_public` int(11) DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tblweb_to_recruitment` (`id`, `campaign_code`, `campaign_name`, `cp_proposal`, `cp_position`, `cp_department`, `cp_amount_recruiment`, `cp_form_work`, `cp_workplace`, `cp_salary_from`, `cp_salary_to`, `cp_from_date`, `cp_to_date`, `cp_reason_recruitment`, `cp_job_description`, `cp_manager`, `cp_follower`, `cp_ages_from`, `cp_ages_to`, `cp_gender`, `cp_height`, `cp_weight`, `cp_literacy`, `cp_experience`, `cp_add_from`, `cp_date_add`, `cp_status`, `nation`, `nationality`, `religion`, `marital_status`, `birthplace`, `home_town`, `resident`, `current_accommodation`, `cp_desired_salary`, `specialized`, `training_form`, `training_places`, `lead_source`, `lead_status`, `notify_ids_staff`, `notify_ids_roles`, `form_key`, `notify_lead_imported`, `notify_type`, `notify_ids`, `responsible`, `name`, `form_data`, `recaptcha`, `submit_btn_name`, `success_submit_msg`, `language`, `allow_duplicate`, `mark_public`, `track_duplicate_field`, `track_duplicate_field_and`, `create_task_on_duplicate`) VALUES (1, '', '', '', 0, 0, 1, '', '', '0', '0', '0000-00-00', '0000-00-00', '', '', '', '', 15, 60, '', '1', '40', '', '', 0, '0000-00-00', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'f98a4eef1eaf7ef94e05a2f1fd514925', 0, '', '', 0, 'recruitment_form', '[{\"label\":\"Croatia\",\"value\":\"55\"},{\"label\":\"Cuba\",\"value\":\"56\"},{\"label\":\"Curacao\",\"value\":\"57\"},{\"label\":\"Cyprus\",\"value\":\"58\"},{\"label\":\"Czech Republic\",\"value\":\"59\"},{\"label\":\"Democratic Republic of the Congo\",\"value\":\"60\"},{\"label\":\"Denmark\",\"value\":\"61\"},{\"label\":\"Djibouti\",\"value\":\"62\"},{\"label\":\"Dominica\",\"value\":\"63\"},{\"label\":\"Dominican Republic\",\"value\":\"64\"},{\"label\":\"Ecuador\",\"value\":\"65\"},{\"label\":\"Egypt\",\"value\":\"66\"},{\"label\":\"El Salvador\",\"value\":\"67\"},{\"label\":\"Equatorial Guinea\",\"value\":\"68\"},{\"label\":\"Eritrea\",\"value\":\"69\"},{\"label\":\"Estonia\",\"value\":\"70\"},{\"label\":\"Ethiopia\",\"value\":\"71\"},{\"label\":\"Falkland Islands (Malvinas)\",\"value\":\"72\"},{\"label\":\"Faroe Islands\",\"value\":\"73\"},{\"label\":\"Fiji\",\"value\":\"74\"},{\"label\":\"Finland\",\"value\":\"75\"},{\"label\":\"France\",\"value\":\"76\"},{\"label\":\"French Guiana\",\"value\":\"77\"},{\"label\":\"French Polynesia\",\"value\":\"78\"},{\"label\":\"French Southern Territories\",\"value\":\"79\"},{\"label\":\"Gabon\",\"value\":\"80\"},{\"label\":\"Gambia\",\"value\":\"81\"},{\"label\":\"Georgia\",\"value\":\"82\"},{\"label\":\"Germany\",\"value\":\"83\"},{\"label\":\"Ghana\",\"value\":\"84\"},{\"label\":\"Gibraltar\",\"value\":\"85\"},{\"label\":\"Greece\",\"value\":\"86\"},{\"label\":\"Greenland\",\"value\":\"87\"},{\"label\":\"Grenada\",\"value\":\"88\"},{\"label\":\"Guadaloupe\",\"value\":\"89\"},{\"label\":\"Guam\",\"value\":\"90\"},{\"label\":\"Guatemala\",\"value\":\"91\"},{\"label\":\"Guernsey\",\"value\":\"92\"},{\"label\":\"Guinea\",\"value\":\"93\"},{\"label\":\"Guinea-Bissau\",\"value\":\"94\"},{\"label\":\"Guyana\",\"value\":\"95\"},{\"label\":\"Haiti\",\"value\":\"96\"},{\"label\":\"Heard Island and McDonald Islands\",\"value\":\"97\"},{\"label\":\"Honduras\",\"value\":\"98\"},{\"label\":\"Hong Kong\",\"value\":\"99\"},{\"label\":\"Hungary\",\"value\":\"100\"},{\"label\":\"Iceland\",\"value\":\"101\"},{\"label\":\"India\",\"value\":\"102\"},{\"label\":\"Indonesia\",\"value\":\"103\"},{\"label\":\"Iran\",\"value\":\"104\"},{\"label\":\"Iraq\",\"value\":\"105\"},{\"label\":\"Ireland\",\"value\":\"106\"},{\"label\":\"Isle of Man\",\"value\":\"107\"},{\"label\":\"Israel\",\"value\":\"108\"},{\"label\":\"Italy\",\"value\":\"109\"},{\"label\":\"Jamaica\",\"value\":\"110\"},{\"label\":\"Japan\",\"value\":\"111\"},{\"label\":\"Jersey\",\"value\":\"112\"},{\"label\":\"Jordan\",\"value\":\"113\"},{\"label\":\"Kazakhstan\",\"value\":\"114\"},{\"label\":\"Kenya\",\"value\":\"115\"},{\"label\":\"Kiribati\",\"value\":\"116\"},{\"label\":\"Kosovo\",\"value\":\"117\"},{\"label\":\"Kuwait\",\"value\":\"118\"},{\"label\":\"Kyrgyzstan\",\"value\":\"119\"},{\"label\":\"Laos\",\"value\":\"120\"},{\"label\":\"Latvia\",\"value\":\"121\"},{\"label\":\"Lebanon\",\"value\":\"122\"},{\"label\":\"Lesotho\",\"value\":\"123\"},{\"label\":\"Liberia\",\"value\":\"124\"},{\"label\":\"Libya\",\"value\":\"125\"},{\"label\":\"Liechtenstein\",\"value\":\"126\"},{\"label\":\"Lithuania\",\"value\":\"127\"},{\"label\":\"Luxembourg\",\"value\":\"128\"},{\"label\":\"Macao\",\"value\":\"129\"},{\"label\":\"North Macedonia\",\"value\":\"130\"},{\"label\":\"Madagascar\",\"value\":\"131\"},{\"label\":\"Malawi\",\"value\":\"132\"},{\"label\":\"Malaysia\",\"value\":\"133\"},{\"label\":\"Maldives\",\"value\":\"134\"},{\"label\":\"Mali\",\"value\":\"135\"},{\"label\":\"Malta\",\"value\":\"136\"},{\"label\":\"Marshall Islands\",\"value\":\"137\"},{\"label\":\"Martinique\",\"value\":\"138\"},{\"label\":\"Mauritania\",\"value\":\"139\"},{\"label\":\"Mauritius\",\"value\":\"140\"},{\"label\":\"Mayotte\",\"value\":\"141\"},{\"label\":\"Mexico\",\"value\":\"142\"},{\"label\":\"Micronesia\",\"value\":\"143\"},{\"label\":\"Moldava\",\"value\":\"144\"},{\"label\":\"Monaco\",\"value\":\"145\"},{\"label\":\"Mongolia\",\"value\":\"146\"},{\"label\":\"Montenegro\",\"value\":\"147\"},{\"label\":\"Montserrat\",\"value\":\"148\"},{\"label\":\"Morocco\",\"value\":\"149\"},{\"label\":\"Mozambique\",\"value\":\"150\"},{\"label\":\"Myanmar (Burma)\",\"value\":\"151\"},{\"label\":\"Namibia\",\"value\":\"152\"},{\"label\":\"Nauru\",\"value\":\"153\"},{\"label\":\"Nepal\",\"value\":\"154\"},{\"label\":\"Netherlands\",\"value\":\"155\"},{\"label\":\"New Caledonia\",\"value\":\"156\"},{\"label\":\"New Zealand\",\"value\":\"157\"},{\"label\":\"Nicaragua\",\"value\":\"158\"},{\"label\":\"Niger\",\"value\":\"159\"},{\"label\":\"Nigeria\",\"value\":\"160\"},{\"label\":\"Niue\",\"value\":\"161\"},{\"label\":\"Norfolk Island\",\"value\":\"162\"},{\"label\":\"North Korea\",\"value\":\"163\"},{\"label\":\"Northern Mariana Islands\",\"value\":\"164\"},{\"label\":\"Norway\",\"value\":\"165\"},{\"label\":\"Oman\",\"value\":\"166\"},{\"label\":\"Pakistan\",\"value\":\"167\"},{\"label\":\"Palau\",\"value\":\"168\"},{\"label\":\"Palestine\",\"value\":\"169\"},{\"label\":\"Panama\",\"value\":\"170\"},{\"label\":\"Papua New Guinea\",\"value\":\"171\"},{\"label\":\"Paraguay\",\"value\":\"172\"},{\"label\":\"Peru\",\"value\":\"173\"},{\"label\":\"Phillipines\",\"value\":\"174\"},{\"label\":\"Pitcairn\",\"value\":\"175\"},{\"label\":\"Poland\",\"value\":\"176\"},{\"label\":\"Portugal\",\"value\":\"177\"},{\"label\":\"Puerto Rico\",\"value\":\"178\"},{\"label\":\"Qatar\",\"value\":\"179\"},{\"label\":\"Reunion\",\"value\":\"180\"},{\"label\":\"Romania\",\"value\":\"181\"},{\"label\":\"Russia\",\"value\":\"182\"},{\"label\":\"Rwanda\",\"value\":\"183\"},{\"label\":\"Saint Barthelemy\",\"value\":\"184\"},{\"label\":\"Saint Helena\",\"value\":\"185\"},{\"label\":\"Saint Kitts and Nevis\",\"value\":\"186\"},{\"label\":\"Saint Lucia\",\"value\":\"187\"},{\"label\":\"Saint Martin\",\"value\":\"188\"},{\"label\":\"Saint Pierre and Miquelon\",\"value\":\"189\"},{\"label\":\"Saint Vincent and the Grenadines\",\"value\":\"190\"},{\"label\":\"Samoa\",\"value\":\"191\"},{\"label\":\"San Marino\",\"value\":\"192\"},{\"label\":\"Sao Tome and Principe\",\"value\":\"193\"},{\"label\":\"Saudi Arabia\",\"value\":\"194\"},{\"label\":\"Senegal\",\"value\":\"195\"},{\"label\":\"Serbia\",\"value\":\"196\"},{\"label\":\"Seychelles\",\"value\":\"197\"},{\"label\":\"Sierra Leone\",\"value\":\"198\"},{\"label\":\"Singapore\",\"value\":\"199\"},{\"label\":\"Sint Maarten\",\"value\":\"200\"},{\"label\":\"Slovakia\",\"value\":\"201\"},{\"label\":\"Slovenia\",\"value\":\"202\"},{\"label\":\"Solomon Islands\",\"value\":\"203\"},{\"label\":\"Somalia\",\"value\":\"204\"},{\"label\":\"South Africa\",\"value\":\"205\"},{\"label\":\"South Georgia and the South Sandwich Islands\",\"value\":\"206\"},{\"label\":\"South Korea\",\"value\":\"207\"},{\"label\":\"South Sudan\",\"value\":\"208\"},{\"label\":\"Spain\",\"value\":\"209\"},{\"label\":\"Sri Lanka\",\"value\":\"210\"},{\"label\":\"Sudan\",\"value\":\"211\"},{\"label\":\"Suriname\",\"value\":\"212\"},{\"label\":\"Svalbard and Jan Mayen\",\"value\":\"213\"},{\"label\":\"Swaziland\",\"value\":\"214\"},{\"label\":\"Sweden\",\"value\":\"215\"},{\"label\":\"Switzerland\",\"value\":\"216\"},{\"label\":\"Syria\",\"value\":\"217\"},{\"label\":\"Taiwan\",\"value\":\"218\"},{\"label\":\"Tajikistan\",\"value\":\"219\"},{\"label\":\"Tanzania\",\"value\":\"220\"},{\"label\":\"Thailand\",\"value\":\"221\"},{\"label\":\"Timor-Leste (East Timor)\",\"value\":\"222\"},{\"label\":\"Togo\",\"value\":\"223\"},{\"label\":\"Tokelau\",\"value\":\"224\"},{\"label\":\"Tonga\",\"value\":\"225\"},{\"label\":\"Trinidad and Tobago\",\"value\":\"226\"},{\"label\":\"Tunisia\",\"value\":\"227\"},{\"label\":\"Turkey\",\"value\":\"228\"},{\"label\":\"Turkmenistan\",\"value\":\"229\"},{\"label\":\"Turks and Caicos Islands\",\"value\":\"230\"},{\"label\":\"Tuvalu\",\"value\":\"231\"},{\"label\":\"Uganda\",\"value\":\"232\"},{\"label\":\"Ukraine\",\"value\":\"233\"},{\"label\":\"United Arab Emirates\",\"value\":\"234\"},{\"label\":\"United Kingdom\",\"value\":\"235\"},{\"label\":\"United States\",\"value\":\"236\"},{\"label\":\"United States Minor Outlying Islands\",\"value\":\"237\"},{\"label\":\"Uruguay\",\"value\":\"238\"},{\"label\":\"Uzbekistan\",\"value\":\"239\"},{\"label\":\"Vanuatu\",\"value\":\"240\"},{\"label\":\"Vatican City\",\"value\":\"241\"},{\"label\":\"Venezuela\",\"value\":\"242\"},{\"label\":\"Vietnam\",\"value\":\"243\",\"selected\":true},{\"label\":\"Virgin Islands, British\",\"value\":\"244\"},{\"label\":\"Virgin Islands, US\",\"value\":\"245\"},{\"label\":\"Wallis and Futuna\",\"value\":\"246\"},{\"label\":\"Western Sahara\",\"value\":\"247\"},{\"label\":\"Yemen\",\"value\":\"248\"},{\"label\":\"Zambia\",\"value\":\"249\"},{\"label\":\"Zimbabwe\",\"value\":\"250\"}]},{\"type\":\"text\",\"label\":\"_national\",\"className\":\"form-control\",\"name\":\"nation\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_religion\",\"className\":\"form-control\",\"name\":\"religion\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"_phone\",\"className\":\"form-control\",\"name\":\"phonenumber\",\"subtype\":\"text\"},{\"type\":\"select\",\"label\":\"_diploma\",\"className\":\"form-control\",\"name\":\"diploma\",\"values\":[{\"label\":\"\",\"value\":\"\"},{\"label\":\"master_s_degree\",\"value\":\"0\"},{\"label\":\"Ph_D\",\"value\":\"1\"},{\"label\":\"bachelor\",\"value\":\"2\"},{\"label\":\"university\",\"value\":\"3\"},{\"label\":\"vocational_colleges\",\"value\":\"4\"},{\"label\":\"vocational\",\"value\":\"5\"},{\"label\":\"high_school\",\"value\":\"6\"}]},{\"type\":\"text\",\"label\":\"training_places\",\"className\":\"form-control\",\"name\":\"training_places\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"specialized\",\"className\":\"form-control\",\"name\":\"specialized\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"forms_of_training\",\"className\":\"form-control\",\"name\":\"training_form\",\"subtype\":\"text\"},{\"type\":\"text\",\"label\":\"issue_date_identification_card\",\"className\":\"form-control fc-datepicker\",\"name\":\"days_for_identity\",\"subtype\":\"text\"}]', 0, 'sent', 'sent_successfully', '', 0, 0, '', '', 0);


#
# TABLE STRUCTURE FOR: tblwh_activity_log
#

DROP TABLE IF EXISTS `tblwh_activity_log`;

CREATE TABLE `tblwh_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblwh_approval_details
#

DROP TABLE IF EXISTS `tblwh_approval_details`;

CREATE TABLE `tblwh_approval_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(45) NOT NULL,
  `staffid` varchar(45) DEFAULT NULL,
  `approve` varchar(45) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approve_action` varchar(255) DEFAULT NULL,
  `reject_action` varchar(255) DEFAULT NULL,
  `approve_value` varchar(255) DEFAULT NULL,
  `reject_value` varchar(255) DEFAULT NULL,
  `staff_approve` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `date_send` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblwh_approval_setting
#

DROP TABLE IF EXISTS `tblwh_approval_setting`;

CREATE TABLE `tblwh_approval_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `related` varchar(255) NOT NULL,
  `setting` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: tblwh_brand
#

DROP TABLE IF EXISTS `tblwh_brand`;

CREATE TABLE `tblwh_brand` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_custom_fields
#

DROP TABLE IF EXISTS `tblwh_custom_fields`;

CREATE TABLE `tblwh_custom_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `custom_fields_id` int(11) DEFAULT NULL,
  `warehouse_id` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_goods_delivery_activity_log
#

DROP TABLE IF EXISTS `tblwh_goods_delivery_activity_log`;

CREATE TABLE `tblwh_goods_delivery_activity_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_inventory_serial_numbers
#

DROP TABLE IF EXISTS `tblwh_inventory_serial_numbers`;

CREATE TABLE `tblwh_inventory_serial_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commodity_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `inventory_manage_id` int(11) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `is_used` varchar(20) DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_loss_adjustment
#

DROP TABLE IF EXISTS `tblwh_loss_adjustment`;

CREATE TABLE `tblwh_loss_adjustment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) DEFAULT NULL,
  `addfrom` int(11) DEFAULT NULL,
  `reason` longtext DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `date_create` date NOT NULL,
  `status` int(11) NOT NULL,
  `warehouses` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_loss_adjustment_detail
#

DROP TABLE IF EXISTS `tblwh_loss_adjustment_detail`;

CREATE TABLE `tblwh_loss_adjustment_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `items` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `current_number` int(15) DEFAULT NULL,
  `updates_number` int(15) DEFAULT NULL,
  `loss_adjustment` int(11) DEFAULT NULL,
  `expiry_date` text DEFAULT NULL,
  `lot_number` text DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_model
#

DROP TABLE IF EXISTS `tblwh_model`;

CREATE TABLE `tblwh_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_omni_shipments
#

DROP TABLE IF EXISTS `tblwh_omni_shipments`;

CREATE TABLE `tblwh_omni_shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) DEFAULT NULL,
  `shipment_number` varchar(100) DEFAULT NULL,
  `planned_shipping_date` datetime DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT NULL,
  `datecreated` datetime DEFAULT NULL,
  `goods_delivery_id` int(11) DEFAULT NULL,
  `shipment_hash` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_order_return_details
#

DROP TABLE IF EXISTS `tblwh_order_return_details`;

CREATE TABLE `tblwh_order_return_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_return_id` int(11) NOT NULL,
  `rel_type_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `reason_return` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_order_returns
#

DROP TABLE IF EXISTS `tblwh_order_returns`;

CREATE TABLE `tblwh_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(50) NOT NULL COMMENT 'manual, sales_return_order, purchasing_return_order',
  `return_type` varchar(50) DEFAULT NULL COMMENT 'manual, partially, fully',
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `order_number` varchar(500) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `number_of_item` decimal(15,2) DEFAULT 0.00,
  `order_total` decimal(15,2) DEFAULT 0.00,
  `order_return_number` varchar(200) DEFAULT NULL,
  `order_return_name` varchar(500) DEFAULT NULL,
  `fee_return_order` decimal(15,2) DEFAULT 0.00,
  `refund_loyaty_point` int(11) DEFAULT 0,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `adjustment_amount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `return_policies_information` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `receipt_delivery_id` int(1) DEFAULT 0,
  `currency` int(11) DEFAULT NULL,
  `return_reason` longtext DEFAULT NULL,
  `receipt_delivery_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_packing_list_details
#

DROP TABLE IF EXISTS `tblwh_packing_list_details`;

CREATE TABLE `tblwh_packing_list_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packing_list_id` int(11) NOT NULL,
  `delivery_detail_id` int(11) DEFAULT NULL,
  `commodity_code` int(11) DEFAULT NULL,
  `commodity_name` text DEFAULT NULL,
  `quantity` decimal(15,2) DEFAULT 0.00,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT 0.00,
  `sub_total` decimal(15,2) DEFAULT 0.00,
  `tax_id` text DEFAULT NULL,
  `tax_rate` text DEFAULT NULL,
  `tax_name` text DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `serial_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_packing_lists
#

DROP TABLE IF EXISTS `tblwh_packing_lists`;

CREATE TABLE `tblwh_packing_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delivery_note_id` int(11) DEFAULT NULL,
  `packing_list_number` varchar(100) DEFAULT NULL,
  `packing_list_name` varchar(200) DEFAULT NULL,
  `width` decimal(15,2) DEFAULT 0.00,
  `height` decimal(15,2) DEFAULT 0.00,
  `lenght` decimal(15,2) DEFAULT 0.00,
  `weight` decimal(15,2) DEFAULT 0.00,
  `volume` decimal(15,2) DEFAULT 0.00,
  `clientid` int(11) DEFAULT NULL,
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `additional_discount` decimal(15,2) DEFAULT 0.00,
  `total_after_discount` decimal(15,2) DEFAULT 0.00,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `client_note` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approval` int(11) DEFAULT 0,
  `datecreated` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type_of_packing_list` varchar(100) DEFAULT 'total',
  `delivery_status` varchar(100) DEFAULT 'wh_ready_to_deliver',
  `shipping_fee` decimal(15,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_series
#

DROP TABLE IF EXISTS `tblwh_series`;

CREATE TABLE `tblwh_series` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwh_sub_group
#

DROP TABLE IF EXISTS `tblwh_sub_group`;

CREATE TABLE `tblwh_sub_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_group_code` varchar(100) DEFAULT NULL,
  `sub_group_name` text DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  `display` int(1) DEFAULT NULL COMMENT 'display 1: display (yes)  0: not displayed (no)',
  `note` text DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwhatsapp_api_debug_log
#

DROP TABLE IF EXISTS `tblwhatsapp_api_debug_log`;

CREATE TABLE `tblwhatsapp_api_debug_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_endpoint` varchar(255) DEFAULT NULL,
  `phone_number_id` varchar(255) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `business_account_id` varchar(255) DEFAULT NULL,
  `response_code` varchar(4) NOT NULL,
  `response_data` text NOT NULL,
  `send_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`send_json`)),
  `message_category` varchar(50) NOT NULL,
  `category_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`category_params`)),
  `merge_field_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`merge_field_data`)),
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwhatsapp_templates
#

DROP TABLE IF EXISTS `tblwhatsapp_templates`;

CREATE TABLE `tblwhatsapp_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` bigint(20) unsigned NOT NULL COMMENT 'id from api',
  `template_name` varchar(255) NOT NULL,
  `language` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL,
  `header_data_format` varchar(10) NOT NULL,
  `header_data_text` text DEFAULT NULL,
  `header_params_count` int(11) NOT NULL,
  `body_data` text NOT NULL,
  `body_params_count` int(11) NOT NULL,
  `footer_data` text DEFAULT NULL,
  `footer_params_count` int(11) NOT NULL,
  `buttons_data` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwhatsapp_templates_mapping
#

DROP TABLE IF EXISTS `tblwhatsapp_templates_mapping`;

CREATE TABLE `tblwhatsapp_templates_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `send_to` varchar(50) NOT NULL,
  `header_params` varchar(255) NOT NULL,
  `body_params` varchar(255) NOT NULL,
  `footer_params` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `debug_mode` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwiki_articles
#

DROP TABLE IF EXISTS `tblwiki_articles`;

CREATE TABLE `tblwiki_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `is_bookmark` tinyint(3) DEFAULT 0,
  `view_counter` int(11) NOT NULL DEFAULT 0,
  `author_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_publish` tinyint(1) NOT NULL DEFAULT 0,
  `slug` varchar(191) DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL,
  `mindmap_content` text DEFAULT NULL,
  `mindmap_thumb` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwiki_books
#

DROP TABLE IF EXISTS `tblwiki_books`;

CREATE TABLE `tblwiki_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `assign_type` varchar(20) DEFAULT 'specific_staff',
  `assign_ids` mediumtext DEFAULT NULL,
  `author_id` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwiki_staff_article
#

DROP TABLE IF EXISTS `tblwiki_staff_article`;

CREATE TABLE `tblwiki_staff_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `article_id` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwork_shift
#

DROP TABLE IF EXISTS `tblwork_shift`;

CREATE TABLE `tblwork_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_code` varchar(45) NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `shift_type` varchar(200) NOT NULL,
  `department` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `add_from` int(11) NOT NULL,
  `staff` text DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `shifts_detail` text NOT NULL,
  `type_shiftwork` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwork_shift_detail
#

DROP TABLE IF EXISTS `tblwork_shift_detail`;

CREATE TABLE `tblwork_shift_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwork_shift_detail_day_name
#

DROP TABLE IF EXISTS `tblwork_shift_detail_day_name`;

CREATE TABLE `tblwork_shift_detail_day_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `day_name` varchar(45) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblwork_shift_detail_number_day
#

DROP TABLE IF EXISTS `tblwork_shift_detail_number_day`;

CREATE TABLE `tblwork_shift_detail_number_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `work_shift_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: tblworkplace
#

DROP TABLE IF EXISTS `tblworkplace`;

CREATE TABLE `tblworkplace` (
  `workplace_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `workplace_name` varchar(200) NOT NULL,
  PRIMARY KEY (`workplace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

